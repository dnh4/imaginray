import bpy


bpy.context.window.workspace = bpy.data.workspaces[target]
