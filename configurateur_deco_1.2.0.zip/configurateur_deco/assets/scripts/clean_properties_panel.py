import bpy 
from bpy.utils import unregister_class



classes = [
    'SCENE_UL_keying_set_paths',
    'SCENE_PT_scene',
    'SCENE_PT_unit',
    'SCENE_PT_physics',
    'SCENE_PT_keying_sets',
    'SCENE_PT_keying_set_paths',
    'SCENE_PT_keyframing_settings',
    'SCENE_PT_audio',
    'SCENE_PT_rigid_body_world',
    'SCENE_PT_rigid_body_world_settings',
    'SCENE_PT_rigid_body_cache',
    'SCENE_PT_rigid_body_field_weights',
    'SCENE_PT_custom_props',
]

for cls in classes:
    if hasattr(bpy.types, cls):
        theclass = getattr(bpy.types, cls)
        unregister_class(theclass)
