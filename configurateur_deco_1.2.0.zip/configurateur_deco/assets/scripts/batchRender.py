# context.area: VIEW_3D
import bpy
from bpy import context as C
from bpy import data as D
from bpy.props import IntProperty, StringProperty
import datetime



class Batchrender(bpy.types.Operator):
    """Operator which runs itself from a timer"""
    bl_idname = "wm.batchrender"
    bl_label = "Batch Render"

    _timer = None

    cameraIndex: IntProperty(default=0)
    camNum: IntProperty(default=0)
    cameras: [bpy.types.Object] = []

    def getCameraFromObj(self):
        
        self.cameras = [obj for obj in bpy.data.objects if obj.type == 'CAMERA']
        return self.cameras

    def init(self):
        self.cameraIndex = 0
        self.getCameraFromObj()
        self.camNum = len(self.cameras)
        bpy.context.scene.render.engine = 'CYCLES'

    def modal(self, context, event):
        if event.type in {'RIGHTMOUSE', 'ESC'}:
            self.cancel(context)
            return {'CANCELLED'}

        if event.type == 'TIMER':
            if self.cameraIndex < self.camNum:
                if not bpy.app.is_job_running('RENDER'):

                    #Render setups
                    bpy.context.scene.camera = self.cameras[self.cameraIndex]
                    bpy.context.scene.render.filepath = f'//render\\testModal_{bpy.context.scene.camera.name}'
                    bpy.context.scene.cycles.use_denoising = True

                    # if cam is top cam
                    if bpy.context.scene.camera.name == C.scene.sna_addon_prefs_temp.sna_topcamname:
                        #resolution
                        C.scene.render.resolution_x = C.scene.sna_addon_prefs_temp.sna_topcamresolution[0]
                        C.scene.render.resolution_y = C.scene.sna_addon_prefs_temp.sna_topcamresolution[1]
                        # Hide Plafond collection
                        C.scene.collection.children[C.scene.sna_addon_prefs_temp.sna_plafondcollectionname].hide_render = True
                        C.scene.collection.children[C.scene.sna_addon_prefs_temp.sna_plafondcollectionname].hide_viewport = True
                    else:
                        #resolution
                        C.scene.render.resolution_x = C.scene.sna_addon_prefs_temp.sna_panoramic_resolution[0]
                        C.scene.render.resolution_y = C.scene.sna_addon_prefs_temp.sna_panoramic_resolution[1]
                        # Unide Plafond collection
                        C.scene.collection.children[C.scene.sna_addon_prefs_temp.sna_plafondcollectionname].hide_render = False
                        C.scene.collection.children[C.scene.sna_addon_prefs_temp.sna_plafondcollectionname].hide_viewport = False


                    bpy.ops.render.render('INVOKE_DEFAULT', write_still=True, use_viewport=True)
                    self.cameraIndex += 1
                    print('Rendering') 
            else: 
                # Unide Plafond collection
                C.scene.collection.children[C.scene.sna_addon_prefs_temp.sna_plafondcollectionname].hide_render = False
                C.scene.collection.children[C.scene.sna_addon_prefs_temp.sna_plafondcollectionname].hide_viewport = False
                return {'FINISHED'}
            pass
            
        
        return {'PASS_THROUGH'}

    def execute(self, context):
        wm = context.window_manager
        self._timer = wm.event_timer_add(1, window=context.window)
        wm.modal_handler_add(self)
        
        self.init()

        return {'RUNNING_MODAL'}

    def cancel(self, context):
        wm = context.window_manager
        wm.event_timer_remove(self._timer)



def menu_func(self, context):
    self.layout.operator(Batchrender.bl_idname, text=Batchrender.bl_label)


def register():
    bpy.utils.register_class(Batchrender)
#    bpy.types.VIEW3D_MT_view.append(menu_func)
    pass


# Register and add to the "view" menu (required to also use F3 search "Modal Timer Operator" for quick access).
def unregister():
    bpy.utils.unregister_class(Batchrender)
#    bpy.types.VIEW3D_MT_view.remove(menu_func)


# if __name__ == "__main__":
#     try: 
#         unregister()
#     except: pass
#     register()
    
#     # test call
#     bpy.ops.wm.batch_render()





