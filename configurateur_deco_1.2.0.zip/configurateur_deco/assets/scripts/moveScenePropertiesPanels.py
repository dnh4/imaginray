import bl_ui.properties_scene as pscene
from bpy.utils import register_class, unregister_class

def movePanels(reset: bool =False):
    if reset:
        pscene.SceneButtonsPanel.bl_context = 'scene'
        try:
            register_class(pscene.SCENE_PT_scene)
        except: 
            pass
    else:
        pscene.SceneButtonsPanel.bl_context = 'output'
        try:
            unregister_class(pscene.SCENE_PT_scene)
        except:
            pass

    for cls in pscene.classes:
        if cls != pscene.SCENE_PT_scene:
            unregister_class(cls)
            register_class(cls)