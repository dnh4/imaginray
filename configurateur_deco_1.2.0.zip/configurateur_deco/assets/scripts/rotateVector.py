from mathutils import Vector, Euler

#External variables, vec, rot
#External output out
# vec = (0, 0, 1)
# rot = (90*3.14/180, 0, 0)

def rotate(v: Vector, r:Euler):
    v.rotate(r)
    return v


vec = Vector(vec)
rot = Euler(rot)


out = rotate(vec, rot)

