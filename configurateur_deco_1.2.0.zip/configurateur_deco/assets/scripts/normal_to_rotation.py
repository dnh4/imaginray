import bpy
from mathutils import Vector, Matrix, Euler
import math

# normal_vector = (0, 1, 0)
# forward_axis = (0, 0, 1)

def rotation_matrix_to_align_vector(v1: Vector, v2: Vector):
    # Calculate the rotation matrix to align v1 with v2
    threshold = 0.0001
    if math.fabs(v1.angle(v2) % math.pi) >= threshold:
        rot_matrix = Matrix.Rotation(v1.angle(v2), 3, v1.cross(v2).normalized())
        return rot_matrix.to_quaternion().to_euler()
    else:
        return Euler((0, 0, v1.angle(v2)))


# External variable 
normal_vector = Vector(normal_vector)
forward_axis = Vector(forward_axis)


# Compute the rotation quaternion to align the negative y-axis with the normal vector
rotation_euler = rotation_matrix_to_align_vector(forward_axis, normal_vector)

# (1,0,0) -- (0, 1,0)

# print(list(map(lambda x: degrees(x), rotation_euler)))