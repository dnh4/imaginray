import bpy
from bpy.types import (
    Context,
    GizmoGroup,
)

#extern variable: icon_name, x, y, idname

def factory(icon_name: str, x: int, y: int, idname: str):
    class Custom_UI_Buttons(GizmoGroup):
        bl_idname = idname
        bl_label = "Custom UI Buttons"
        bl_space_type = 'VIEW_3D'
        bl_region_type = 'WINDOW'
        bl_options = {'PERSISTENT', 'SCALE'}

        @classmethod
        def poll(cls, context):
            ob = context.object
            return True #(ob and ob.type == 'CAMERA')

        def draw_prepare(self, context):
            region = context.region

            self.foo_gizmo.matrix_basis[0][3] = region.width/2 - 80
            self.foo_gizmo.matrix_basis[1][3] = 40
            # self.foo_gizmo.matrix_basis[0][3] = x
            # self.foo_gizmo.matrix_basis[1][3] = y

        def setup(self, context):
            mpr = self.gizmos.new("GIZMO_GT_button_2d")   # This line crashes Blender

            # mpr.icon = 'OUTLINER_OB_CAMERA'
            mpr.icon = icon_name
                
            mpr.draw_options = {'BACKDROP', 'OUTLINE'}

            mpr.alpha = 0.0
            mpr.color_highlight = 0.8, 0.8, 0.8
            mpr.alpha_highlight = 0.2

            mpr.scale_basis = (80 * 0.35) / 2 # Same as buttons defined in C
            
            #set the operator
    #        props = mpr.target_set_operator("transform.translate")
            
            self.foo_gizmo = mpr
        
        def refresh(self, context: Context):
            region = context.region
            self.foo_gizmo.matrix_basis[0][3] = region.width/2 - 80
            self.foo_gizmo.matrix_basis[1][3] = 40
            return super().refresh(context)
        
        def execute(self, context):
            print("hello")
    Custom_UI_Buttons.__name__ = "Custom_UI_Buttons_%s" % idname

    return Custom_UI_Buttons
cls = factory(icon_name, x, y, idname)

def register():
    bpy.utils.register_class(cls)

def unregister():
    bpy.utils.unregister_class(cls)