import bpy
import os, sys


v3d = bpy.types.VIEW3D_PT_tools_active

bpy.types.VIEW3D_PT_tools_active._tools['OBJECT'] = [None]