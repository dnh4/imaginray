import json

def toJson(filepath: str = "./data.json", data: any = [], returnValue: bool = False):
    if returnValue:
        return json.dumps(data)
    # else
    with open(filepath, "w") as outfile: 
        json.dump(data, outfile)

if __name__ == "__main__":
    a = {'nom': "foo", 'age': 52}

    print(toJson(data=a, returnValue=True))