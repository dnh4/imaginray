import bpy
keymaps = bpy.context.window_manager.keyconfigs.user.keymaps

itemsToEnable = {
    "3D View": ['view3d.rotate', 'view3d.select'],
    "Screen": ['screen.area_move'],
    "Window" : ['sna.toggle_globalhide_aeafd']
}

def enableKeymaps():
    # Activate key maps
    # for space in itemsToEnable.keys():
    #     for id in itemsToEnable[space]:
    #         keymaps[space].keymap_items[id].active = True

    # Change keymaps
        # Rotate view
    keymaps['3D View'].keymap_items['view3d.rotate'].map_type = 'MOUSE'
    keymaps['3D View'].keymap_items['view3d.rotate'].type = 'LEFTMOUSE'
    keymaps['3D View'].keymap_items['view3d.rotate'].value = 'CLICK_DRAG'
        # Select
    keymaps['3D View'].keymap_items['view3d.select'].map_type = 'MOUSE'
    keymaps['3D View'].keymap_items['view3d.select'].type = 'LEFTMOUSE'
    keymaps['3D View'].keymap_items['view3d.select'].value = 'CLICK'


def disableAllKeymaps():
    for keymap in keymaps:
        for item in keymap.keymap_items:
            item.active = False



if __name__ == "__main__":
    # disableAllKeymaps()
    enableKeymaps()
    pass
    