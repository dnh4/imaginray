import os
import sqlite3

def get_database_item(FilePath: str, ColumnNames, ColumnConditions, CheckValues:list, TableName: str, isTransposed:str = True, orderBy:str = None, Ascendent:bool = True ):


    conditions = ColumnConditions

    if not os.path.isfile(FilePath):
        return [None, None, None]
    
    connection = sqlite3.connect(FilePath)
    cursor = connection.cursor()

    # Set the condition for the columns
    columns = ','.join(ColumnNames) if len(ColumnNames) != 0 else '*'

    # filters
    filters = f'WHERE {" AND ".join(conditions)}' if len(conditions) > 0 else ''

    order = f"ORDER BY {orderBy} {'ASC' if Ascendent else 'DESC'}" if (orderBy is not None) and (orderBy != '') else ''
    print(order)

    # Generate the SELECT statement using an f-string
    select_stmt = f"SELECT {columns} FROM {TableName} {filters}"
    select_stmt = select_stmt + f"{order}" if order != '' else select_stmt
    # select_stmt = f"SELECT {columns} FROM {TableName} WHERE Nom Like ?"

    
    results = []
    try:
        cursor.execute(select_stmt, CheckValues)
    
        # Fetch the results
        results = cursor.fetchall()
        nbResults = len(results)

        # trasnpose the list
        if isTransposed:
            results = [list(item) for item in list(zip(*results))]

    except:
        nbResults = 0

    # Commit the changes
    connection.commit()
    # Close the connection
    connection.close()

    return [nbResults, results]

if __name__ == '__main__':
    path = r"L:\#Prod\Leon\3DWarehouse-Lib\Zago officiel\Zago-Officiel.db"
    # get_database_item()
    db = get_database_item(path, ColumnNames=['Couleur'], ColumnConditions=['Prix IS NOT NULL'], CheckValues=[], TableName= 'Zago_Officiel', orderBy='')

    # print(db[-1][0])

    cols = db[-1][0]
    print(list(set(cols)))