import bpy
from mathutils import Vector, Matrix

# obj, external variable
# vec, external variable

world_matrix = obj.matrix_world # outputs 4*4 matrix

vec = Vector(vec)

out = (world_matrix @ vec)[:3]


out = Vector(out).normalized()