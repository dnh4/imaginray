import bpy


addonList = [
    "materials_utils",
    "appart_deco"
]

for addon in addonList:
    try:
        bpy.ops.preferences.addon_enable(module=addon)
    except:
        raise Exception(f"Module '{addon}' not installed!!")