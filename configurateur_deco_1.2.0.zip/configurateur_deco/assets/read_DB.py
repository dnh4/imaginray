import pandas as pd
import time

begin = time.time()

# db_path = "L:/#Prod/Leon/3DWarehouse-Lib/Zago officiel/Zago-Officiel.xlsx"
db_path = "L:/#Prod/Leon/3DWarehouse-Lib/Zago officiel/Zago-Officiel.csv"
directory = "L:/#Prod/Leon/3DWarehouse-Lib/Zago officiel/"

bd_frame = pd.read_csv(db_path)
display_frame = bd_frame[(bd_frame['Dispo']=='Oui') & (bd_frame['Fichier'].notna())  & (bd_frame['Lien_Zago'].notna())]

def filterFrame(initFrame: pd.DataFrame, filter: str, value: str) -> pd.DataFrame:
    # try:
    #     return initFrame.loc[initFrame[filter].str.lower().contains(value.lower())]
    # except:
    #     return None
    conditions = initFrame[filter].str.contains(pat=value, case=False)
    return initFrame[conditions]


columns = ['Nom', 'Fichier', 'Pieces', 'Type', 'Lien_Zago', 'Prix', 'Hauteur', 'Longueur', 'Profondeur', 'Matière',
       'Couleur', 'Pivot', 'Type']
display_frame = display_frame[columns]

try:
    display_frame['Image'] = display_frame['Fichier'].apply(lambda s: s.replace('blend', 'webp'))
except:
    print("Erreur de fichier!!")


[display_frame[entry].to_csv(directory + entry + ".csv", index=False, header=False) for entry in columns + ['Image']]


print(f'Elapsed {time.time() - begin}s')