# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Configurateur Deco",
    "author" : "Kevinn", 
    "description" : "",
    "blender" : (3, 6, 0),
    "version" : (1, 2, 0),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "User Interface" 
}


import bpy
import bpy.utils.previews
import os
import gpu
import gpu_extras
import blf
import math
from bpy.app.handlers import persistent
import mathutils
from bpy import data as D
import datetime
import json
import bl_ui.properties_scene as pscene
from bpy_extras import view3d_utils
from mathutils import Vector, Euler
from datetime import datetime
import textwrap 
import bmesh


addon_keymaps = {}
_icons = None
batch_render = {'sna_index': 0, }
bottom = {'sna_cams': [], 'sna_isbottomdrawn': False, 'sna_button_width': 100, 'sna_button_height': 75, 'sna_button_gap': 50, 'sna_prev_ui_type': '', 'sna_topcamname': 'Top', 'sna_plafondcollectionname': 'Plafond', }
boutons_de_fonctions = {'sna_right_aligned': False, 'sna_cams': [], 'sna_previous_ui_type': '', 'sna_tmpcameraforrender': None, }
boutons_de_fonctions_plus = {'sna_xmove': 0.0, 'sna_ymove': 0.0, 'sna_preveuler': [], }
filtre = {'sna_filtre3d': [], 'sna_filtremat': [], }


importedproducts = {'sna_ids': [], 'sna_price3d': [], 'sna_mat': [], 'sna_areasdict': None, 'sna_dictionnary3d': None, }
mainnodetree = {'sna_globalhide': False, }
placeoncursor = {'sna_hit_location': [], 'sna_objects': [], 'sna_filepath': 'L:/#Prod/Leon/3DWarehouse-Lib/YOKO-SOF3P02.blend', 'sna_objecttoreplace': None, 'sna_hit_normal': [], 'sna_hit_object': None, }
surfaces = {'sna_areas': [], 'sna_matlist': [], }
titres = {'sna_h': 0, 'sna_m': 0, 'sna_s': 0, 'sna_enter_time_h': 0, 'sna_enter_time_m': 0, 'sna_enter_time_s': 0, 'sna_new_variable': 17, }
utils = {'sna_isfinalising': False, 'sna_renderingcameranumber': 0, 'sna_renderingcamera': None, }
viewport_render_cams = {'sna_viewtorender': None, 'sna_previousrenderpercentage': 0, 'sna_previewpercentage': 20, }
zone_de_recherche = {'sna_new_variable': None, 'sna_images': [], 'sna_prices': [], 'sna_term_list': [], 'sna_outputenummap': '', 'sna_colorenummap': '', 'sna_debut': True, 'sna_productidlist': [], }
zone_material = {'sna_faceindex': 0, 'sna_matscollection': [], 'sna_object': None, 'sna_newmaterial': None, 'sna_materials': None, 'sna_materiallist': [], 'sna_matindex': 0, 'sna_filtermat': '', }
zone_recherche_plus = {'sna_filter3d': '', }
bottom_vars_A06F5 = {'sna_cams': [], }


def sna_camera_objects_77160_A06F5(collection_Input):
    bottom_vars_A06F5['sna_cams'] = []
    for i_F1733 in range(len(collection_Input)):
        if collection_Input[i_F1733].type == 'CAMERA':
            bottom_vars_A06F5['sna_cams'].append(collection_Input[i_F1733])
    return bottom_vars_A06F5['sna_cams']


bottom_vars_0D1CD = {'sna_cams': [], }


def sna_camera_objects_77160_0D1CD(collection_Input):
    bottom_vars_0D1CD['sna_cams'] = []
    for i_F1733 in range(len(collection_Input)):
        if collection_Input[i_F1733].type == 'CAMERA':
            bottom_vars_0D1CD['sna_cams'].append(collection_Input[i_F1733])
    return bottom_vars_0D1CD['sna_cams']


bottom_vars_FF824 = {'sna_cams': [], }


def sna_camera_objects_77160_FF824(collection_Input):
    bottom_vars_FF824['sna_cams'] = []
    for i_F1733 in range(len(collection_Input)):
        if collection_Input[i_F1733].type == 'CAMERA':
            bottom_vars_FF824['sna_cams'].append(collection_Input[i_F1733])
    return bottom_vars_FF824['sna_cams']


bottom_vars_0E8F1 = {'sna_cams': [], }


def sna_camera_objects_77160_0E8F1(collection_Input):
    bottom_vars_0E8F1['sna_cams'] = []
    for i_F1733 in range(len(collection_Input)):
        if collection_Input[i_F1733].type == 'CAMERA':
            bottom_vars_0E8F1['sna_cams'].append(collection_Input[i_F1733])
    return bottom_vars_0E8F1['sna_cams']


class dotdict(dict):
    __getattr__ = dict.get
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__


def sna_update_sna_globalhide_8AD9B(self, context):
    sna_updated_prop = self.sna_globalhide
    sna_clean_t_panel_B9F40()


def sna_getdatabase_69E32_DDE5A(Filepath, ColumnNames, ColumnConditions, CheckValues, TableName, isTransposed, orderBy, Ascendent):
    import sqlite3

    def get_database_item(FilePath: str, ColumnNames, ColumnConditions, CheckValues:list, TableName: str, isTransposed:str = True, orderBy:str = None, Ascendent:bool = True ):
        conditions = ColumnConditions
        if not os.path.isfile(FilePath):
            return [None, None, None]
        connection = sqlite3.connect(FilePath)
        cursor = connection.cursor()
        # Set the condition for the columns
        columns = ','.join(ColumnNames) if len(ColumnNames) != 0 else '*'
        # filters
        filters = f'WHERE {" AND ".join(conditions)}' if len(conditions) > 0 else ''
        order = f"ORDER BY {orderBy} {'ASC' if Ascendent else 'DESC'}" if orderBy is not None else ""
        # Generate the SELECT statement using an f-string
        select_stmt = f"SELECT {columns} FROM {TableName} {filters} {order}"
        # select_stmt = f"SELECT {columns} FROM {TableName} WHERE Nom Like ?"
        results = []
        try:
            cursor.execute(select_stmt, CheckValues)
            # Fetch the results
            results = cursor.fetchall()
            nbResults = len(results)
            # trasnpose the list
            if isTransposed:
                results = [list(item) for item in list(zip(*results))]
        except:
            nbResults = 0
        # Commit the changes
        connection.commit()
        # Close the connection
        connection.close()
        return [nbResults, results]
    if __name__ == '__main__':
        path = r"L:\#Prod\Leon\3DWarehouse-Lib\Zago officiel\Zago-Officiel.db"
        # get_database_item()
        db = get_database_item(path, ColumnNames=['Nom', 'Prix'], ColumnConditions=['Prix IS NOT NULL',"Nom LIKE '%lit%' OR Nom LIKE '%rouge%'"], CheckValues=[], TableName= 'Zago_Officiel')
        print(db[-1])
    return_7362F = get_database_item(FilePath=Filepath, ColumnNames=ColumnNames, ColumnConditions=ColumnConditions, CheckValues=CheckValues, TableName=TableName, isTransposed=isTransposed, orderBy=orderBy, Ascendent=Ascendent)
    return [return_7362F[0], return_7362F[1]]


def sna_getdatabase_69E32_7E640(Filepath, ColumnNames, ColumnConditions, CheckValues, TableName, isTransposed, orderBy, Ascendent):
    import sqlite3

    def get_database_item(FilePath: str, ColumnNames, ColumnConditions, CheckValues:list, TableName: str, isTransposed:str = True, orderBy:str = None, Ascendent:bool = True ):
        conditions = ColumnConditions
        if not os.path.isfile(FilePath):
            return [None, None, None]
        connection = sqlite3.connect(FilePath)
        cursor = connection.cursor()
        # Set the condition for the columns
        columns = ','.join(ColumnNames) if len(ColumnNames) != 0 else '*'
        # filters
        filters = f'WHERE {" AND ".join(conditions)}' if len(conditions) > 0 else ''
        order = f"ORDER BY {orderBy} {'ASC' if Ascendent else 'DESC'}" if orderBy is not None else ""
        # Generate the SELECT statement using an f-string
        select_stmt = f"SELECT {columns} FROM {TableName} {filters} {order}"
        # select_stmt = f"SELECT {columns} FROM {TableName} WHERE Nom Like ?"
        results = []
        try:
            cursor.execute(select_stmt, CheckValues)
            # Fetch the results
            results = cursor.fetchall()
            nbResults = len(results)
            # trasnpose the list
            if isTransposed:
                results = [list(item) for item in list(zip(*results))]
        except:
            nbResults = 0
        # Commit the changes
        connection.commit()
        # Close the connection
        connection.close()
        return [nbResults, results]
    if __name__ == '__main__':
        path = r"L:\#Prod\Leon\3DWarehouse-Lib\Zago officiel\Zago-Officiel.db"
        # get_database_item()
        db = get_database_item(path, ColumnNames=['Nom', 'Prix'], ColumnConditions=['Prix IS NOT NULL',"Nom LIKE '%lit%' OR Nom LIKE '%rouge%'"], CheckValues=[], TableName= 'Zago_Officiel')
        print(db[-1])
    return_7362F = get_database_item(FilePath=Filepath, ColumnNames=ColumnNames, ColumnConditions=ColumnConditions, CheckValues=CheckValues, TableName=TableName, isTransposed=isTransposed, orderBy=orderBy, Ascendent=Ascendent)
    return [return_7362F[0], return_7362F[1]]


def sna_update_sna_show_toolbar_FBEFC(self, context):
    sna_updated_prop = self.sna_show_toolbar
    self = eval('True')


bottom_vars_86E9E = {'sna_cams': [], }


def sna_camera_objects_77160_86E9E(collection_Input):
    bottom_vars_86E9E['sna_cams'] = []
    for i_F1733 in range(len(collection_Input)):
        if collection_Input[i_F1733].type == 'CAMERA':
            bottom_vars_86E9E['sna_cams'].append(collection_Input[i_F1733])
    return bottom_vars_86E9E['sna_cams']


class dotdict(dict):
    __getattr__ = dict.get
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__


def sna_node_58D55_C44CC(Modal_Event_Mouse_Region, Move_3D_Cursor):
    Modal_Event_Mouse_Region = Modal_Event_Mouse_Region
    Move_3D_Cursor = Move_3D_Cursor
    best_obj = None
    best_hit = None
    out_face_index = None
    best_normal = None
    coord = Modal_Event_Mouse_Region
    move_3d_cursor = Move_3D_Cursor
    best_obj = None
    hit_world = None
    out_face_index = None
    context = bpy.context
    # get the context arguments
    scene = context.scene
    region = context.region
    rv3d = context.region_data
    #coord = event.mouse_region_x, event.mouse_region_y
    act_obj = bpy.context.active_object
    # get the ray from the viewport and mouse
    view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
    ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
    ray_target = ray_origin + view_vector

    def visible_objects_and_duplis():
        """Loop over (object, matrix) pairs (mesh only)"""
        depsgraph = context.evaluated_depsgraph_get()
        for dup in depsgraph.object_instances:
            if dup.is_instance:  # Real dupli instance
                obj = dup.instance_object
                yield (obj, dup.matrix_world.copy())
            else:  # Usual object
                obj = dup.object
                yield (obj, obj.matrix_world.copy())
    out_face_index=0
    out_edge_index=0

    def obj_ray_cast(obj, matrix):
        """Wrapper for ray casting that moves the ray into object space"""
        # get the ray relative to the object
        matrix_inv = matrix.inverted()
        ray_origin_obj = matrix_inv @ ray_origin
        ray_target_obj = matrix_inv @ ray_target
        ray_direction_obj = ray_target_obj - ray_origin_obj
        # cast the ray
        success, location, normal, face_index = obj.ray_cast(ray_origin_obj, ray_direction_obj)
        if success:
            out_face_index = face_index
            return location, normal, face_index
        else:
            return None, None, None
    # cast rays and find the closest object
    best_length_squared = -1.0
    best_obj = None
    best_hit = None
    best_normal = None
    for obj, matrix in visible_objects_and_duplis():
            if obj.type == 'MESH':
                hit, normal, face_index = obj_ray_cast(obj, matrix)
                if hit is not None:
                    hit_world = matrix @ hit
                    length_squared = (hit_world - ray_origin).length_squared
                    if best_obj is None or length_squared < best_length_squared:
                        best_length_squared = length_squared
                        best_obj_name = obj.name
                        best_obj = obj
                        out_face_index = face_index
                        best_hit = hit_world
                        best_normal = normal
                if move_3d_cursor == True and best_hit != None:
                    scene.cursor.location = best_hit
    # return [best_obj, best_hit, out_face_index, best_normal]
    return [best_obj, best_hit, out_face_index, best_normal]


def sna_rotatevector_B0BC7_BD168(vector, rotation):
    vec = vector
    rot = rotation
    out = None
    #External variables, vec, rot
    #External output out
    # vec = (0, 0, 1)
    # rot = (90*3.14/180, 0, 0)

    def rotate(v: Vector, r:Euler):
        v.rotate(r)
        return v
    vec = Vector(vec)
    rot = Euler(rot)
    out = rotate(vec, rot)
    return out


def sna_update_sna_globalhide_A5A3D(self, context):
    sna_updated_prop = self.sna_globalhide
    if sna_updated_prop:
        bpy.ops.preferences.keyconfig_import(filepath=bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'AppartDeco_Keyconfigs.py')), keep_original=True)
    else:
        bpy.context.preferences.keymap.active_keyconfig = 'Blender'


bottom_vars_B87D4 = {'sna_cams': [], }
bottom_vars_C4A99 = {'sna_cams': [], }


def sna_update_sna_trier_61CB3(self, context):
    sna_updated_prop = self.sna_trier
    if sna_updated_prop == "Par prix croissant":
        bpy.context.scene.sna_prixcroissant = False
    elif sna_updated_prop == "Par prix décroissant":
        bpy.context.scene.sna_prixcroissant = False
    else:
        pass


def sna_update_sna_search_term_9FC8E(self, context):
    sna_updated_prop = self.sna_search_term
    if eval("sna_updated_prop.replace(' ','') == ''"):
        bpy.context.scene.sna_search_term = 'Que recherchez-vous?'


def find_areas_of_type(screen, area_type):
    areas = []
    for area in screen.areas:
        if area.type == area_type:
            areas.append(area)
    return areas


def find_area_by_type(screen, area_type, index):
    areas = find_areas_of_type(screen, area_type)
    if areas:
        return areas[index]
    return None


bottom_vars_CC779 = {'sna_cams': [], }


def sna_camera_objects_77160_CC779(collection_Input):
    bottom_vars_CC779['sna_cams'] = []
    for i_F1733 in range(len(collection_Input)):
        if collection_Input[i_F1733].type == 'CAMERA':
            bottom_vars_CC779['sna_cams'].append(collection_Input[i_F1733])
    return bottom_vars_CC779['sna_cams']


def sna_getdatabase_69E32_88D4D(Filepath, ColumnNames, ColumnConditions, CheckValues, TableName, isTransposed, orderBy, Ascendent):
    import sqlite3

    def get_database_item(FilePath: str, ColumnNames, ColumnConditions, CheckValues:list, TableName: str, isTransposed:str = True, orderBy:str = None, Ascendent:bool = True ):
        conditions = ColumnConditions
        if not os.path.isfile(FilePath):
            return [None, None, None]
        connection = sqlite3.connect(FilePath)
        cursor = connection.cursor()
        # Set the condition for the columns
        columns = ','.join(ColumnNames) if len(ColumnNames) != 0 else '*'
        # filters
        filters = f'WHERE {" AND ".join(conditions)}' if len(conditions) > 0 else ''
        order = f"ORDER BY {orderBy} {'ASC' if Ascendent else 'DESC'}" if orderBy is not None else ""
        # Generate the SELECT statement using an f-string
        select_stmt = f"SELECT {columns} FROM {TableName} {filters} {order}"
        # select_stmt = f"SELECT {columns} FROM {TableName} WHERE Nom Like ?"
        results = []
        try:
            cursor.execute(select_stmt, CheckValues)
            # Fetch the results
            results = cursor.fetchall()
            nbResults = len(results)
            # trasnpose the list
            if isTransposed:
                results = [list(item) for item in list(zip(*results))]
        except:
            nbResults = 0
        # Commit the changes
        connection.commit()
        # Close the connection
        connection.close()
        return [nbResults, results]
    if __name__ == '__main__':
        path = r"L:\#Prod\Leon\3DWarehouse-Lib\Zago officiel\Zago-Officiel.db"
        # get_database_item()
        db = get_database_item(path, ColumnNames=['Nom', 'Prix'], ColumnConditions=['Prix IS NOT NULL',"Nom LIKE '%lit%' OR Nom LIKE '%rouge%'"], CheckValues=[], TableName= 'Zago_Officiel')
        print(db[-1])
    return_7362F = get_database_item(FilePath=Filepath, ColumnNames=ColumnNames, ColumnConditions=ColumnConditions, CheckValues=CheckValues, TableName=TableName, isTransposed=isTransposed, orderBy=orderBy, Ascendent=Ascendent)
    return [return_7362F[0], return_7362F[1]]


_item_map = dict()


def make_enum_item(_id, name, descr, preview_id, uid):
    lookup = str(_id)+"\0"+str(name)+"\0"+str(descr)+"\0"+str(preview_id)+"\0"+str(uid)
    if not lookup in _item_map:
        _item_map[lookup] = (_id, name, descr, preview_id, uid)
    return _item_map[lookup]


def sna_getdatabase_69E32_BF860(Filepath, ColumnNames, ColumnConditions, CheckValues, TableName, isTransposed, orderBy, Ascendent):
    import sqlite3

    def get_database_item(FilePath: str, ColumnNames, ColumnConditions, CheckValues:list, TableName: str, isTransposed:str = True, orderBy:str = None, Ascendent:bool = True ):
        conditions = ColumnConditions
        if not os.path.isfile(FilePath):
            return [None, None, None]
        connection = sqlite3.connect(FilePath)
        cursor = connection.cursor()
        # Set the condition for the columns
        columns = ','.join(ColumnNames) if len(ColumnNames) != 0 else '*'
        # filters
        filters = f'WHERE {" AND ".join(conditions)}' if len(conditions) > 0 else ''
        order = f"ORDER BY {orderBy} {'ASC' if Ascendent else 'DESC'}" if orderBy is not None else ""
        # Generate the SELECT statement using an f-string
        select_stmt = f"SELECT {columns} FROM {TableName} {filters} {order}"
        # select_stmt = f"SELECT {columns} FROM {TableName} WHERE Nom Like ?"
        results = []
        try:
            cursor.execute(select_stmt, CheckValues)
            # Fetch the results
            results = cursor.fetchall()
            nbResults = len(results)
            # trasnpose the list
            if isTransposed:
                results = [list(item) for item in list(zip(*results))]
        except:
            nbResults = 0
        # Commit the changes
        connection.commit()
        # Close the connection
        connection.close()
        return [nbResults, results]
    if __name__ == '__main__':
        path = r"L:\#Prod\Leon\3DWarehouse-Lib\Zago officiel\Zago-Officiel.db"
        # get_database_item()
        db = get_database_item(path, ColumnNames=['Nom', 'Prix'], ColumnConditions=['Prix IS NOT NULL',"Nom LIKE '%lit%' OR Nom LIKE '%rouge%'"], CheckValues=[], TableName= 'Zago_Officiel')
        print(db[-1])
    return_7362F = get_database_item(FilePath=Filepath, ColumnNames=ColumnNames, ColumnConditions=ColumnConditions, CheckValues=CheckValues, TableName=TableName, isTransposed=isTransposed, orderBy=orderBy, Ascendent=Ascendent)
    return [return_7362F[0], return_7362F[1]]


def sna_word_wrap_34E95_414F3(Text, Width_Threshold):
    string = Text
    threshold = (1 if (Width_Threshold < 1) else Width_Threshold)
    wList = None
    textTowrap = string      
    wrapp = textwrap.TextWrapper(width=threshold) #50 = maximum length       
    wList = wrapp.wrap(text=textTowrap) 
    listout = wList
    return wList


def sna_getdatabase_69E32_9D3D4(Filepath, ColumnNames, ColumnConditions, CheckValues, TableName, isTransposed, orderBy, Ascendent):
    import sqlite3

    def get_database_item(FilePath: str, ColumnNames, ColumnConditions, CheckValues:list, TableName: str, isTransposed:str = True, orderBy:str = None, Ascendent:bool = True ):
        conditions = ColumnConditions
        if not os.path.isfile(FilePath):
            return [None, None, None]
        connection = sqlite3.connect(FilePath)
        cursor = connection.cursor()
        # Set the condition for the columns
        columns = ','.join(ColumnNames) if len(ColumnNames) != 0 else '*'
        # filters
        filters = f'WHERE {" AND ".join(conditions)}' if len(conditions) > 0 else ''
        order = f"ORDER BY {orderBy} {'ASC' if Ascendent else 'DESC'}" if orderBy is not None else ""
        # Generate the SELECT statement using an f-string
        select_stmt = f"SELECT {columns} FROM {TableName} {filters} {order}"
        # select_stmt = f"SELECT {columns} FROM {TableName} WHERE Nom Like ?"
        results = []
        try:
            cursor.execute(select_stmt, CheckValues)
            # Fetch the results
            results = cursor.fetchall()
            nbResults = len(results)
            # trasnpose the list
            if isTransposed:
                results = [list(item) for item in list(zip(*results))]
        except:
            nbResults = 0
        # Commit the changes
        connection.commit()
        # Close the connection
        connection.close()
        return [nbResults, results]
    if __name__ == '__main__':
        path = r"L:\#Prod\Leon\3DWarehouse-Lib\Zago officiel\Zago-Officiel.db"
        # get_database_item()
        db = get_database_item(path, ColumnNames=['Nom', 'Prix'], ColumnConditions=['Prix IS NOT NULL',"Nom LIKE '%lit%' OR Nom LIKE '%rouge%'"], CheckValues=[], TableName= 'Zago_Officiel')
        print(db[-1])
    return_7362F = get_database_item(FilePath=Filepath, ColumnNames=ColumnNames, ColumnConditions=ColumnConditions, CheckValues=CheckValues, TableName=TableName, isTransposed=isTransposed, orderBy=orderBy, Ascendent=Ascendent)
    return [return_7362F[0], return_7362F[1]]


def get_blend_contents(path, data_type):
    if os.path.exists(path):
        with bpy.data.libraries.load(path) as (data_from, data_to):
            return getattr(data_from, data_type)
    return []


def property_exists(prop_path, glob, loc):
    try:
        eval(prop_path, glob, loc)
        return True
    except:
        return False


def load_preview_icon(path):
    global _icons
    if not path in _icons:
        if os.path.exists(path):
            _icons.load(path, path, "IMAGE")
        else:
            return 0
    return _icons[path].icon_id


def sna_word_wrap_34E95_1348A(Text, Width_Threshold):
    string = Text
    threshold = (1 if (Width_Threshold < 1) else Width_Threshold)
    wList = None
    textTowrap = string      
    wrapp = textwrap.TextWrapper(width=threshold) #50 = maximum length       
    wList = wrapp.wrap(text=textTowrap) 
    listout = wList
    return wList


def sna_node_58D55_5B174(Modal_Event_Mouse_Region, Move_3D_Cursor):
    Modal_Event_Mouse_Region = Modal_Event_Mouse_Region
    Move_3D_Cursor = Move_3D_Cursor
    best_obj = None
    best_hit = None
    out_face_index = None
    best_normal = None
    coord = Modal_Event_Mouse_Region
    move_3d_cursor = Move_3D_Cursor
    best_obj = None
    hit_world = None
    out_face_index = None
    context = bpy.context
    # get the context arguments
    scene = context.scene
    region = context.region
    rv3d = context.region_data
    #coord = event.mouse_region_x, event.mouse_region_y
    act_obj = bpy.context.active_object
    # get the ray from the viewport and mouse
    view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
    ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
    ray_target = ray_origin + view_vector

    def visible_objects_and_duplis():
        """Loop over (object, matrix) pairs (mesh only)"""
        depsgraph = context.evaluated_depsgraph_get()
        for dup in depsgraph.object_instances:
            if dup.is_instance:  # Real dupli instance
                obj = dup.instance_object
                yield (obj, dup.matrix_world.copy())
            else:  # Usual object
                obj = dup.object
                yield (obj, obj.matrix_world.copy())
    out_face_index=0
    out_edge_index=0

    def obj_ray_cast(obj, matrix):
        """Wrapper for ray casting that moves the ray into object space"""
        # get the ray relative to the object
        matrix_inv = matrix.inverted()
        ray_origin_obj = matrix_inv @ ray_origin
        ray_target_obj = matrix_inv @ ray_target
        ray_direction_obj = ray_target_obj - ray_origin_obj
        # cast the ray
        success, location, normal, face_index = obj.ray_cast(ray_origin_obj, ray_direction_obj)
        if success:
            out_face_index = face_index
            return location, normal, face_index
        else:
            return None, None, None
    # cast rays and find the closest object
    best_length_squared = -1.0
    best_obj = None
    best_hit = None
    best_normal = None
    for obj, matrix in visible_objects_and_duplis():
            if obj.type == 'MESH':
                hit, normal, face_index = obj_ray_cast(obj, matrix)
                if hit is not None:
                    hit_world = matrix @ hit
                    length_squared = (hit_world - ray_origin).length_squared
                    if best_obj is None or length_squared < best_length_squared:
                        best_length_squared = length_squared
                        best_obj_name = obj.name
                        best_obj = obj
                        out_face_index = face_index
                        best_hit = hit_world
                        best_normal = normal
                if move_3d_cursor == True and best_hit != None:
                    scene.cursor.location = best_hit
    # return [best_obj, best_hit, out_face_index, best_normal]
    return [best_obj, best_hit, out_face_index, best_normal]


_CB8FD_running = False
class SNA_OT_Batch_Render_Cb8Fd(bpy.types.Operator):
    bl_idname = "sna.batch_render_cb8fd"
    bl_label = "Batch Render"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    cursor = "CROSSHAIR"
    _handle = None
    _event = {}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        if not False or context.area.spaces[0].bl_rna.identifier == 'SpaceNodeEditor':
            return not False
        return False

    def save_event(self, event):
        event_options = ["type", "value", "alt", "shift", "ctrl", "oskey", "mouse_region_x", "mouse_region_y", "mouse_x", "mouse_y", "pressure", "tilt"]
        if bpy.app.version >= (3, 2, 1):
            event_options += ["type_prev", "value_prev"]
        for option in event_options: self._event[option] = getattr(event, option)

    def draw_callback_px(self, context):
        event = self._event
        if event.keys():
            event = dotdict(event)
            try:
                pass
            except Exception as error:
                print(error)

    def execute(self, context):
        global _CB8FD_running
        _CB8FD_running = False
        context.window.cursor_set("DEFAULT")
        bpy.context.scene.timeline_markers.clear()
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}

    def modal(self, context, event):
        global _CB8FD_running
        if not context.area or not _CB8FD_running:
            self.execute(context)
            return {'CANCELLED'}
        self.save_event(event)
        context.window.cursor_set('CROSSHAIR')
        try:
            if (batch_render['sna_index'] < len(sna_camera_objects_77160_A06F5(bpy.data.objects))):
                if eval("bpy.app.is_job_running('RENDER')"):
                    pass
                else:
                    bpy.context.scene.timeline_markers.clear()
                    marker_1292C = bpy.context.scene.timeline_markers.new(name=sna_camera_objects_77160_A06F5(bpy.data.objects)[batch_render['sna_index']].name, frame=bpy.context.scene.frame_current, )
                    marker_1292C.camera = sna_camera_objects_77160_A06F5(bpy.data.objects)[batch_render['sna_index']]
                    bpy.context.scene.render.filepath = '//render/test_' + getattr(sna_camera_objects_77160_A06F5(bpy.data.objects)[batch_render['sna_index']], 'name', None)
                    bpy.ops.render.render('INVOKE_DEFAULT', write_still=False)
                    batch_render['sna_index'] += 0
            else:
                if event.type in ['RIGHTMOUSE', 'ESC']:
                    self.execute(context)
                    return {'CANCELLED'}
                self.execute(context)
                return {"FINISHED"}
        except Exception as error:
            print(error)
        if event.type in ['RIGHTMOUSE', 'ESC']:
            self.execute(context)
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        global _CB8FD_running
        if _CB8FD_running:
            _CB8FD_running = False
            return {'FINISHED'}
        else:
            self.save_event(event)
            self.start_pos = (event.mouse_x, event.mouse_y)
            batch_render['sna_index'] = 0
            batch_render['sna_index'] = 0
            context.window_manager.modal_handler_add(self)
            _CB8FD_running = True
            return {'RUNNING_MODAL'}


def sna_loadimages_9657B():
    bottom['sna_cams'] = []
    for i_702F6 in range(len(sna_camera_objects_77160_0D1CD(bpy.data.objects))):
        if os.path.exists(os.path.join(bpy.context.scene.sna_tmpfolder,sna_camera_objects_77160_0D1CD(bpy.data.objects)[i_702F6].name + '.png')):
            bpy.ops.image.open('INVOKE_DEFAULT', filepath=os.path.join(bpy.context.scene.sna_tmpfolder,sna_camera_objects_77160_0D1CD(bpy.data.objects)[i_702F6].name + '.png'))


def sna_camera_objects_77160(collection_Input):
    bottom['sna_cams'] = []
    for i_F1733 in range(len(collection_Input)):
        if collection_Input[i_F1733].type == 'CAMERA':
            bottom['sna_cams'].append(collection_Input[i_F1733])
    return bottom['sna_cams']


def sna_setviewbycamera_FE2AD(Camera):
    if (property_exists("find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).spaces.active.region_3d.view_location", globals(), locals()) and property_exists("find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).spaces.active.region_3d.view_rotation", globals(), locals())):
        find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).spaces.active.region_3d.view_location = Camera.location
        find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).spaces.active.region_3d.view_rotation = eval("Camera.rotation_euler.to_quaternion()")
        find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).spaces.active.region_3d.view_distance = 0.0
        find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).spaces[0].lens = float(Camera.data.lens * 2.0)
        bpy.context.scene.render.resolution_x = find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).regions[-1].width
        bpy.context.scene.render.resolution_y = find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).regions[-1].height


def sna_isbetween_7B8B8(min, max, value):
    return ((value >= min) and (value <= max))


def sna_isinsidebox_EE952(Mouse_region, button_location, width, height):
    return (sna_isbetween_7B8B8(button_location[0], float(button_location[0] + width), Mouse_region[0]) and sna_isbetween_7B8B8(button_location[1], float(button_location[1] + height), Mouse_region[1]))


def sna_toggle_plafond_95678(hide):
    if (property_exists("bpy.data.collections[bpy.context.preferences.addons['configurateur_deco'].preferences.sna_plafondcollectionname].hide_viewport", globals(), locals()) and property_exists("bpy.data.collections[bpy.context.preferences.addons['configurateur_deco'].preferences.sna_plafondcollectionname].hide_render", globals(), locals())):
        if hide:
            bpy.data.collections[bpy.context.preferences.addons['configurateur_deco'].preferences.sna_plafondcollectionname].hide_render = eval('True')
            bpy.data.collections[bpy.context.preferences.addons['configurateur_deco'].preferences.sna_plafondcollectionname].hide_viewport = eval('True')
        else:
            bpy.data.collections[bpy.context.preferences.addons['configurateur_deco'].preferences.sna_plafondcollectionname].hide_render = eval('False')
            bpy.data.collections[bpy.context.preferences.addons['configurateur_deco'].preferences.sna_plafondcollectionname].hide_viewport = eval('False')


def sna_showscreenshots_3AF4B():
    if (len(sna_camera_objects_77160_FF824(bpy.data.objects)) == len(bpy.context.scene.sna_custombuttons)):
        for i_B00C4 in range(len(bpy.context.scene.sna_custombuttons)):
            coords = (  (bpy.context.scene.sna_custombuttons[i_B00C4].location[0], bpy.context.scene.sna_custombuttons[i_B00C4].location[1])   , (bpy.context.scene.sna_custombuttons[i_B00C4].location[0]+bpy.context.scene.sna_custombuttons[i_B00C4].width,bpy.context.scene.sna_custombuttons[i_B00C4].location[1])  ,  (bpy.context.scene.sna_custombuttons[i_B00C4].location[0]+bpy.context.scene.sna_custombuttons[i_B00C4].width, bpy.context.scene.sna_custombuttons[i_B00C4].location[1]+float(bpy.context.scene.sna_custombuttons[i_B00C4].width / 2.0))  ,   (bpy.context.scene.sna_custombuttons[i_B00C4].location[0], bpy.context.scene.sna_custombuttons[i_B00C4].location[1]+float(bpy.context.scene.sna_custombuttons[i_B00C4].width / 2.0))   )
            bpy.data.images.load(filepath=bpy.context.scene.sna_custombuttons[i_B00C4].image, check_existing=True, )

            def get_img_name():
                this = os.path.basename(bpy.context.scene.sna_custombuttons[i_B00C4].image)
                for i in range(len(bpy.data.images)):
                    if bpy.data.images[i].name == bpy.data.images[this].name:
                        return bpy.data.images[i]
            texture = gpu.texture.from_image(get_img_name())
            shader = gpu.shader.from_builtin('2D_IMAGE')
            batch = gpu_extras.batch.batch_for_shader(
                shader, 'TRI_FAN',
                {
                    "pos": coords,
                    "texCoord": ((0, 0), (1, 0), (1, 1), (0, 1)),
                },
            )
            shader.bind()
            gpu.state.blend_set('ALPHA')
            shader.uniform_sampler("image", texture)
            batch.draw(shader)
    else:
        sna_loadimages_9657B()


def sna_precompute_buttons_B1B27(offset):
    bottom['sna_button_gap'] = 50
    bottom['sna_button_width'] = 100
    bpy.context.scene.sna_custombuttons.clear()
    for i_00086 in range(len(sna_camera_objects_77160_0E8F1(bpy.context.scene.objects))):
        item_8AFFD = bpy.context.scene.sna_custombuttons.add()
        bottom['sna_button_width'] = bpy.context.preferences.addons['configurateur_deco'].preferences.sna_previewwidthdefault
        bottom['sna_button_height'] = int(bottom['sna_button_width'] * float(bpy.context.scene.render.resolution_y / bpy.context.scene.render.resolution_x))
        item_8AFFD.width = bpy.context.preferences.addons['configurateur_deco'].preferences.sna_previewwidthdefault
        item_8AFFD.height = int(bottom['sna_button_width'] * float(bpy.context.scene.render.resolution_y / bpy.context.scene.render.resolution_x))
        item_8AFFD.location = (float(float(float(bottom['sna_button_width'] + bottom['sna_button_gap']) * i_00086) + float(float(float(bpy.context.scene.sna_d_area_width / 2.0) - float(int(int(len(sna_camera_objects_77160_0E8F1(bpy.context.scene.objects)) * bottom['sna_button_width']) + int(int(len(sna_camera_objects_77160_0E8F1(bpy.context.scene.objects)) - -1.0) * bottom['sna_button_gap'])) / 2.0)) + offset)), 25.0)
        item_8AFFD.camera = sna_camera_objects_77160_0E8F1(bpy.context.scene.objects)[i_00086]
        item_8AFFD.image = bpy.path.abspath(bpy.data.images[sna_camera_objects_77160_0E8F1(bpy.context.scene.objects)[i_00086].name_full + '.png'].filepath)


_3A2A1_running = False
class SNA_OT_Click_Check_3A2A1(bpy.types.Operator):
    bl_idname = "sna.click_check_3a2a1"
    bl_label = "click check"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    cursor = "DEFAULT"
    _handle = None
    _event = {}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        if not True or context.area.spaces[0].bl_rna.identifier == 'SpaceView3D':
            return not False
        return False

    def save_event(self, event):
        event_options = ["type", "value", "alt", "shift", "ctrl", "oskey", "mouse_region_x", "mouse_region_y", "mouse_x", "mouse_y", "pressure", "tilt"]
        if bpy.app.version >= (3, 2, 1):
            event_options += ["type_prev", "value_prev"]
        for option in event_options: self._event[option] = getattr(event, option)

    def draw_callback_px(self, context):
        event = self._event
        if event.keys():
            event = dotdict(event)
            try:
                sna_showscreenshots_3AF4B()
            except Exception as error:
                print(error)

    def execute(self, context):
        global _3A2A1_running
        _3A2A1_running = False
        context.window.cursor_set("DEFAULT")
        bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
        bottom['sna_isbottomdrawn'] = eval('False')

        def delayed_87DCF():
            area_EDE4B = find_area_by_type(bpy.context.screen, 'VIEW_3D', 0)
            region_EDE4B = find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).regions[-1]
            with bpy.context.temp_override(area=area_EDE4B, region=region_EDE4B, ):
                bpy.ops.sna.click_check_3a2a1('INVOKE_DEFAULT', )
        bpy.app.timers.register(delayed_87DCF, first_interval=0.20000000298023224)
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}

    def modal(self, context, event):
        global _3A2A1_running
        if not context.area or not _3A2A1_running:
            self.execute(context)
            return {'CANCELLED'}
        self.save_event(event)
        context.area.tag_redraw()
        context.window.cursor_set('DEFAULT')
        try:
            sna_precompute_buttons_B1B27(0.0)
            if (event.type == 'LEFTMOUSE' and event.value == 'PRESS' and event.alt == False and event.shift == False and event.ctrl == False):
                for i_79F2D in range(len(bpy.context.scene.sna_custombuttons)):
                    if sna_isinsidebox_EE952((event.mouse_region_x, event.mouse_region_y), bpy.context.scene.sna_custombuttons[i_79F2D].location, bpy.context.scene.sna_custombuttons[i_79F2D].width, bpy.context.scene.sna_custombuttons[i_79F2D].height):
                        sna_setviewbycamera_FE2AD(bpy.context.scene.sna_custombuttons[i_79F2D].camera)
                        sna_toggle_plafond_95678((bpy.context.preferences.addons['configurateur_deco'].preferences.sna_topcamname == getattr(bpy.context.scene.sna_custombuttons[i_79F2D].camera, 'name', None)))

                        def delayed_BCC4F():
                            bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
                        bpy.app.timers.register(delayed_BCC4F, first_interval=0.20000000298023224)
            if (property_exists("find_area_by_type(bpy.context.screen, 'VIEW_3D', 0)", globals(), locals()) and property_exists("find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).regions[-1].width", globals(), locals()) and property_exists("bpy.context.scene.sna_d_area_width", globals(), locals())):
                if bool(int(eval("abs(find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).regions[-1].width-bpy.context.scene.sna_d_area_width) >= 3.0"))):
                    bpy.context.scene.sna_d_area_width = find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).regions[-1].width
        except Exception as error:
            print(error)
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        global _3A2A1_running
        if _3A2A1_running:
            _3A2A1_running = False
            return {'FINISHED'}
        else:
            self.save_event(event)
            self.start_pos = (event.mouse_x, event.mouse_y)
            bottom['sna_isbottomdrawn'] = eval('True')
            args = (context,)
            self._handle = bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px, args, 'WINDOW', 'POST_PIXEL')
            context.window_manager.modal_handler_add(self)
            _3A2A1_running = True
            return {'RUNNING_MODAL'}


@persistent
def load_post_handler_FDB46(dummy):

    def delayed_27031():
        if bottom['sna_isbottomdrawn']:
            pass
        else:
            if property_exists("find_area_by_type(bpy.context.screen, 'VIEW_3D', 0)", globals(), locals()):
                area_63EEA = find_area_by_type(bpy.context.screen, 'VIEW_3D', 0)
                region_63EEA = find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).regions[-1]
                with bpy.context.temp_override(area=area_63EEA, region=region_63EEA, ):
                    bpy.ops.sna.click_check_3a2a1('INVOKE_DEFAULT', )
        if False:
            return None
        return 5.0
    bpy.app.timers.register(delayed_27031, first_interval=5.0)


class SNA_OT_Clean_Top_Bar_8853A(bpy.types.Operator):
    bl_idname = "sna.clean_top_bar_8853a"
    bl_label = "clean_top_bar"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_add_to_topbar_ht_upper_bar_8C538(self, context):
    if not (False):
        layout = self.layout
        if bpy.context.scene.sna_globalhide:
            layout.separator(factor=500000.0)


def sna_add_to_view3d_pt_tools_active_6EE17(self, context):
    if not (False):
        layout = self.layout
        if bpy.context.scene.sna_globalhide:
            layout.separator(factor=50000.0)


def sna_hide_tool_settings_3d_view_F85D8():
    for i_52F4E in range(len(bpy.data.screens)):
        for i_3B10B in range(len(find_areas_of_type(bpy.data.screens[i_52F4E], 'VIEW_3D'))):
            if (property_exists("find_areas_of_type(bpy.data.screens[i_52F4E], 'VIEW_3D')[i_3B10B]", globals(), locals()) and property_exists("find_areas_of_type(bpy.data.screens[i_52F4E], 'VIEW_3D')[i_3B10B].spaces[0].show_region_tool_header", globals(), locals())):
                find_areas_of_type(bpy.data.screens[i_52F4E], 'VIEW_3D')[i_3B10B].spaces[0].show_region_tool_header = False


def sna_turn_off_overlays_9F185():
    for i_DD0ED in range(len(bpy.data.screens)):
        if property_exists("bpy.data.screens[i_DD0ED]", globals(), locals()):
            for i_49632 in range(len(find_areas_of_type(bpy.data.screens[i_DD0ED], 'VIEW_3D'))):
                if property_exists("find_areas_of_type(bpy.data.screens[i_DD0ED], 'VIEW_3D')[i_49632]", globals(), locals()):
                    for i_3FE75 in range(len(eval("find_areas_of_type(bpy.data.screens[i_DD0ED], 'VIEW_3D')[i_49632].spaces[0].overlay.__dir__()"))):
                        if hasattr(find_areas_of_type(bpy.data.screens[i_DD0ED], 'VIEW_3D')[i_49632].spaces[0].overlay, eval("find_areas_of_type(bpy.data.screens[i_DD0ED], 'VIEW_3D')[i_49632].spaces[0].overlay.__dir__()")[i_3FE75]):
                            if eval("type(getattr(find_areas_of_type(bpy.data.screens[i_DD0ED], 'VIEW_3D')[i_49632].spaces[0].overlay, find_areas_of_type(bpy.data.screens[i_DD0ED], 'VIEW_3D')[i_49632].spaces[0].overlay.__dir__()[i_3FE75], None)) ==  bool"):
                                setattr(find_areas_of_type(bpy.data.screens[i_DD0ED], 'VIEW_3D')[i_49632].spaces[0].overlay, eval("find_areas_of_type(bpy.data.screens[i_DD0ED], 'VIEW_3D')[i_49632].spaces[0].overlay.__dir__()")[i_3FE75], (eval('True') if eval("find_areas_of_type(bpy.data.screens[i_DD0ED], 'VIEW_3D')[i_49632].spaces[0].overlay.__dir__()")[i_3FE75] in ['show_outline_selected', 'show_overlays'] else eval('False')))
                for i_ADB39 in range(len(eval("find_areas_of_type(bpy.data.screens[i_DD0ED], 'VIEW_3D')[i_49632].spaces[0].__dir__()"))):
                    if hasattr(find_areas_of_type(bpy.data.screens[i_DD0ED], 'VIEW_3D')[i_49632].spaces[0], eval("find_areas_of_type(bpy.data.screens[i_DD0ED], 'VIEW_3D')[i_49632].spaces[0].__dir__()")[i_ADB39]):
                        if eval("type(getattr(find_areas_of_type(bpy.data.screens[i_DD0ED], 'VIEW_3D')[i_49632].spaces[0], find_areas_of_type(bpy.data.screens[i_DD0ED], 'VIEW_3D')[i_49632].spaces[0].__dir__()[i_ADB39], None)) ==  bool"):
                            setattr(find_areas_of_type(bpy.data.screens[i_DD0ED], 'VIEW_3D')[i_49632].spaces[0], eval("find_areas_of_type(bpy.data.screens[i_DD0ED], 'VIEW_3D')[i_49632].spaces[0].__dir__()")[i_ADB39], (eval('True') if eval("find_areas_of_type(bpy.data.screens[i_DD0ED], 'VIEW_3D')[i_49632].spaces[0].__dir__()")[i_ADB39] in ['show_object_viewport_mesh', 'show_object_viewport_curve', 'show_object_viewport_light', 'show_object_select_mesh', 'show_object_select_curve', 'show_object_select_camera', 'show_region_header'] else False))


def sna_updatepriceondelete_D9D70(Object):
    if ('sna_objectpointer' in Object and bool(eval("Object['sna_objectpointer']['genericproduct']['price']"))):
        bpy.context.scene.sna_prixpiece = float(bpy.context.scene.sna_prixpiece - eval("Object['sna_objectpointer']['genericproduct']['price']"))


def sna_tempcamfromview_2491F():
    if (None != boutons_de_fonctions['sna_tmpcameraforrender']):
        bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
        boutons_de_fonctions['sna_tmpcameraforrender'].select_set(state=False, view_layer=bpy.context.view_layer, )
        bpy.ops.object.delete(use_global=False, confirm=False)
    bpy.ops.object.camera_add('INVOKE_DEFAULT', location=find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).spaces.active.region_3d.view_location, rotation=eval("find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).spaces.active.region_3d.view_rotation.to_euler()"))
    if property_exists("bpy.context.view_layer.objects.active.data.lens", globals(), locals()):
        bpy.context.view_layer.objects.active.data.lens = float(find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).spaces[0].lens / 2.0)
        boutons_de_fonctions['sna_tmpcameraforrender'] = bpy.context.view_layer.objects.active


class SNA_OT_Calculer_Cea9D(bpy.types.Operator):
    bl_idname = "sna.calculer_cea9d"
    bl_label = "Calculer"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_filepath: bpy.props.StringProperty(name='Filepath', description='Nom de rendu', options={'HIDDEN'}, default='//', subtype='FILE_PATH', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.render.engine = 'CYCLES'
        bpy.context.scene.render.filepath = '//'
        sna_rendersetup_98487()
        sna_tempcamfromview_2491F()
        if (None != boutons_de_fonctions['sna_tmpcameraforrender']):
            sna_make_active_camera_B3C8C(boutons_de_fonctions['sna_tmpcameraforrender'])
            bpy.ops.render.render('INVOKE_DEFAULT', write_still=eval('True'), use_viewport=eval('True'))

            def delayed_BBCE6():
                bpy.data.objects.remove(object=boutons_de_fonctions['sna_tmpcameraforrender'], do_unlink=eval('True'), do_id_user=eval('True'), do_ui_user=eval('True'), )
            bpy.app.timers.register(delayed_BBCE6, first_interval=2.0)
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        layout.label(text='Dossier de destination', icon_value=0)
        layout.prop(self, 'sna_filepath', text='', icon_value=0, emboss=eval('True'))

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)


def sna_add_to_view3d_ht_tool_header_4990D(self, context):
    if not (False):
        layout = self.layout
        if bpy.context.scene.sna_globalhide:
            layout.separator(factor=5000.0)


def sna_add_to_image_ht_header_1EA36(self, context):
    if not (False):
        layout = self.layout
        layout.separator(factor=5000.0)


class SNA_OT_Terminer_7Fdfe(bpy.types.Operator):
    bl_idname = "sna.terminer_7fdfe"
    bl_label = "Terminer"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.wm.batchrender('INVOKE_DEFAULT', )
        sna_listtojson_0ED0B()
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        box_9CB88 = layout.box()
        box_9CB88.alert = eval('False')
        box_9CB88.enabled = eval('True')
        box_9CB88.active = eval('True')
        box_9CB88.use_property_split = True
        box_9CB88.use_property_decorate = True
        box_9CB88.alignment = 'Expand'.upper()
        box_9CB88.scale_x = 1.0
        box_9CB88.scale_y = 1.0
        if not eval('True'): box_9CB88.operator_context = "EXEC_DEFAULT"
        box_9CB88.label(text="Veuillez attendre la finalisation de l'image 360 \n" + " et l'image plan.", icon_value=678)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=500)


def sna_add_to_view3d_pt_tools_active_B1403(self, context):
    if not (False):
        layout = self.layout
        if bpy.context.scene.sna_globalhide:
            layout.separator(factor=1.0)


def sna_clean_t_panel_B9F40():

    def delayed_4D444():
        for i_399EC in range(len(bpy.data.screens)):
            for i_0F836 in range(len(find_areas_of_type(bpy.data.screens[i_399EC], 'VIEW_3D'))):
                find_areas_of_type(bpy.data.screens[i_399EC], 'VIEW_3D')[i_0F836].spaces[0].show_region_ui = False
                find_areas_of_type(bpy.data.screens[i_399EC], 'VIEW_3D')[i_0F836].id_data.show_statusbar = False
        if  not bpy.context.scene.sna_globalhide:
            return None
        return 0.5
    bpy.app.timers.register(delayed_4D444, first_interval=0.0)


def sna_rendersetup_98487():
    if (property_exists("bpy.context.scene.cycles.use_adaptive_sampling", globals(), locals()) and property_exists("bpy.context.scene.cycles.samples", globals(), locals()) and property_exists("bpy.context.scene.cycles.time_limit", globals(), locals()) and property_exists("bpy.context.scene.cycles.use_denoising", globals(), locals()) and property_exists("bpy.context.scene.cycles.denoiser", globals(), locals())):
        bpy.context.scene.cycles.use_adaptive_sampling = eval('False')
        bpy.context.scene.cycles.samples = 1000
        bpy.context.scene.cycles.time_limit = bpy.context.preferences.addons['configurateur_deco'].preferences.sna_calcultimethreshold
        bpy.context.scene.cycles.use_denoising = eval('True')
        bpy.context.scene.cycles.denoiser = 'OPTIX'
        bpy.context.scene.render.resolution_percentage = 100
        if bpy.context and bpy.context.screen:
            for a in bpy.context.screen.areas:
                a.tag_redraw()


class SNA_OT_Effacer_82A47(bpy.types.Operator):
    bl_idname = "sna.effacer_82a47"
    bl_label = "Effacer"
    bl_description = "Effacer"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not eval("len(bpy.context.view_layer.objects.selected) == 0")

    def execute(self, context):
        zone_de_recherche['sna_debut'] = bool(1)
        if (eval("len(bpy.context.view_layer.objects.selected) > 0") and property_exists("bpy.context.view_layer.objects.active", globals(), locals())):
            sna_updatepriceondelete_D9D70(bpy.context.view_layer.objects.active)
            bpy.ops.object.select_all(action='DESELECT')
            bpy.context.view_layer.objects.active.select_set(state=eval('True'), view_layer=bpy.context.view_layer, )
            bpy.ops.object.delete(use_global=eval('True'), confirm=eval('False'))
            bpy.ops.outliner.orphans_purge(do_local_ids=eval('True'), do_linked_ids=eval('True'), do_recursive=eval('True'))
            sna_main_bottom_D6C7A()
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)


def sna_checkoriginal_EE8B5():
    if (bpy.data.filepath.replace('_original', '') != bpy.data.filepath):
        if os.path.exists(bpy.data.filepath.replace('_original', '')):
            bpy.ops.wm.save_as_mainfile(filepath=bpy.data.filepath.replace('_original', ''), check_existing=False, filemode=0)


@persistent
def load_post_handler_B1103(dummy):
    sna_checkoriginal_EE8B5()


class SNA_OT_Reinitialiser_3B8Dd(bpy.types.Operator):
    bl_idname = "sna.reinitialiser_3b8dd"
    bl_label = "Reinitialiser"
    bl_description = "Réinitialiser"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if os.path.exists(bpy.data.filepath.replace(os.path.splitext(bpy.data.filepath)[1], '_original' + os.path.splitext(bpy.data.filepath)[1])):
            bpy.ops.wm.open_mainfile(filepath=bpy.data.filepath.replace(os.path.splitext(bpy.data.filepath)[1], '_original' + os.path.splitext(bpy.data.filepath)[1]))
        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)


def sna_rotatebuttons_E0B3D(layout_function, ):
    row_DF177 = layout_function.row(heading='', align=True)
    row_DF177.alert = False
    row_DF177.enabled = eval("len(bpy.context.view_layer.objects.selected) != 0")
    row_DF177.active = eval("len(bpy.context.view_layer.objects.selected) != 0")
    row_DF177.use_property_split = False
    row_DF177.use_property_decorate = False
    row_DF177.scale_x = 1.0
    row_DF177.scale_y = 1.0
    row_DF177.alignment = 'Expand'.upper()
    if not True: row_DF177.operator_context = "EXEC_DEFAULT"
    op = row_DF177.operator('sna.rotate_39ac0', text='', icon_value=715, emboss=eval('True'), depress=eval('False'))
    op.sna_clockwise = eval('False')
    op = row_DF177.operator('sna.rotate_39ac0', text='', icon_value=716, emboss=eval('True'), depress=eval('False'))
    op.sna_clockwise = eval('True')


def sna_movebuttons_B8309(layout_function, ):
    row_97E79 = layout_function.row(heading='', align=True)
    row_97E79.alert = False
    row_97E79.enabled = eval("len(bpy.context.view_layer.objects.selected) != 0")
    row_97E79.active = eval("len(bpy.context.view_layer.objects.selected) != 0")
    row_97E79.use_property_split = False
    row_97E79.use_property_decorate = False
    row_97E79.scale_x = 1.0
    row_97E79.scale_y = 1.0
    row_97E79.alignment = 'Expand'.upper()
    if not True: row_97E79.operator_context = "EXEC_DEFAULT"
    op = row_97E79.operator('sna.move_ad916', text='', icon_value=6, emboss=eval('True'), depress=eval('False'))
    op.sna_direction = 'left'
    op = row_97E79.operator('sna.move_ad916', text='', icon_value=4, emboss=eval('True'), depress=eval('False'))
    op.sna_direction = 'right'
    op = row_97E79.operator('sna.move_ad916', text='', icon_value=7, emboss=eval('True'), depress=eval('False'))
    op.sna_direction = 'forward'
    op = row_97E79.operator('sna.move_ad916', text='', icon_value=5, emboss=eval('True'), depress=eval('False'))
    op.sna_direction = 'backward'


class SNA_OT_Move_Ad916(bpy.types.Operator):
    bl_idname = "sna.move_ad916"
    bl_label = "move"
    bl_description = "Déplacer"
    bl_options = {"REGISTER", "UNDO"}

    def sna_direction_enum_items(self, context):
        return [("No Items", "No Items", "No generate enum items node found to create items!", "ERROR", 0)]
    sna_direction: bpy.props.EnumProperty(name='direction', description='', items=[('left', 'left', '', 0, 0), ('right', 'right', '', 0, 1), ('forward', 'forward', '', 0, 2), ('backward', 'backward', '', 0, 3)])

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        boutons_de_fonctions_plus['sna_xmove'] = 0.0
        boutons_de_fonctions_plus['sna_ymove'] = 0.0
        if (property_exists("bpy.context.view_layer.objects.active", globals(), locals()) and property_exists("bpy.context.view_layer.objects.active.sna_objectpointer.genericproduct.id", globals(), locals()) and eval("bpy.context.view_layer.objects.active.sna_objectpointer.genericproduct.id != ''")):
            if self.sna_direction == "left":
                boutons_de_fonctions_plus['sna_xmove'] = float(bpy.context.preferences.addons['configurateur_deco'].preferences.sna_movedistance * -1.0)
            elif self.sna_direction == "right":
                boutons_de_fonctions_plus['sna_xmove'] = bpy.context.preferences.addons['configurateur_deco'].preferences.sna_movedistance
            elif self.sna_direction == "forward":
                boutons_de_fonctions_plus['sna_ymove'] = bpy.context.preferences.addons['configurateur_deco'].preferences.sna_movedistance
            elif self.sna_direction == "backward":
                boutons_de_fonctions_plus['sna_ymove'] = float(bpy.context.preferences.addons['configurateur_deco'].preferences.sna_movedistance * -1.0)
            else:
                boutons_de_fonctions_plus['sna_xmove'] = 0.0
                boutons_de_fonctions_plus['sna_ymove'] = 0.0
            exec('from mathutils import Vector')
            return_35E49 = bpy.context.view_layer.objects.active.rotation_euler.to_matrix() @ Vector((boutons_de_fonctions_plus['sna_xmove'], boutons_de_fonctions_plus['sna_ymove'], 0.0))
            bpy.context.view_layer.objects.active.location = tuple(mathutils.Vector(bpy.context.view_layer.objects.active.location) + mathutils.Vector(return_35E49))
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


@persistent
def load_pre_handler_AB2EC(dummy):
    area_85F93 = find_area_by_type(bpy.context.screen, 'VIEW_3D', 0)
    with bpy.context.temp_override(area=area_85F93, ):
        bpy.ops.wm.tool_set_by_id('INVOKE_DEFAULT', name='builtin.cursor')


class SNA_OT_Rotate_39Ac0(bpy.types.Operator):
    bl_idname = "sna.rotate_39ac0"
    bl_label = "rotate"
    bl_description = "Tourner"
    bl_options = {"REGISTER", "UNDO"}
    sna_clockwise: bpy.props.BoolProperty(name='clockwise', description='', default=False)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.view_layer.objects.active:
            boutons_de_fonctions_plus['sna_preveuler'] = list(bpy.context.view_layer.objects.active.rotation_euler)
            area_5C060 = find_area_by_type(bpy.context.screen, 'VIEW_3D', 0)
            with bpy.context.temp_override(area=area_5C060, ):
                bpy.ops.transform.rotate(value=(bpy.context.preferences.addons['configurateur_deco'].preferences.sna_rotationangle if self.sna_clockwise else float(bpy.context.preferences.addons['configurateur_deco'].preferences.sna_rotationangle * -1.0)), orient_axis='Z', orient_type='LOCAL')
                bpy.context.view_layer.objects.active.delta_rotation_euler = tuple(mathutils.Vector(bpy.context.view_layer.objects.active.delta_rotation_euler) + mathutils.Vector(tuple(mathutils.Vector(bpy.context.view_layer.objects.active.rotation_euler) - mathutils.Vector(tuple(boutons_de_fonctions_plus['sna_preveuler'])))))
                bpy.context.view_layer.objects.active.rotation_euler = tuple(boutons_de_fonctions_plus['sna_preveuler'])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_getmats_53367():
    importedproducts['sna_mat'] = []
    for i_F8315 in range(len(bpy.data.materials)):
        if (property_exists("bpy.data.materials[i_F8315].sna_materialpointer.genericproduct.id", globals(), locals()) and eval("bpy.data.materials[i_F8315].sna_materialpointer.genericproduct.id != ''") and eval("bpy.data.materials[i_F8315].users > 1")):
            importedproducts['sna_mat'].append(bpy.data.materials[i_F8315].sna_materialpointer.genericproduct.id)
    return [importedproducts['sna_mat'], sna_getdatabase_69E32_DDE5A(os.path.join(os.path.dirname(__file__), 'assets', 'Materials.db'), ['Nom'], ["ID IN ('" + "','".join(importedproducts['sna_mat']) + "')"], [], 'Material', True, 'Nom', False)[1][0]]


def sna_get3ds_22CBA():
    importedproducts['sna_ids'] = []
    importedproducts['sna_price3d'] = []
    importedproducts['sna_dictionnary3d'] = None
    importedproducts['sna_dictionnary3d'] = eval("dict()")
    for i_32BB9 in range(len(bpy.context.scene.objects)):
        if (property_exists("bpy.context.scene.objects[i_32BB9].sna_objectpointer.genericproduct.id", globals(), locals()) and eval("bpy.context.scene.objects[i_32BB9].sna_objectpointer.genericproduct.id != ''")):
            importedproducts['sna_ids'].append(bpy.context.scene.objects[i_32BB9].sna_objectpointer.genericproduct.id)
            importedproducts['sna_price3d'].append(bpy.context.scene.objects[i_32BB9].sna_objectpointer.genericproduct.price)
            return_8ED1E = importedproducts['sna_dictionnary3d'][bpy.context.scene.objects[i_32BB9].sna_objectpointer.genericproduct.id] ={'price': bpy.context.scene.objects[i_32BB9].sna_objectpointer.genericproduct.price, 'n': 1} if  not importedproducts['sna_dictionnary3d'].get(bpy.context.scene.objects[i_32BB9].sna_objectpointer.genericproduct.id) else {'price': bpy.context.scene.objects[i_32BB9].sna_objectpointer.genericproduct.price, 'n': importedproducts['sna_dictionnary3d'][bpy.context.scene.objects[i_32BB9].sna_objectpointer.genericproduct.id]['n']+1} 
            return_34DB5 = importedproducts['sna_dictionnary3d'][bpy.context.scene.objects[i_32BB9].sna_objectpointer.genericproduct.id]['name'] = bpy.context.scene.objects[i_32BB9].sna_objectpointer.genericproduct.name
    return [importedproducts['sna_ids'], importedproducts['sna_price3d'], importedproducts['sna_dictionnary3d']]


def sna_listtojson_0ED0B():
    if os.path.exists(bpy.path.abspath(bpy.context.preferences.addons['configurateur_deco'].preferences.sna_datapath)):
        pass
    else:
        if not os.path.exists(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['configurateur_deco'].preferences.sna_datapath), '')):
            os.mkdir(os.path.join(bpy.path.abspath(bpy.context.preferences.addons['configurateur_deco'].preferences.sna_datapath), ''))
    return_05353 = toJson(filepath=os.path.join(bpy.path.abspath(bpy.context.preferences.addons['configurateur_deco'].preferences.sna_datapath),'products.json'), data=sna_get3ds_22CBA()[2])
    return os.path.join(bpy.path.abspath(bpy.context.preferences.addons['configurateur_deco'].preferences.sna_datapath),'products.json')


class SNA_PT_NEW_PANEL_B8E48(bpy.types.Panel):
    bl_label = 'New Panel'
    bl_idname = 'SNA_PT_NEW_PANEL_B8E48'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 0
    bl_ui_units_x=20

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        box_8DA1C = layout.box()
        box_8DA1C.alert = False
        box_8DA1C.enabled = True
        box_8DA1C.active = True
        box_8DA1C.use_property_split = False
        box_8DA1C.use_property_decorate = False
        box_8DA1C.alignment = 'Expand'.upper()
        box_8DA1C.scale_x = 1.0
        box_8DA1C.scale_y = 1.0
        if not True: box_8DA1C.operator_context = "EXEC_DEFAULT"
        box_8DA1C.label(text='Meubles', icon_value=0)
        col_3EC09 = box_8DA1C.column(heading='', align=False)
        col_3EC09.alert = False
        col_3EC09.enabled = True
        col_3EC09.active = True
        col_3EC09.use_property_split = False
        col_3EC09.use_property_decorate = False
        col_3EC09.scale_x = 1.0
        col_3EC09.scale_y = 1.0
        col_3EC09.alignment = 'Expand'.upper()
        if not True: col_3EC09.operator_context = "EXEC_DEFAULT"
        for i_AC42B in range(len(eval("list(sna_get3ds_22CBA()[2].keys())"))):
            row_D94C5 = col_3EC09.row(heading='', align=False)
            row_D94C5.alert = False
            row_D94C5.enabled = True
            row_D94C5.active = True
            row_D94C5.use_property_split = False
            row_D94C5.use_property_decorate = False
            row_D94C5.scale_x = 1.0
            row_D94C5.scale_y = 1.0
            row_D94C5.alignment = 'Left'.upper()
            if not True: row_D94C5.operator_context = "EXEC_DEFAULT"
            row_D94C5.label(text=str(eval("sna_get3ds_22CBA()[2].get(list(sna_get3ds_22CBA()[2].keys())[i_AC42B]).get('n')")) + 'x', icon_value=0)
            row_D94C5.label(text=str(round(eval("sna_get3ds_22CBA()[2].get(list(sna_get3ds_22CBA()[2].keys())[i_AC42B]).get('price')"), abs(2))) + ' €', icon_value=0)
            row_D94C5.label(text=eval("sna_get3ds_22CBA()[2].get(list(sna_get3ds_22CBA()[2].keys())[i_AC42B]).get('name')"), icon_value=0)
        box_950AF = layout.box()
        box_950AF.alert = False
        box_950AF.enabled = True
        box_950AF.active = True
        box_950AF.use_property_split = False
        box_950AF.use_property_decorate = False
        box_950AF.alignment = 'Expand'.upper()
        box_950AF.scale_x = 1.0
        box_950AF.scale_y = 1.0
        if not True: box_950AF.operator_context = "EXEC_DEFAULT"
        box_950AF.label(text='Matériaux', icon_value=0)
        col_ACA32 = box_950AF.column(heading='', align=False)
        col_ACA32.alert = False
        col_ACA32.enabled = True
        col_ACA32.active = True
        col_ACA32.use_property_split = False
        col_ACA32.use_property_decorate = False
        col_ACA32.scale_x = 1.0
        col_ACA32.scale_y = 1.0
        col_ACA32.alignment = 'Expand'.upper()
        if not True: col_ACA32.operator_context = "EXEC_DEFAULT"
        for i_37DB9 in range(len(eval("list(set(sna_getmats_53367()[0]))"))):
            row_3BEEA = col_ACA32.row(heading='', align=False)
            row_3BEEA.alert = False
            row_3BEEA.enabled = True
            row_3BEEA.active = True
            row_3BEEA.use_property_split = False
            row_3BEEA.use_property_decorate = False
            row_3BEEA.scale_x = 1.0
            row_3BEEA.scale_y = 1.0
            row_3BEEA.alignment = 'Left'.upper()
            if not True: row_3BEEA.operator_context = "EXEC_DEFAULT"
            row_3BEEA.label(text=eval("list(set(sna_getmats_53367()[0]))")[i_37DB9], icon_value=0)


class SNA_PT_NEW_PANEL_AC978(bpy.types.Panel):
    bl_label = 'New Panel'
    bl_idname = 'SNA_PT_NEW_PANEL_AC978'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 0
    bl_ui_units_x=30

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        box_1C2B6 = layout.box()
        box_1C2B6.alert = False
        box_1C2B6.enabled = True
        box_1C2B6.active = True
        box_1C2B6.use_property_split = False
        box_1C2B6.use_property_decorate = False
        box_1C2B6.alignment = 'Expand'.upper()
        box_1C2B6.scale_x = 1.0
        box_1C2B6.scale_y = 1.0
        if not True: box_1C2B6.operator_context = "EXEC_DEFAULT"
        box_1C2B6.label(text='Meubles', icon_value=0)
        col_881C4 = box_1C2B6.column(heading='', align=False)
        col_881C4.alert = False
        col_881C4.enabled = True
        col_881C4.active = True
        col_881C4.use_property_split = False
        col_881C4.use_property_decorate = False
        col_881C4.scale_x = 1.0
        col_881C4.scale_y = 1.0
        col_881C4.alignment = 'Expand'.upper()
        if not True: col_881C4.operator_context = "EXEC_DEFAULT"
        for i_52DD1 in range(len(eval("list(sna_get3ds_22CBA()[2].keys())"))):
            row_7812F = col_881C4.row(heading='', align=False)
            row_7812F.alert = False
            row_7812F.enabled = True
            row_7812F.active = True
            row_7812F.use_property_split = False
            row_7812F.use_property_decorate = False
            row_7812F.scale_x = 1.0
            row_7812F.scale_y = 1.0
            row_7812F.alignment = 'Left'.upper()
            if not True: row_7812F.operator_context = "EXEC_DEFAULT"
            row_7812F.template_icon(icon_value=load_preview_icon(bpy.path.abspath(sna_imagepreviewfromnameorid_C2A95(eval("sna_get3ds_22CBA()[2].get(list(sna_get3ds_22CBA()[2].keys())[i_52DD1]).get('name')"), '', True, os.path.join(os.path.dirname(__file__), 'assets', 'Zago-Officiel.db'), 'Zago_Officiel'))), scale=4.0)
            row_7812F.label(text=str(round(eval("sna_get3ds_22CBA()[2].get(list(sna_get3ds_22CBA()[2].keys())[i_52DD1]).get('price')"), abs(2))) + ' €' + '   X   ' + str(eval("sna_get3ds_22CBA()[2].get(list(sna_get3ds_22CBA()[2].keys())[i_52DD1]).get('n')")), icon_value=0)
            row_7812F.label(text=eval("sna_get3ds_22CBA()[2].get(list(sna_get3ds_22CBA()[2].keys())[i_52DD1]).get('name')"), icon_value=0)
        box_1FC59 = layout.box()
        box_1FC59.alert = False
        box_1FC59.enabled = True
        box_1FC59.active = True
        box_1FC59.use_property_split = False
        box_1FC59.use_property_decorate = False
        box_1FC59.alignment = 'Expand'.upper()
        box_1FC59.scale_x = 1.0
        box_1FC59.scale_y = 1.0
        if not True: box_1FC59.operator_context = "EXEC_DEFAULT"
        box_1FC59.label(text='Matériaux', icon_value=0)
        col_2FCC0 = box_1FC59.column(heading='', align=False)
        col_2FCC0.alert = False
        col_2FCC0.enabled = True
        col_2FCC0.active = True
        col_2FCC0.use_property_split = False
        col_2FCC0.use_property_decorate = False
        col_2FCC0.scale_x = 1.0
        col_2FCC0.scale_y = 1.0
        col_2FCC0.alignment = 'Expand'.upper()
        if not True: col_2FCC0.operator_context = "EXEC_DEFAULT"
        for i_48B7E in range(len(sna_getmats_53367()[0])):
            row_EB808 = col_2FCC0.row(heading='', align=False)
            row_EB808.alert = False
            row_EB808.enabled = True
            row_EB808.active = True
            row_EB808.use_property_split = False
            row_EB808.use_property_decorate = False
            row_EB808.scale_x = 1.0
            row_EB808.scale_y = 1.0
            row_EB808.alignment = 'Left'.upper()
            if not True: row_EB808.operator_context = "EXEC_DEFAULT"
            row_EB808.template_icon(icon_value=load_preview_icon(bpy.path.abspath(sna_imagepreviewfromnameorid_C2A95('', sna_getmats_53367()[0][i_48B7E], False, os.path.join(os.path.dirname(__file__), 'assets', 'Materials.db'), 'Material'))), scale=4.0)
            row_EB808.label(text=str(round(eval("importedproducts['sna_areasdict'].get(sna_getmats_53367()[0][i_48B7E])"), abs(2))) + 'm²', icon_value=0)
            row_EB808.label(text=sna_getmats_53367()[1][i_48B7E], icon_value=0)


def sna_imagepreviewfromnameorid_C2A95(Nom, ID, ByName, database, tableName):
    return_693CC = sna_getdatabase_69E32_7E640(database, ['Image'], [('Nom' if ByName else 'ID') + " = '" + (Nom if ByName else ID) + "'"], [], tableName, True, 'Nom', False)[1][0][0]
    return return_693CC


def sna_sumprices_2C11E():
    return eval("sum([item['price'] * item['n'] for item in sna_get3ds_22CBA()[2].values()])")


class SNA_OT_List_6D562(bpy.types.Operator):
    bl_idname = "sna.list_6d562"
    bl_label = "List"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        importedproducts['sna_areasdict'] = None
        areas_0_96d60, areas_dict_1_96d60, area_2_96d60 = sna_getmatareas_E6BFF('')
        importedproducts['sna_areasdict'] = areas_dict_1_96d60
        bpy.ops.wm.call_panel(name="SNA_PT_NEW_PANEL_AC978", keep_open=True)
        bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)


def sna_language_32F37(Input):
    bpy.context.preferences.view.language = Input
    bpy.context.preferences.view.use_translate_interface = bool(1)
    bpy.context.preferences.view.use_translate_new_dataname = bool(1)
    bpy.context.preferences.view.use_translate_tooltips = bool(1)


@persistent
def load_pre_handler_5A8E2(dummy):
    sna_language_32F37('fr_FR')


class SNA_OT_Global_Hide_8A754(bpy.types.Operator):
    bl_idname = "sna.global_hide_8a754"
    bl_label = "Global Hide"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        layout.prop(bpy.context.scene, 'sna_globalhide', text='', icon_value=0, emboss=False)

    def invoke(self, context, event):
        context.window_manager.invoke_props_popup(self, event)
        return self.execute(context)


def sna_shading_mode_E9DC9():
    for i_52447 in range(len(bpy.data.screens)):
        for i_98AB6 in range(len(find_areas_of_type(bpy.data.screens[i_52447], 'VIEW_3D'))):
            find_areas_of_type(bpy.data.screens[i_52447], 'VIEW_3D')[i_98AB6].spaces[0].shading.type = 'MATERIAL'
            find_areas_of_type(bpy.data.screens[i_52447], 'VIEW_3D')[i_98AB6].spaces[0].shading.use_scene_lights = True
            find_areas_of_type(bpy.data.screens[i_52447], 'VIEW_3D')[i_98AB6].spaces[0].shading.use_scene_world = True


def sna_gizmos_BEEF0():
    for i_8AB58 in range(len(bpy.data.screens)):
        for i_2EC0B in range(len(find_areas_of_type(bpy.data.screens[i_8AB58], 'VIEW_3D'))):
            if property_exists("find_areas_of_type(bpy.data.screens[i_8AB58], 'VIEW_3D')[i_2EC0B].spaces[0].shading.type", globals(), locals()):
                find_areas_of_type(bpy.data.screens[i_8AB58], 'VIEW_3D')[i_2EC0B].spaces[0].shading.type = 'MATERIAL'
                sna_toolbarshow_A5C56()


def sna_toolbarshow_A5C56():
    if bpy.context.scene.sna_globalhide:
        area_8E2AC = find_area_by_type(bpy.context.screen, 'VIEW_3D', 0)
        with bpy.context.temp_override(area=area_8E2AC, ):
            find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).spaces[0].show_region_toolbar = eval('True')
            bpy.context.scene.sna_show_toolbar = find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).spaces[0].show_region_toolbar


class SNA_OT_Choose_Platform_E9D97(bpy.types.Operator):
    bl_idname = "sna.choose_platform_e9d97"
    bl_label = "Choose platform"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    def sna_platform_enum_items(self, context):
        return [("No Items", "No Items", "No generate enum items node found to create items!", "ERROR", 0)]
    sna_platform: bpy.props.EnumProperty(name='Platform', description='', items=[('PC', 'PC', '', 0, 0), ('Mobile', 'Mobile', '', 0, 1)])

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if property_exists("bpy.data.workspaces[self.sna_platform]", globals(), locals()):
            bpy.data.window_managers[0].windows[0].workspace = bpy.data.workspaces[self.sna_platform]
        else:
            before_data = list(bpy.data.workspaces)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'workspace_template.blend') + r'\WorkSpace', filename=self.sna_platform, link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.workspaces)))
            appended_19454 = None if not new_data else new_data[0]
            bpy.data.window_managers[0].windows[0].workspace = appended_19454
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Toggle_Globalhide_Aeafd(bpy.types.Operator):
    bl_idname = "sna.toggle_globalhide_aeafd"
    bl_label = "toggle globalHide"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if property_exists("bpy.context.scene.sna_globalhide", globals(), locals()):
            mainnodetree['sna_globalhide'] = not mainnodetree['sna_globalhide']
            bpy.context.scene.sna_globalhide = mainnodetree['sna_globalhide']
            for i_92362 in range(len(bpy.context.screen.areas)):
                bpy.context.screen.areas[i_92362].tag_redraw()
                return_BE0D6 = movePanels(reset=(not bpy.context.scene.sna_globalhide))
                if (not bpy.context.scene.sna_globalhide):
                    bpy.ops.preferences.reset_default_theme()
                else:
                    sna_setwhitetheme_A6B0C()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


@persistent
def load_post_handler_5BC94(dummy):
    sna_clean_t_panel_B9F40()
    sna_hide_tool_settings_3d_view_F85D8()
    sna_gizmos_BEEF0()
    sna_clean_property_window_8A68A()
    sna_property_context_to_scene_232A2()
    sna_shading_mode_E9DC9()
    sna_turn_off_overlays_9F185()


@persistent
def load_post_handler_BB9E5(dummy):
    sna_main_bottom_D6C7A()
    sna_setviewbycamera_FE2AD(sna_camera_objects_77160_86E9E(bpy.data.objects)[0])
    return_E2075 = movePanels(reset=eval('False'))
    sna_setwhitetheme_A6B0C()


@persistent
def load_post_handler_B49B0(dummy):
    bpy.ops.sna.choose_platform_e9d97('INVOKE_DEFAULT', sna_platform='PC')


@persistent
def load_post_handler_34F67(dummy):
    addonList = [
        "materials_utils",
        "appart_deco"
    ]
    for addon in addonList:
        try:
            bpy.ops.preferences.addon_enable(module=addon)
        except:
            raise Exception(f"Module '{addon}' not installed!!")
    bpy.context.scene.sna_globalhide = eval('True')


# context.area: VIEW_3D


from bpy import context as C
from bpy.props import IntProperty, StringProperty
class Batchrender(bpy.types.Operator):
    """Operator which runs itself from a timer"""
    bl_idname = "wm.batchrender"
    bl_label = "Batch Render"
    _timer = None
    cameraIndex: IntProperty(default=0)
    camNum: IntProperty(default=0)
    cameras: [bpy.types.Object] = []

    def getCameraFromObj(self):
        self.cameras = [obj for obj in bpy.data.objects if obj.type == 'CAMERA']
        return self.cameras

    def init(self):
        self.cameraIndex = 0
        self.getCameraFromObj()
        self.camNum = len(self.cameras)
        bpy.context.scene.render.engine = 'CYCLES'

    def modal(self, context, event):
        if event.type in {'RIGHTMOUSE', 'ESC'}:
            self.cancel(context)
            return {'CANCELLED'}
        if event.type == 'TIMER':
            if self.cameraIndex < self.camNum:
                if not bpy.app.is_job_running('RENDER'):
                    #Render setups
                    bpy.context.scene.camera = self.cameras[self.cameraIndex]
                    bpy.context.scene.render.filepath = f'//render\\testModal_{bpy.context.scene.camera.name}'
                    bpy.context.scene.cycles.use_denoising = True
                    # if cam is top cam
                    if bpy.context.scene.camera.name == C.scene.sna_addon_prefs_temp.sna_topcamname:
                        #resolution
                        C.scene.render.resolution_x = C.scene.sna_addon_prefs_temp.sna_topcamresolution[0]
                        C.scene.render.resolution_y = C.scene.sna_addon_prefs_temp.sna_topcamresolution[1]
                        # Hide Plafond collection
                        C.scene.collection.children[C.scene.sna_addon_prefs_temp.sna_plafondcollectionname].hide_render = True
                        C.scene.collection.children[C.scene.sna_addon_prefs_temp.sna_plafondcollectionname].hide_viewport = True
                    else:
                        #resolution
                        C.scene.render.resolution_x = C.scene.sna_addon_prefs_temp.sna_panoramic_resolution[0]
                        C.scene.render.resolution_y = C.scene.sna_addon_prefs_temp.sna_panoramic_resolution[1]
                        # Unide Plafond collection
                        C.scene.collection.children[C.scene.sna_addon_prefs_temp.sna_plafondcollectionname].hide_render = False
                        C.scene.collection.children[C.scene.sna_addon_prefs_temp.sna_plafondcollectionname].hide_viewport = False
                    bpy.ops.render.render('INVOKE_DEFAULT', write_still=True, use_viewport=True)
                    self.cameraIndex += 1
                    print('Rendering') 
            else: 
                # Unide Plafond collection
                C.scene.collection.children[C.scene.sna_addon_prefs_temp.sna_plafondcollectionname].hide_render = False
                C.scene.collection.children[C.scene.sna_addon_prefs_temp.sna_plafondcollectionname].hide_viewport = False
                return {'FINISHED'}
            pass
        return {'PASS_THROUGH'}

    def execute(self, context):
        wm = context.window_manager
        self._timer = wm.event_timer_add(1, window=context.window)
        wm.modal_handler_add(self)
        self.init()
        return {'RUNNING_MODAL'}

    def cancel(self, context):
        wm = context.window_manager
        wm.event_timer_remove(self._timer)


def menu_func(self, context):
    self.layout.operator(Batchrender.bl_idname, text=Batchrender.bl_label)


#    bpy.types.VIEW3D_MT_view.append(menu_func)
    pass


# Register and add to the "view" menu (required to also use F3 search "Modal Timer Operator" for quick access).
#    bpy.types.VIEW3D_MT_view.remove(menu_func)
#     try: 
#         unregister()
#     except: pass
#     register()
#     # test call
#     bpy.ops.wm.batch_render()


def toJson(filepath: str = "./data.json", data: any = [], returnValue: bool = False):
    if returnValue:
        return json.dumps(data)
    # else
    with open(filepath, "w") as outfile: 
        json.dump(data, outfile)


if __name__ == "__main__":
    a = {'nom': "foo", 'age': 52}
    print(toJson(data=a, returnValue=True))


from bpy.utils import register_class, unregister_class


def movePanels(reset: bool =False):
    if reset:
        pscene.SceneButtonsPanel.bl_context = 'scene'
        try:
            register_class(pscene.SCENE_PT_scene)
        except: 
            pass
    else:
        pscene.SceneButtonsPanel.bl_context = 'output'
        try:
            unregister_class(pscene.SCENE_PT_scene)
        except:
            pass
    for cls in pscene.classes:
        if cls != pscene.SCENE_PT_scene:
            unregister_class(cls)
            register_class(cls)


def sna_setwhitetheme_A6B0C():
    if os.path.exists(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Custom_White.xml'))):
        bpy.ops.preferences.theme_install(overwrite=True, filepath=bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Custom_White.xml')))


@persistent
def load_post_handler_471C4(dummy):
    bpy.context.window_manager.keyconfigs.active.keymaps['3D View'].keymap_items['view3d.view_pan'].active = False
    bpy.context.window_manager.keyconfigs.active.keymaps['3D View'].keymap_items['view3d.move'].active = False


class SNA_OT_Operator_57A70(bpy.types.Operator):
    bl_idname = "sna.operator_57a70"
    bl_label = "Operator"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_setwhitetheme_A6B0C()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_normal_to_euler_A52AD(normal, forward_axis):
    normal_vector = normal
    forward_axis = forward_axis
    rotation_euler = None
    from mathutils import Vector, Matrix, Euler
    # normal_vector = (0, 1, 0)
    # forward_axis = (0, 0, 1)

    def rotation_matrix_to_align_vector(v1: Vector, v2: Vector):
        # Calculate the rotation matrix to align v1 with v2
        threshold = 0.0001
        if math.fabs(v1.angle(v2) % math.pi) >= threshold:
            rot_matrix = Matrix.Rotation(v1.angle(v2), 3, v1.cross(v2).normalized())
            return rot_matrix.to_quaternion().to_euler()
        else:
            return Euler((0, 0, v1.angle(v2)))
    # External variable 
    normal_vector = Vector(normal_vector)
    forward_axis = Vector(forward_axis)
    # Compute the rotation quaternion to align the negative y-axis with the normal vector
    rotation_euler = rotation_matrix_to_align_vector(forward_axis, normal_vector)
    # (1,0,0) -- (0, 1,0)
    # print(list(map(lambda x: degrees(x), rotation_euler)))
    return rotation_euler


class SNA_PT_AIDE_38B46(bpy.types.Panel):
    bl_label = 'Aide'
    bl_idname = 'SNA_PT_AIDE_38B46'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.separator(factor=5.0)
        layout.label(text='Cliquer dans la pièce.', icon_value=0)


def sna_appendfile_C56FA(filepath, allfiles):
    if allfiles:
        for i_9FCCB in range(len(get_blend_contents(bpy.path.abspath(filepath), 'objects'))):
            before_data = list(bpy.data.objects)
            bpy.ops.wm.append(directory=bpy.path.abspath(filepath) + r'\Object', filename=get_blend_contents(bpy.path.abspath(filepath), 'objects')[i_9FCCB], link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.objects)))
            appended_5D3C8 = None if not new_data else new_data[0]
            placeoncursor['sna_objects'].append(appended_5D3C8)
            return placeoncursor['sna_objects']
    else:
        if os.path.exists(bpy.path.abspath(filepath)):
            before_data = list(bpy.data.objects)
            bpy.ops.wm.append(directory=bpy.path.abspath(filepath) + r'\Object', filename=get_blend_contents(bpy.path.abspath(filepath), 'objects')[0], link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.objects)))
            appended_15F37 = None if not new_data else new_data[0]
            appended_15F37['isReplacable'] = False
            return appended_15F37


class SNA_PT_wrong_place_469A0(bpy.types.Panel):
    bl_label = ''
    bl_idname = 'SNA_PT_wrong_place_469A0'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_order = 0
    bl_options = {'HIDE_HEADER'}
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='Cliquer une place convenable', icon_value=0)


class SNA_PT_REMPLACER_A6840(bpy.types.Panel):
    bl_label = 'Remplacer'
    bl_idname = 'SNA_PT_REMPLACER_A6840'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 0
    bl_ui_units_x=15

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        box_59DBF = layout.box()
        box_59DBF.alert = eval('True')
        box_59DBF.enabled = eval('True')
        box_59DBF.active = eval('True')
        box_59DBF.use_property_split = False
        box_59DBF.use_property_decorate = False
        box_59DBF.alignment = 'Expand'.upper()
        box_59DBF.scale_x = 1.0
        box_59DBF.scale_y = 1.0
        if not eval('True'): box_59DBF.operator_context = "EXEC_DEFAULT"
        box_59DBF.label(text='Selectionner un produit dans la pièce.', icon_value=256)


class SNA_OT_Place_387A2(bpy.types.Operator):
    bl_idname = "sna.place_387a2"
    bl_label = "Place"
    bl_description = "Placer ou remplacer un produit"
    bl_options = {"REGISTER", "UNDO"}
    sna_filepath: bpy.props.StringProperty(name='filepath', description='', options={'HIDDEN'}, default='', subtype='FILE_PATH', maxlen=0)

    def sna_pivot_enum_items(self, context):
        return [("No Items", "No Items", "No generate enum items node found to create items!", "ERROR", 0)]
    sna_pivot: bpy.props.EnumProperty(name='Pivot', description='', options={'HIDDEN'}, items=[('None', 'None', '', 0, 0), ('Mur', 'Mur', '', 0, 1), ('Sol', 'Sol', '', 0, 2), ('Plafond', 'Plafond', '', 0, 3)])
    sna_nom: bpy.props.StringProperty(name='Nom', description='', default='', subtype='NONE', maxlen=0)
    sna_price: bpy.props.FloatProperty(name='Price', description='', default=0.0, subtype='NONE', unit='NONE', step=3, precision=6)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.wm.call_panel(name="SNA_PT_AIDE_38B46", keep_open=False)
        area_FB593 = find_area_by_type(bpy.context.screen, 'VIEW_3D', 0)
        region_FB593 = getattr(find_area_by_type(bpy.context.screen, 'VIEW_3D', 0), 'regions', None)[-1]
        with bpy.context.temp_override(area=area_FB593, region=region_FB593, ):
            prev_context = bpy.context.area.type
            bpy.context.area.type = 'VIEW_3D'
            bpy.ops.sna.append_and_move_0eba8('INVOKE_DEFAULT', sna_filepath=self.sna_filepath, sna_pivot=self.sna_pivot)
            bpy.context.area.type = prev_context
            area_5D8F8 = find_area_by_type(bpy.context.screen, 'PROPERTIES', 0)
            region_5D8F8 = getattr(find_area_by_type(bpy.context.screen, 'PROPERTIES', 0), 'regions', None)[1]
            with bpy.context.temp_override(area=area_5D8F8, region=region_5D8F8, ):
                bpy.context.scene.sna_thisproduct.nom = self.sna_nom
                bpy.context.scene.sna_thisproduct.prix = self.sna_price
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        layout.label(text='Cliquer dans la pièce.', icon_value=35)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=300)


class SNA_OT_Append_And_Replace_F53E9(bpy.types.Operator):
    bl_idname = "sna.append_and_replace_f53e9"
    bl_label = "Append and replace"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_filepath: bpy.props.StringProperty(name='filepath', description='', options={'SKIP_SAVE', 'HIDDEN'}, default='', subtype='FILE_PATH', maxlen=0)

    def sna_pivot_enum_items(self, context):
        return [("No Items", "No Items", "No generate enum items node found to create items!", "ERROR", 0)]
    sna_pivot: bpy.props.EnumProperty(name='Pivot', description='', options={'SKIP_SAVE', 'HIDDEN'}, items=[('None', 'None', '', 0, 0), ('Mur', 'Mur', '', 0, 1), ('Plafond', 'Plafond', '', 0, 2), ('Sol', 'Sol', '', 0, 3)])
    sna_price: bpy.props.FloatProperty(name='Price', description='', default=0.0, subtype='NONE', unit='NONE', step=3, precision=6)
    sna_selectedobjprice: bpy.props.FloatProperty(name='selectedObjPrice', description='', default=0.0, subtype='NONE', unit='NONE', step=3, precision=6)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if eval("len(bpy.context.view_layer.objects.selected) > 0"):
            sna_updatepriceondelete_D9D70(bpy.context.view_layer.objects.selected[0])
            placeoncursor['sna_hit_location'] = []
            placeoncursor['sna_hit_location'] = list(bpy.context.view_layer.objects.selected[0].location)
            placeoncursor['sna_objecttoreplace'] = None
            placeoncursor['sna_objecttoreplace'] = bpy.context.view_layer.objects.selected[0]
            if ((bpy.context.view_layer.objects.selected[0].sna_pivot == self.sna_pivot) and (bpy.context.view_layer.objects.selected[0].sna_pivot != 'None') and (self.sna_pivot != 'None')):
                output_0_5f3c5 = sna_appendfile_C56FA(self.sna_filepath, False)
                bpy.context.scene.sna_prixpiece = float(bpy.context.scene.sna_prixpiece + self.sna_price)
                output_0_5f3c5.location = tuple(placeoncursor['sna_hit_location'])
                output_0_5f3c5.rotation_euler = placeoncursor['sna_objecttoreplace'].rotation_euler
                output_0_5f3c5.delta_rotation_euler = placeoncursor['sna_objecttoreplace'].delta_rotation_euler
                bpy.data.objects.remove(object=placeoncursor['sna_objecttoreplace'], do_unlink=eval('True'), do_id_user=eval('True'), do_ui_user=eval('True'), )
                sna_main_bottom_D6C7A()
                bpy.ops.outliner.orphans_purge(do_local_ids=eval('True'), do_linked_ids=eval('True'), do_recursive=eval('True'))
        else:
            bpy.ops.wm.call_panel(name="SNA_PT_REMPLACER_A6840", keep_open=False)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


_0EBA8_running = False
class SNA_OT_Append_And_Move_0Eba8(bpy.types.Operator):
    bl_idname = "sna.append_and_move_0eba8"
    bl_label = "Append and move"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_filepath: bpy.props.StringProperty(name='filepath', description='', default='', subtype='FILE_PATH', maxlen=0)

    def sna_pivot_enum_items(self, context):
        return [("No Items", "No Items", "No generate enum items node found to create items!", "ERROR", 0)]
    sna_pivot: bpy.props.EnumProperty(name='Pivot', description='', items=[('Sol', 'Sol', '', 0, 0), ('Plafond', 'Plafond', '', 0, 1), ('Mur', 'Mur', '', 0, 2), ('None', 'None', '', 0, 3)])
    cursor = "CROSSHAIR"
    _handle = None
    _event = {}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        if not True or context.area.spaces[0].bl_rna.identifier == 'SpaceView3D':
            return not False
        return False

    def save_event(self, event):
        event_options = ["type", "value", "alt", "shift", "ctrl", "oskey", "mouse_region_x", "mouse_region_y", "mouse_x", "mouse_y", "pressure", "tilt"]
        if bpy.app.version >= (3, 2, 1):
            event_options += ["type_prev", "value_prev"]
        for option in event_options: self._event[option] = getattr(event, option)

    def draw_callback_px(self, context):
        event = self._event
        if event.keys():
            event = dotdict(event)
            try:
                pass
            except Exception as error:
                print(error)

    def execute(self, context):
        global _0EBA8_running
        _0EBA8_running = False
        context.window.cursor_set("DEFAULT")
        bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
        if (len(placeoncursor['sna_hit_location']) > 2):
            output_0_02d04 = sna_appendfile_C56FA(self.sna_filepath, False)
            bpy.ops.object.select_all('INVOKE_DEFAULT', )
            bpy.context.view_layer.objects.active = output_0_02d04
            if property_exists("output_0_02d04", globals(), locals()):
                output_0_02d04.location = tuple(placeoncursor['sna_hit_location'])
                output_0_2be20 = sna_normal_to_euler_A52AD(tuple(placeoncursor['sna_hit_normal']), (0.0, 1.0, 0.0))
                output_0_02d04.rotation_euler = (bpy.context.view_layer.objects.active.rotation_euler[0], bpy.context.view_layer.objects.active.rotation_euler[1], output_0_2be20[2])
                bpy.context.scene.sna_prixpiece = float(bpy.context.scene.sna_prixpiece + bpy.context.scene.sna_thisproduct.prix)
                sna_main_bottom_D6C7A()
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}

    def modal(self, context, event):
        global _0EBA8_running
        if not context.area or not _0EBA8_running:
            self.execute(context)
            return {'CANCELLED'}
        self.save_event(event)
        context.area.tag_redraw()
        context.window.cursor_set('CROSSHAIR')
        try:
            if (event.type == 'LEFTMOUSE' and event.value == 'PRESS' and event.alt == False and event.shift == False and event.ctrl == False):
                placeoncursor['sna_hit_location'] = list(sna_node_58D55_C44CC((event.mouse_region_x, event.mouse_region_y), False)[1])
                placeoncursor['sna_hit_normal'] = list(sna_rotatevector_B0BC7_BD168(sna_node_58D55_C44CC((event.mouse_region_x, event.mouse_region_y), False)[3], sna_node_58D55_C44CC((event.mouse_region_x, event.mouse_region_y), False)[0].rotation_euler))
                if bpy.context.scene.sna_freeplace:
                    placeoncursor['sna_hit_object'] = sna_node_58D55_C44CC((event.mouse_region_x, event.mouse_region_y), False)[0]
                    zone_de_recherche['sna_debut'] = eval('True')
                    self.execute(context)
                    return {"FINISHED"}
                else:
                    if ((self.sna_pivot == bpy.context.view_layer.objects.active.sna_structure) and (self.sna_pivot != 'None') and (bpy.context.view_layer.objects.active.sna_structure != 'None')):
                        placeoncursor['sna_hit_object'] = sna_node_58D55_C44CC((event.mouse_region_x, event.mouse_region_y), False)[0]
                        zone_de_recherche['sna_debut'] = eval('True')
                        self.execute(context)
                        return {"FINISHED"}
                    else:
                        bpy.ops.wm.call_panel(name="SNA_PT_wrong_place_469A0", keep_open=False)
                        if event.type in ['RIGHTMOUSE', 'ESC']:
                            self.execute(context)
                            return {'CANCELLED'}
                        return {"CANCELLED"}
        except Exception as error:
            print(error)
        if event.type in ['RIGHTMOUSE', 'ESC']:
            self.execute(context)
            return {'CANCELLED'}
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        global _0EBA8_running
        if _0EBA8_running:
            _0EBA8_running = False
            return {'FINISHED'}
        else:
            self.save_event(event)
            self.start_pos = (event.mouse_x, event.mouse_y)
            placeoncursor['sna_hit_location'] = []
            placeoncursor['sna_hit_normal'] = []
            placeoncursor['sna_hit_object'] = None
            args = (context,)
            self._handle = bpy.types.SpaceView3D.draw_handler_add(self.draw_callback_px, args, 'WINDOW', 'POST_PIXEL')
            context.window_manager.modal_handler_add(self)
            _0EBA8_running = True
            return {'RUNNING_MODAL'}


class SNA_AddonPreferences_588F5(bpy.types.AddonPreferences):
    bl_idname = 'configurateur_deco'
    sna_topcamname: bpy.props.StringProperty(name='topCamName', description='', options={'SKIP_SAVE', 'HIDDEN'}, default='Top', subtype='NONE', maxlen=0)
    sna_topcamresolution: bpy.props.IntVectorProperty(name='topCamResolution', description='', size=2, default=(3000, 3000), subtype='XYZ')
    sna_renderfolder: bpy.props.StringProperty(name='RenderFolder', description='', default='//Render', subtype='DIR_PATH', maxlen=0)
    sna_panoramic_resolution: bpy.props.IntVectorProperty(name='Panoramic Resolution', description='Resolution of the panoramic render', options={'HIDDEN', 'ANIMATABLE'}, size=2, default=(3000, 1500), subtype='XYZ', min=0, soft_max=12000)
    sna_plafondcollectionname: bpy.props.StringProperty(name='plafondCollectionName', description='', default='Plafond', subtype='NONE', maxlen=0)
    sna_panoramicimagename: bpy.props.StringProperty(name='PanoramicImageName', description='', default='pano_', subtype='NONE', maxlen=0)
    sna_panotimethreshold: bpy.props.IntProperty(name='PanoTimeThreshold', description='', default=60, subtype='TIME', min=0)
    sna_toptimethreshold: bpy.props.IntProperty(name='TopTimeThreshold', description='', default=60, subtype='TIME', min=0)
    sna_maxsamples: bpy.props.IntProperty(name='MaxSamples', description='', default=1000, subtype='NONE', min=0)
    sna_previewwidthdefault: bpy.props.IntProperty(name='previewWidthDefault', description='Minimum width of the preview of the camera', default=130, subtype='NONE', min=0)
    sna_calcultimethreshold: bpy.props.IntProperty(name='CalculTimeThreshold', description='', default=60, subtype='TIME', min=1, soft_min=60, soft_max=300)
    sna_datapath: bpy.props.StringProperty(name='dataPath', description='User\'s data folder', default='//datas', subtype='DIR_PATH', maxlen=0)
    sna_movedistance: bpy.props.FloatProperty(name='moveDistance', description='', default=0.029999999329447746, subtype='NONE', unit='LENGTH', step=3, precision=3)
    sna_rotationangle: bpy.props.FloatProperty(name='rotationAngle', description='', default=5.0, subtype='NONE', unit='ROTATION', step=3, precision=3)

    def draw(self, context):
        if not (False):
            layout = self.layout 
            row_F7566 = layout.row(heading='', align=False)
            row_F7566.alert = False
            row_F7566.enabled = True
            row_F7566.active = True
            row_F7566.use_property_split = False
            row_F7566.use_property_decorate = False
            row_F7566.scale_x = 1.0
            row_F7566.scale_y = 1.0
            row_F7566.alignment = 'Expand'.upper()
            if not False: row_F7566.operator_context = "EXEC_DEFAULT"
            row_F7566.label(text='Nom de la cam top view', icon_value=0)
            row_F7566.prop(bpy.context.preferences.addons['configurateur_deco'].preferences, 'sna_topcamname', text='', icon_value=266, emboss=True, expand=True)
            row_D9580 = layout.row(heading='', align=False)
            row_D9580.alert = False
            row_D9580.enabled = True
            row_D9580.active = True
            row_D9580.use_property_split = False
            row_D9580.use_property_decorate = False
            row_D9580.scale_x = 1.0
            row_D9580.scale_y = 1.0
            row_D9580.alignment = 'Expand'.upper()
            if not False: row_D9580.operator_context = "EXEC_DEFAULT"
            row_D9580.label(text='Nom de la collection plafond', icon_value=0)
            row_D9580.prop(bpy.context.preferences.addons['configurateur_deco'].preferences, 'sna_plafondcollectionname', text='', icon_value=250, emboss=True)
            split_E17AB = layout.split(factor=0.5, align=False)
            split_E17AB.alert = False
            split_E17AB.enabled = True
            split_E17AB.active = True
            split_E17AB.use_property_split = False
            split_E17AB.use_property_decorate = False
            split_E17AB.scale_x = 1.0
            split_E17AB.scale_y = 1.0
            split_E17AB.alignment = 'Center'.upper()
            if not False: split_E17AB.operator_context = "EXEC_DEFAULT"
            split_E17AB.label(text='Panoramic image basename', icon_value=0)
            split_E17AB.prop(bpy.context.preferences.addons['configurateur_deco'].preferences, 'sna_panoramicimagename', text='', icon_value=362, emboss=True, expand=False, slider=False)
            row_B034B = layout.row(heading='', align=False)
            row_B034B.alert = False
            row_B034B.enabled = True
            row_B034B.active = True
            row_B034B.use_property_split = False
            row_B034B.use_property_decorate = False
            row_B034B.scale_x = 1.0
            row_B034B.scale_y = 1.0
            row_B034B.alignment = 'Expand'.upper()
            if not False: row_B034B.operator_context = "EXEC_DEFAULT"
            col_D274E = row_B034B.column(heading='', align=False)
            col_D274E.alert = False
            col_D274E.enabled = True
            col_D274E.active = True
            col_D274E.use_property_split = False
            col_D274E.use_property_decorate = False
            col_D274E.scale_x = 1.0
            col_D274E.scale_y = 1.0
            col_D274E.alignment = 'Expand'.upper()
            if not False: col_D274E.operator_context = "EXEC_DEFAULT"
            col_D274E.label(text='Panoramic resolution', icon_value=0)
            col_D274E.prop(bpy.context.preferences.addons['configurateur_deco'].preferences, 'sna_panoramic_resolution', text='', icon_value=776, emboss=True, expand=True, slider=True)
            col_4DD64 = row_B034B.column(heading='', align=False)
            col_4DD64.alert = False
            col_4DD64.enabled = True
            col_4DD64.active = True
            col_4DD64.use_property_split = False
            col_4DD64.use_property_decorate = False
            col_4DD64.scale_x = 1.0
            col_4DD64.scale_y = 1.0
            col_4DD64.alignment = 'Expand'.upper()
            if not False: col_4DD64.operator_context = "EXEC_DEFAULT"
            col_4DD64.label(text='Top camera resolution', icon_value=0)
            col_4DD64.prop(bpy.context.preferences.addons['configurateur_deco'].preferences, 'sna_topcamresolution', text='', icon_value=776, emboss=True, expand=True, slider=True)
            layout.prop(bpy.context.preferences.addons['configurateur_deco'].preferences, 'sna_renderfolder', text='Render folder', icon_value=0, emboss=True, expand=True, slider=True)
            box_D6B7B = layout.box()
            box_D6B7B.alert = False
            box_D6B7B.enabled = True
            box_D6B7B.active = True
            box_D6B7B.use_property_split = False
            box_D6B7B.use_property_decorate = False
            box_D6B7B.alignment = 'Expand'.upper()
            box_D6B7B.scale_x = 1.0
            box_D6B7B.scale_y = 1.0
            if not False: box_D6B7B.operator_context = "EXEC_DEFAULT"
            box_D6B7B.label(text='Final renders', icon_value=0)
            box_D6B7B.prop(bpy.context.preferences.addons['configurateur_deco'].preferences, 'sna_panotimethreshold', text='Temps de rendu panoramic', icon_value=0, emboss=True, expand=True, slider=True)
            box_D6B7B.prop(bpy.context.preferences.addons['configurateur_deco'].preferences, 'sna_toptimethreshold', text='Top', icon_value=0, emboss=True, expand=True, slider=True)
            box_D6B7B.prop(bpy.context.preferences.addons['configurateur_deco'].preferences, 'sna_maxsamples', text='Max samples', icon_value=0, emboss=True, expand=True, slider=True)
            box_E8F4A = layout.box()
            box_E8F4A.alert = False
            box_E8F4A.enabled = True
            box_E8F4A.active = True
            box_E8F4A.use_property_split = False
            box_E8F4A.use_property_decorate = False
            box_E8F4A.alignment = 'Expand'.upper()
            box_E8F4A.scale_x = 1.0
            box_E8F4A.scale_y = 1.0
            if not True: box_E8F4A.operator_context = "EXEC_DEFAULT"
            box_E8F4A.label(text='Calcul image', icon_value=0)
            box_E8F4A.prop(bpy.context.preferences.addons['configurateur_deco'].preferences, 'sna_calcultimethreshold', text='Temps de rendu (s)', icon_value=0, emboss=True)
            layout.prop(bpy.context.preferences.addons['configurateur_deco'].preferences, 'sna_datapath', text="Dossier de données l'utilisateur", icon_value=0, emboss=True)
            row_BD77D = layout.row(heading='', align=False)
            row_BD77D.alert = False
            row_BD77D.enabled = True
            row_BD77D.active = True
            row_BD77D.use_property_split = False
            row_BD77D.use_property_decorate = False
            row_BD77D.scale_x = 1.0
            row_BD77D.scale_y = 1.0
            row_BD77D.alignment = 'Expand'.upper()
            if not True: row_BD77D.operator_context = "EXEC_DEFAULT"
            row_BD77D.prop(bpy.context.preferences.addons['configurateur_deco'].preferences, 'sna_movedistance', text='Distance de déplacement', icon_value=0, emboss=True)
            row_BD77D.prop(bpy.context.preferences.addons['configurateur_deco'].preferences, 'sna_rotationangle', text='Angle de rotation', icon_value=0, emboss=True)


def sna_property_context_to_scene_232A2():
    for i_FED1E in range(len(bpy.data.screens)):
        for i_9E957 in range(len(find_areas_of_type(bpy.data.screens[i_FED1E], 'PROPERTIES'))):
            find_areas_of_type(bpy.data.screens[i_FED1E], 'PROPERTIES')[i_9E957].spaces.active.context = 'SCENE'


def sna_clean_property_window_8A68A():
    for i_E0AF4 in range(len(bpy.data.screens)):
        for i_9382C in range(len(find_areas_of_type(bpy.data.screens[i_E0AF4], 'PROPERTIES'))):
            find_areas_of_type(bpy.data.screens[i_E0AF4], 'PROPERTIES')[i_9382C].spaces[0].show_region_header = False
    if (property_exists("bpy.context.scene", globals(), locals()) and bpy.context.scene.name):
        bpy.context.scene.name = bpy.context.scene.sna_texte_scene


def sna_add_to_properties_pt_navigation_bar_D8EF4(self, context):
    if not (False):
        layout = self.layout
        if bpy.context.scene.sna_globalhide:
            layout.separator(factor=50000.0)


def sna_add_to_properties_ht_header_26849(self, context):
    if not (False):
        layout = self.layout
        if bpy.context.scene.sna_globalhide:
            layout.separator(factor=25000.0)


def sna_getmatindexincollection_AB8C6(Collection, Material):
    return_83FF0 = [i for i,mat in enumerate(Collection) if Material == mat]
    return return_83FF0


def sna_getareafromfaceindices_436DA(FaceIndices, Polygons):
    return_9CF19 = [Polygons[i].area for i in FaceIndices]
    return_A7ED0 = sum(return_9CF19)
    return [return_9CF19, return_A7ED0]


def sna_getfaceidswithmatids_032C3(Polygons, matIndices):
    return_ED29D = [ i for i, face in enumerate(Polygons) if face.material_index in matIndices]
    return return_ED29D


def sna_getmatareas_E6BFF(ID):
    surfaces['sna_areas'] = []
    id_0_d7762 = sna_getmatidlist_FA08E(bpy.data.materials)
    for i_07C2B in range(len(id_0_d7762)):
        bpy.ops.view3d.materialutilities_select_by_material_name(material_name=id_0_d7762[i_07C2B])
        for i_D4FB2 in range(len(bpy.context.view_layer.objects.selected)):
            faceids_0_8d5f9 = sna_getfaceidswithmatids_032C3(bpy.context.view_layer.objects.selected[i_D4FB2].data.polygons, sna_getmatindexincollection_AB8C6(bpy.context.view_layer.objects.selected[i_D4FB2].data.materials, bpy.data.materials[id_0_d7762[i_07C2B]]))
            arealists_0_88d40, sumarea_1_88d40 = sna_getareafromfaceindices_436DA(faceids_0_8d5f9, bpy.context.view_layer.objects.selected[i_D4FB2].data.polygons)
            surfaces['sna_areas'].append(eval("(id_0_d7762[i_07C2B], sumarea_1_88d40)"))
    return_D2A72 = {name: areas for name, areas in surfaces['sna_areas'] }
    return [surfaces['sna_areas'], return_D2A72, eval("return_D2A72.get(ID)")]


def sna_add_to_topbar_ht_upper_bar_14A26(self, context):
    if not (False):
        layout = self.layout


class SNA_PT_RENDU_FINI_79A39(bpy.types.Panel):
    bl_label = 'Rendu Fini'
    bl_idname = 'SNA_PT_RENDU_FINI_79A39'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        box_82DE5 = layout.box()
        box_82DE5.alert = False
        box_82DE5.enabled = False
        box_82DE5.active = False
        box_82DE5.use_property_split = False
        box_82DE5.use_property_decorate = False
        box_82DE5.alignment = 'Expand'.upper()
        box_82DE5.scale_x = 1.0
        box_82DE5.scale_y = 1.0
        if not False: box_82DE5.operator_context = "EXEC_DEFAULT"
        box_82DE5.label(text='Rendus finis.', icon_value=881)
        op = box_82DE5.operator('sn.dummy_button_operator', text='Ok', icon_value=0, emboss=False, depress=False)


def sna_isselected_3C840():
    return [(len(bpy.context.view_layer.objects.selected) > 0), bpy.context.view_layer.objects.selected, (bpy.context.view_layer.objects.selected[0] if (len(bpy.context.view_layer.objects.selected) > 0) else None)]


def sna_filterbyselectedtype_34F6B():
    return ("Type IS '?'".replace('?', sna_typeoffirstselected_77FDE()) if eval("sna_typeoffirstselected_77FDE() != ''") else 'True')


def sna_typeoffirstselected_77FDE():
    return (sna_isselected_3C840()[2].sna_objectpointer.genericproduct.type if (sna_isselected_3C840()[0] and 'sna_objectpointer' in sna_isselected_3C840()[2] and property_exists("sna_isselected_3C840()[2].sna_objectpointer.genericproduct.type", globals(), locals())) else None)


def sna_defaultfilter_1F513():
    return ['(' + sna_decompose_search_term_on_field_8A8A9('Nom', bpy.context.scene.sna_search_term.replace('Que recherchez-vous?', '')) + ')', sna_mapprixenum_D8A3D(bpy.context.scene.sna_prix), sna_mapcolors_4915D(bpy.context.scene.sna_couleurs, 'Couleur')]


def sna_make_active_camera_B3C8C(Input):
    if (property_exists("bpy.context.view_layer.objects.active", globals(), locals()) and property_exists("Input", globals(), locals())):
        if property_exists("bpy.context.scene.camera", globals(), locals()):
            bpy.context.scene.camera = Input
            if property_exists("find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).spaces[0].region_3d.view_perspective", globals(), locals()):
                find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).spaces[0].region_3d.view_perspective = 'PERSP'


def sna_eevee_render_BE76B():
    if (property_exists("bpy.context.preferences.addons['configurateur_deco'].preferences.sna_previewwidthdefault", globals(), locals()) and property_exists("bpy.context.scene.render.resolution_x", globals(), locals()) and property_exists("bpy.context.scene.render.resolution_y", globals(), locals())):
        bpy.context.scene.render.resolution_x = 400
        bpy.context.scene.render.resolution_y = int(400 / 2.0)
        if property_exists("bpy.context.scene.render.engine", globals(), locals()):
            bpy.context.scene.render.engine = 'BLENDER_EEVEE'
            for i_AE82F in range(len(sna_camera_objects_77160_CC779(bpy.data.objects))):
                bpy.context.scene.render.filepath = os.path.join(bpy.context.scene.sna_tmpfolder,getattr(sna_camera_objects_77160_CC779(bpy.data.objects)[i_AE82F], 'name', None))
                sna_make_active_camera_B3C8C(sna_camera_objects_77160_CC779(bpy.data.objects)[i_AE82F])
                bpy.context.scene.render.resolution_percentage = 100
                if property_exists("bpy.context.scene.eevee.taa_render_samples", globals(), locals()):
                    if (getattr(sna_camera_objects_77160_CC779(bpy.data.objects)[i_AE82F], 'name', None) == bpy.context.preferences.addons['configurateur_deco'].preferences.sna_topcamname):
                        sna_toggle_plafond_95678(eval('True'))
                    else:
                        sna_toggle_plafond_95678(eval('False'))
                    bpy.ops.render.render(write_still=eval('True'), use_viewport=eval('True'))
                    sna_toggle_plafond_95678(eval('False'))


class SNA_OT_Switch_Workspace_15E45(bpy.types.Operator):
    bl_idname = "sna.switch_workspace_15e45"
    bl_label = "Switch workspace"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_target: bpy.props.StringProperty(name='target', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        target = self.sna_target
        bpy.context.window.workspace = bpy.data.workspaces[target]
        bpy.context.scene.sna_active_workspace = self.sna_target
        sna_property_context_to_scene_232A2()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_inbetweenquery_2F2CB(min, max):
    return 'Prix' + ' BETWEEN ' + str(min) + ' AND ' + str(max)


def sna_mapprixenum_D8A3D(Input):
    zone_de_recherche['sna_outputenummap'] = ''
    if Input == "Moins de 100€":
        output_0_66f06 = sna_inbetweenquery_2F2CB(0.0, 100.0)
        zone_de_recherche['sna_outputenummap'] = output_0_66f06
    elif Input == "100€ à 250€":
        output_0_239f1 = sna_inbetweenquery_2F2CB(100.0, 250.0)
        zone_de_recherche['sna_outputenummap'] = output_0_239f1
    elif Input == "250€ à 500€":
        output_0_5acb9 = sna_inbetweenquery_2F2CB(250.0, 500.0)
        zone_de_recherche['sna_outputenummap'] = output_0_5acb9
    elif Input == "500€ à 750€":
        output_0_8c544 = sna_inbetweenquery_2F2CB(500.0, 750.0)
        zone_de_recherche['sna_outputenummap'] = output_0_8c544
    elif Input == "750€ à 1000€":
        output_0_01fc4 = sna_inbetweenquery_2F2CB(750.0, 1000.0)
        zone_de_recherche['sna_outputenummap'] = output_0_01fc4
    elif Input == "1000€ à 1250€":
        output_0_50112 = sna_inbetweenquery_2F2CB(1000.0, 1250.0)
        zone_de_recherche['sna_outputenummap'] = output_0_50112
    elif Input == "1250€ à 1500€":
        output_0_bbb67 = sna_inbetweenquery_2F2CB(1250.0, 1500.0)
        zone_de_recherche['sna_outputenummap'] = output_0_bbb67
    elif Input == "Plus de 1500€":
        zone_de_recherche['sna_outputenummap'] = 'Prix' + '>=' + '1500'
    else:
        zone_de_recherche['sna_outputenummap'] = 'Prix' + '>' + '0'
    return zone_de_recherche['sna_outputenummap']


def sna_getallcollorsindb_05CF4():
    return_F1922 = list(set(sna_getdatabase_69E32_88D4D(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Zago-Officiel.db')), ['Couleur'], ["LOWER(Dispo) = 'oui'"], [], 'Zago_Officiel', True, 'Nom', False)[1][0]))
    return return_F1922


def sna_couleurs_enum_items(self, context):
    enum_items = eval("[['Toutes', 'Toutes', '', 0]] + list(map(list, list(zip(sna_getallcollorsindb_05CF4(), sna_getallcollorsindb_05CF4(), ['']*len(sna_getallcollorsindb_05CF4()), [0]*len(sna_getallcollorsindb_05CF4())))))")
    return [make_enum_item(item[0], item[1], item[2], item[3], i) for i, item in enumerate(enum_items)]


def sna_prix_enum_items(self, context):
    enum_items = [['Tout prix', 'Tout prix', '', 0], ['Moins de 100€', 'Moins de 100€', '', 0], ['100€ à 250€', '100€ à 250€', '', 0], ['250€ à 500€', '250€ à 500€', '', 0], ['500€ à 750€', '500€ à 750€', '', 0], ['750€ à 1000€', '750€ à 1000€', '', 0], ['1000€ à 1250€', '1000€ à 1250€', '', 0], ['1250€ à 1500€', '1250€ à 1500€', '', 0], ['Plus de 1500€', 'Plus de 1500€', '', 0]]
    return [make_enum_item(item[0], item[1], item[2], item[3], i) for i, item in enumerate(enum_items)]


def sna_trier_enum_items(self, context):
    enum_items = [['Par prix croissant', 'Par prix croissant', '', 0], ['Par prix décroissant', 'Par prix décroissant', '', 0]]
    return [make_enum_item(item[0], item[1], item[2], item[3], i) for i, item in enumerate(enum_items)]


def sna_mapcolors_4915D(Color, ColorField):
    zone_de_recherche['sna_colorenummap'] = ''
    if Color == "Toutes":
        zone_de_recherche['sna_colorenummap'] = ColorField + ' ' + ' IS NOT NULL'
    else:
        zone_de_recherche['sna_colorenummap'] = ColorField + ' = ' + "'" + Color + "'"
    return zone_de_recherche['sna_colorenummap']


def sna_scene3delements_F0328():
    ids_0_e143f = sna_get3didlist_A3E6F()
    return 'ID in ' + ' (' + "'" + "','".join(eval("list(set(ids_0_e143f))")) + "'" + ')'


def sna_get3didlist_A3E6F():
    zone_de_recherche['sna_productidlist'] = []
    for i_636D3 in range(len(bpy.data.objects)):
        if bpy.data.objects[i_636D3].type == 'MESH':
            if property_exists("bpy.data.objects[i_636D3].sna_objectpointer", globals(), locals()):
                if (property_exists("bpy.data.objects[i_636D3].sna_objectpointer.genericproduct", globals(), locals()) and property_exists("bpy.data.objects[i_636D3].sna_objectpointer.genericproduct.id", globals(), locals()) and eval("bpy.data.objects[i_636D3].sna_objectpointer.genericproduct.id != ''")):
                    zone_de_recherche['sna_productidlist'].append(bpy.data.objects[i_636D3].sna_objectpointer.genericproduct.id)
    return zone_de_recherche['sna_productidlist']


@persistent
def load_post_handler_85AB2(dummy):

    def delayed_CDB35():
        sum_0_bf221 = sna_sumprices_2C11E()
        bpy.context.scene.sna_prixpiece = sum_0_bf221
        find_area_by_type(bpy.context.screen, 'PROPERTIES', 0).tag_redraw()
        if False:
            return None
        return 0.5
    bpy.app.timers.register(delayed_CDB35, first_interval=0.20000000298023224)


def sna_button_placer_06127(layout_function, filepath, pivot, nom, price):
    op = layout_function.operator('sna.place_387a2', text='Placer dans la pièce', icon_value=0, emboss=eval('True'), depress=eval('False'))
    op.sna_filepath = filepath
    op.sna_pivot = pivot
    op.sna_nom = nom
    op.sna_price = price


def sna_button_remplacer_0FA9F(layout_function, filepath, pivot, price):
    op = layout_function.operator('sna.append_and_replace_f53e9', text='Remplacer', icon_value=0, emboss=eval('True'), depress=eval('False'))
    op.sna_filepath = filepath
    op.sna_pivot = pivot
    op.sna_price = price
    op.sna_selectedobjprice = 0.0


def sna_button_voir_plus_3d_6B6A8(layout_function, nom):
    op = layout_function.operator('sna.voirplus_cec25', text='Voir plus de produits', icon_value=0, emboss=eval('True'), depress=eval('False'))
    op.sna_nom = nom


class SNA_PT_NEW_PANEL_88C1D(bpy.types.Panel):
    bl_label = 'New Panel'
    bl_idname = 'SNA_PT_NEW_PANEL_88C1D'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_category = 'AssetSearch'
    bl_order = 2
    bl_options = {'HIDE_HEADER'}
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout_function = layout
        sna_search_panel_FC798(layout_function, sna_getdatabase_69E32_BF860(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Zago-Officiel.db')), 'Image, Prix, Nom, Fichier, Lien_Zago, Pivot'.split(','), sna_concatenatelists_30982([['Prix IS NOT NULL', (((sna_filterbyselectedtype_34F6B() if eval("sna_isselected_3C840()[2].get('sna_objectpointer').get('genericproduct').get('id') != None and sna_isselected_3C840()[2].get('sna_objectpointer').get('genericproduct').get('id') != ''") else 'FALSE') if (sna_isselected_3C840()[0] and sna_isselected_3C840()[2].type == 'MESH') else sna_scene3delements_F0328()) if zone_de_recherche['sna_debut'] else zone_recherche_plus['sna_filter3d'])], sna_defaultfilter_1F513()]), [], 'Zago_Officiel', True, 'Prix', bpy.context.scene.sna_prixcroissant)[1][0], sna_getdatabase_69E32_BF860(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Zago-Officiel.db')), 'Image, Prix, Nom, Fichier, Lien_Zago, Pivot'.split(','), sna_concatenatelists_30982([['Prix IS NOT NULL', (((sna_filterbyselectedtype_34F6B() if eval("sna_isselected_3C840()[2].get('sna_objectpointer').get('genericproduct').get('id') != None and sna_isselected_3C840()[2].get('sna_objectpointer').get('genericproduct').get('id') != ''") else 'FALSE') if (sna_isselected_3C840()[0] and sna_isselected_3C840()[2].type == 'MESH') else sna_scene3delements_F0328()) if zone_de_recherche['sna_debut'] else zone_recherche_plus['sna_filter3d'])], sna_defaultfilter_1F513()]), [], 'Zago_Officiel', True, 'Prix', bpy.context.scene.sna_prixcroissant)[1][1], sna_getdatabase_69E32_BF860(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Zago-Officiel.db')), 'Image, Prix, Nom, Fichier, Lien_Zago, Pivot'.split(','), sna_concatenatelists_30982([['Prix IS NOT NULL', (((sna_filterbyselectedtype_34F6B() if eval("sna_isselected_3C840()[2].get('sna_objectpointer').get('genericproduct').get('id') != None and sna_isselected_3C840()[2].get('sna_objectpointer').get('genericproduct').get('id') != ''") else 'FALSE') if (sna_isselected_3C840()[0] and sna_isselected_3C840()[2].type == 'MESH') else sna_scene3delements_F0328()) if zone_de_recherche['sna_debut'] else zone_recherche_plus['sna_filter3d'])], sna_defaultfilter_1F513()]), [], 'Zago_Officiel', True, 'Prix', bpy.context.scene.sna_prixcroissant)[1][2], sna_getdatabase_69E32_BF860(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Zago-Officiel.db')), 'Image, Prix, Nom, Fichier, Lien_Zago, Pivot'.split(','), sna_concatenatelists_30982([['Prix IS NOT NULL', (((sna_filterbyselectedtype_34F6B() if eval("sna_isselected_3C840()[2].get('sna_objectpointer').get('genericproduct').get('id') != None and sna_isselected_3C840()[2].get('sna_objectpointer').get('genericproduct').get('id') != ''") else 'FALSE') if (sna_isselected_3C840()[0] and sna_isselected_3C840()[2].type == 'MESH') else sna_scene3delements_F0328()) if zone_de_recherche['sna_debut'] else zone_recherche_plus['sna_filter3d'])], sna_defaultfilter_1F513()]), [], 'Zago_Officiel', True, 'Prix', bpy.context.scene.sna_prixcroissant)[1][3], 2, False, sna_getdatabase_69E32_BF860(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Zago-Officiel.db')), 'Image, Prix, Nom, Fichier, Lien_Zago, Pivot'.split(','), sna_concatenatelists_30982([['Prix IS NOT NULL', (((sna_filterbyselectedtype_34F6B() if eval("sna_isselected_3C840()[2].get('sna_objectpointer').get('genericproduct').get('id') != None and sna_isselected_3C840()[2].get('sna_objectpointer').get('genericproduct').get('id') != ''") else 'FALSE') if (sna_isselected_3C840()[0] and sna_isselected_3C840()[2].type == 'MESH') else sna_scene3delements_F0328()) if zone_de_recherche['sna_debut'] else zone_recherche_plus['sna_filter3d'])], sna_defaultfilter_1F513()]), [], 'Zago_Officiel', True, 'Prix', bpy.context.scene.sna_prixcroissant)[1][4], sna_getdatabase_69E32_BF860(bpy.path.abspath(os.path.join(os.path.dirname(__file__), 'assets', 'Zago-Officiel.db')), 'Image, Prix, Nom, Fichier, Lien_Zago, Pivot'.split(','), sna_concatenatelists_30982([['Prix IS NOT NULL', (((sna_filterbyselectedtype_34F6B() if eval("sna_isselected_3C840()[2].get('sna_objectpointer').get('genericproduct').get('id') != None and sna_isselected_3C840()[2].get('sna_objectpointer').get('genericproduct').get('id') != ''") else 'FALSE') if (sna_isselected_3C840()[0] and sna_isselected_3C840()[2].type == 'MESH') else sna_scene3delements_F0328()) if zone_de_recherche['sna_debut'] else zone_recherche_plus['sna_filter3d'])], sna_defaultfilter_1F513()]), [], 'Zago_Officiel', True, 'Prix', bpy.context.scene.sna_prixcroissant)[1][5])


def sna_search_panel_FC798(layout_function, images, prices, names, blender_filepaths, display_number, limit_display, lien_zago, pivot):
    if images:
        if prices:
            if names:
                grid_8D2AC = layout_function.grid_flow(columns=(int(bpy.context.region.width / int(bpy.context.window.width / 3.0 / 2.6700000762939453)) if bpy.context.scene.sna_editdisplay else bpy.context.scene.sna_productperrow), row_major=False, even_columns=False, even_rows=False, align=False)
                grid_8D2AC.enabled = True
                grid_8D2AC.active = True
                grid_8D2AC.use_property_split = False
                grid_8D2AC.use_property_decorate = False
                grid_8D2AC.alignment = 'Expand'.upper()
                grid_8D2AC.scale_x = 1.3600000143051147
                grid_8D2AC.scale_y = 1.0
                if not False: grid_8D2AC.operator_context = "EXEC_DEFAULT"
                for i_8CE98 in range(len(images)):
                    if limit_display:
                        if (i_8CE98 < display_number):
                            layout_function = grid_8D2AC
                            sna_asset_panel_45577(layout_function, prices[i_8CE98], names[i_8CE98], os.path.join(images[i_8CE98],), blender_filepaths[i_8CE98], lien_zago[i_8CE98], pivot[i_8CE98])
                    else:
                        layout_function = grid_8D2AC
                        sna_asset_panel_45577(layout_function, prices[i_8CE98], names[i_8CE98], os.path.join(images[i_8CE98],), blender_filepaths[i_8CE98], lien_zago[i_8CE98], pivot[i_8CE98])
            else:
                box_993EF = layout_function.box()
                box_993EF.alert = True
                box_993EF.enabled = True
                box_993EF.active = True
                box_993EF.use_property_split = False
                box_993EF.use_property_decorate = False
                box_993EF.alignment = 'Expand'.upper()
                box_993EF.scale_x = 1.0
                box_993EF.scale_y = 1.0
                if not False: box_993EF.operator_context = "EXEC_DEFAULT"
                box_993EF.label(text='Name list error', icon_value=0)
        else:
            box_AB668 = layout_function.box()
            box_AB668.alert = True
            box_AB668.enabled = True
            box_AB668.active = True
            box_AB668.use_property_split = False
            box_AB668.use_property_decorate = False
            box_AB668.alignment = 'Expand'.upper()
            box_AB668.scale_x = 1.0
            box_AB668.scale_y = 1.0
            if not False: box_AB668.operator_context = "EXEC_DEFAULT"
            box_AB668.label(text='Price list error', icon_value=0)
    else:
        box_12ACA = layout_function.box()
        box_12ACA.alert = True
        box_12ACA.enabled = True
        box_12ACA.active = True
        box_12ACA.use_property_split = False
        box_12ACA.use_property_decorate = False
        box_12ACA.alignment = 'Expand'.upper()
        box_12ACA.scale_x = 1.0
        box_12ACA.scale_y = 1.0
        if not False: box_12ACA.operator_context = "EXEC_DEFAULT"
        box_12ACA.label(text='Image list error', icon_value=0)


def sna_decompose_search_term_on_field_8A8A9(field, term):
    zone_de_recherche['sna_term_list'] = []
    for i_E8CAD in range(len(eval("' '.join(term.split())").split(' '))):
        zone_de_recherche['sna_term_list'].append('LOWER(' + ('Nom' if eval("field == ''") else field) + ') LIKE LOWER("%?%")'.replace('?', eval("' '.join(term.split())").split(' ')[i_E8CAD]))
    return ' AND '.join(zone_de_recherche['sna_term_list'])


class SNA_PT_FILTRES_96594(bpy.types.Panel):
    bl_label = 'Filtres'
    bl_idname = 'SNA_PT_FILTRES_96594'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_category = 'Top'
    bl_order = 0
    bl_options = {'HIDE_HEADER'}
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_80BCE = layout.column(heading='', align=False)
        col_80BCE.alert = False
        col_80BCE.enabled = True
        col_80BCE.active = True
        col_80BCE.use_property_split = False
        col_80BCE.use_property_decorate = False
        col_80BCE.scale_x = 1.0
        col_80BCE.scale_y = 1.0
        col_80BCE.alignment = 'Expand'.upper()
        if not False: col_80BCE.operator_context = "EXEC_DEFAULT"
        row_F37A5 = col_80BCE.row(heading='', align=False)
        row_F37A5.alert = False
        row_F37A5.enabled = True
        row_F37A5.active = True
        row_F37A5.use_property_split = False
        row_F37A5.use_property_decorate = False
        row_F37A5.scale_x = 1.0
        row_F37A5.scale_y = 1.0
        row_F37A5.alignment = 'Left'.upper()
        if not True: row_F37A5.operator_context = "EXEC_DEFAULT"
        row_F37A5.label(text='Prix produits estimé dans la pièce: ' + str(round(bpy.context.scene.sna_prixpiece, abs(2))) + ' €', icon_value=0)
        op = row_F37A5.operator('sna.list_6d562', text='Détails', icon_value=46, emboss=False, depress=False)
        col_80BCE.prop(bpy.context.scene, 'sna_search_term', text='', icon_value=30, emboss=eval('True'))
        if zone_de_recherche['sna_debut']:
            pass
        else:
            grid_9DAB1 = col_80BCE.grid_flow(columns=5, row_major=False, even_columns=False, even_rows=False, align=False)
            grid_9DAB1.enabled = True
            grid_9DAB1.active = True
            grid_9DAB1.use_property_split = False
            grid_9DAB1.use_property_decorate = False
            grid_9DAB1.alignment = 'Expand'.upper()
            grid_9DAB1.scale_x = 1.0
            grid_9DAB1.scale_y = 1.0
            if not False: grid_9DAB1.operator_context = "EXEC_DEFAULT"
            grid_9DAB1.prop(bpy.context.scene, 'sna_trier', text='Trier', icon_value=0, emboss=True)
            grid_9DAB1.prop(bpy.context.scene, 'sna_tailles', text='Tailles', icon_value=0, emboss=True)
            grid_9DAB1.prop(bpy.context.scene, 'sna_marques', text='Marques', icon_value=0, emboss=True)
            grid_9DAB1.prop(bpy.context.scene, 'sna_couleurs', text='Couleurs', icon_value=0, emboss=True)
            grid_9DAB1.prop(bpy.context.scene, 'sna_type', text='Type', icon_value=0, emboss=True)
            grid_9DAB1.prop(bpy.context.scene, 'sna_prix', text='Prix', icon_value=0, emboss=True)
            grid_9DAB1.separator(factor=1.0)
            grid_9DAB1.separator(factor=1.0)
            split_50549 = grid_9DAB1.split(factor=1.0, align=False)
            split_50549.alert = False
            split_50549.enabled = True
            split_50549.active = True
            split_50549.use_property_split = False
            split_50549.use_property_decorate = False
            split_50549.scale_x = 1.0
            split_50549.scale_y = 1.0
            split_50549.alignment = 'Expand'.upper()
            if not False: split_50549.operator_context = "EXEC_DEFAULT"
            row_9006E = split_50549.row(heading='', align=False)
            row_9006E.alert = False
            row_9006E.enabled = True
            row_9006E.active = True
            row_9006E.use_property_split = False
            row_9006E.use_property_decorate = False
            row_9006E.scale_x = 1.0
            row_9006E.scale_y = 1.0
            row_9006E.alignment = 'Expand'.upper()
            if not False: row_9006E.operator_context = "EXEC_DEFAULT"
            row_9006E.label(text='Nb col.', icon_value=0)
            row_9006E.prop(bpy.context.scene, 'sna_productperrow', text='', icon_value=0, emboss=True)
            row_9006E.prop(bpy.context.scene, 'sna_editdisplay', text='Auto', icon_value=39, emboss=True, toggle=True)
        if zone_de_recherche['sna_debut']:
            pass
        else:
            op = col_80BCE.operator('sna.retourner_60c49', text='Retourner', icon_value=717, emboss=True, depress=False)


def sna_asset_panel_45577(layout_function, price, nom, image_path, filepath, lien, pivot):
    box_DF13F = layout_function.box()
    box_DF13F.alert = False
    box_DF13F.enabled = True
    box_DF13F.active = True
    box_DF13F.use_property_split = False
    box_DF13F.use_property_decorate = False
    box_DF13F.alignment = 'Expand'.upper()
    box_DF13F.scale_x = 1.0
    box_DF13F.scale_y = 1.0
    if not False: box_DF13F.operator_context = "EXEC_DEFAULT"
    col_87854 = box_DF13F.column(heading='', align=False)
    col_87854.alert = False
    col_87854.enabled = True
    col_87854.active = True
    col_87854.use_property_split = False
    col_87854.use_property_decorate = False
    col_87854.scale_x = 1.0
    col_87854.scale_y = 1.6299999952316284
    col_87854.alignment = 'Left'.upper()
    if not False: col_87854.operator_context = "EXEC_DEFAULT"
    col_87854.template_icon(icon_value=load_preview_icon(bpy.path.abspath(image_path)), scale=6.0)
    row_872ED = col_87854.row(heading='', align=False)
    row_872ED.alert = False
    row_872ED.enabled = True
    row_872ED.active = True
    row_872ED.use_property_split = False
    row_872ED.use_property_decorate = False
    row_872ED.scale_x = 1.0
    row_872ED.scale_y = 1.059999942779541
    row_872ED.alignment = 'Center'.upper()
    if not False: row_872ED.operator_context = "EXEC_DEFAULT"
    row_872ED.label(text='', icon_value=0)
    col_A8148 = row_872ED.column(heading='', align=False)
    col_A8148.alert = False
    col_A8148.enabled = True
    col_A8148.active = True
    col_A8148.use_property_split = False
    col_A8148.use_property_decorate = False
    col_A8148.scale_x = 1.0
    col_A8148.scale_y = 0.5
    col_A8148.alignment = 'Center'.upper()
    if not False: col_A8148.operator_context = "EXEC_DEFAULT"
    col_A8148.separator(factor=2.0)
    col_12E9A = col_A8148.column(heading='', align=False)
    col_12E9A.alert = False
    col_12E9A.enabled = True
    col_12E9A.active = True
    col_12E9A.use_property_split = False
    col_12E9A.use_property_decorate = False
    col_12E9A.scale_x = 1.0
    col_12E9A.scale_y = 2.0
    col_12E9A.alignment = 'Expand'.upper()
    if not True: col_12E9A.operator_context = "EXEC_DEFAULT"
    if ((not sna_isselected_3C840()[0]) and zone_de_recherche['sna_debut']):
        layout_function = col_12E9A
        sna_button_voir_plus_3d_6B6A8(layout_function, nom)
    else:
        layout_function = col_12E9A
        sna_button_placer_06127(layout_function, bpy.path.abspath(filepath), pivot, nom, price)
    col_12E9A.separator(factor=1.0)
    if ((not sna_isselected_3C840()[0]) and zone_de_recherche['sna_debut']):
        pass
    else:
        layout_function = col_12E9A
        sna_button_remplacer_0FA9F(layout_function, bpy.path.abspath(filepath), pivot, price)
    col_A8148.separator(factor=2.0)
    for i_03CA9 in range(len(sna_word_wrap_34E95_414F3(nom, 32))):
        col_A8148.label(text=sna_word_wrap_34E95_414F3(nom, 32)[i_03CA9], icon_value=0)
    col_A8148.separator(factor=1.0)
    row_A0FD7 = col_A8148.row(heading='', align=False)
    row_A0FD7.alert = False
    row_A0FD7.enabled = True
    row_A0FD7.active = True
    row_A0FD7.use_property_split = False
    row_A0FD7.use_property_decorate = False
    row_A0FD7.scale_x = 1.0
    row_A0FD7.scale_y = 1.0
    row_A0FD7.alignment = 'Expand'.upper()
    if not False: row_A0FD7.operator_context = "EXEC_DEFAULT"
    row_A0FD7.label(text=str(price) + '€', icon_value=0)
    row_A0FD7.separator(factor=0.0)
    op = row_A0FD7.operator('wm.url_open', text='En savoir +', icon_value=0, emboss=eval('True'), depress=eval('False'))
    op.url = lien
    row_872ED.label(text='', icon_value=0)


@persistent
def load_post_handler_900C8(dummy):
    zone_de_recherche['sna_debut'] = True


class SNA_PT_NEW_PANEL_9CADE(bpy.types.Panel):
    bl_label = 'New Panel'
    bl_idname = 'SNA_PT_NEW_PANEL_9CADE'
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_category = 'AssetSearch'
    bl_order = 3
    bl_options = {'HIDE_HEADER'}
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        grid_C0744 = layout.grid_flow(columns=(int(bpy.context.region.width / int(bpy.context.window.width / 3.0 / 2.6700000762939453)) if bpy.context.scene.sna_editdisplay else bpy.context.scene.sna_productperrow), row_major=False, even_columns=False, even_rows=False, align=False)
        grid_C0744.enabled = True
        grid_C0744.active = True
        grid_C0744.use_property_split = False
        grid_C0744.use_property_decorate = False
        grid_C0744.alignment = 'Expand'.upper()
        grid_C0744.scale_x = 1.0
        grid_C0744.scale_y = 1.0
        if not False: grid_C0744.operator_context = "EXEC_DEFAULT"
        for i_C723E in range(sna_getdatabase_69E32_9D3D4(os.path.join(os.path.dirname(__file__), 'assets', 'Materials.db'), 'Prix, Nom, Image, Fichier, Lien, ID'.split(','), sna_concatenatelists_30982([["Dispo = 'Oui'", (('Type IN ' + '(' + 'SELECT ' + 'Type ' + 'FROM Material WHERE ' + "ID IN ('" + "','".join(eval("list(set(sna_getmatidlist_FA08E(bpy.context.view_layer.objects.active.data.materials)))")) + "')" + ')' if (sna_isselected_3C840()[0] and (bpy.context.view_layer.objects.active.type == 'MESH' or bpy.context.view_layer.objects.active.type == 'CURVE')) else 'ID IN ' + "('" + "','".join(sna_getmatidlist_FA08E(bpy.data.materials)) + "')") if zone_de_recherche['sna_debut'] else zone_material['sna_filtermat'])], sna_defaultfilter_1F513()]), [], 'Material', eval('True'), 'Nom', False)[0]):
            layout_function = grid_C0744
            sna_material_panel_74DAC(layout_function, sna_getdatabase_69E32_9D3D4(os.path.join(os.path.dirname(__file__), 'assets', 'Materials.db'), 'Prix, Nom, Image, Fichier, Lien, ID'.split(','), sna_concatenatelists_30982([["Dispo = 'Oui'", (('Type IN ' + '(' + 'SELECT ' + 'Type ' + 'FROM Material WHERE ' + "ID IN ('" + "','".join(eval("list(set(sna_getmatidlist_FA08E(bpy.context.view_layer.objects.active.data.materials)))")) + "')" + ')' if (sna_isselected_3C840()[0] and (bpy.context.view_layer.objects.active.type == 'MESH' or bpy.context.view_layer.objects.active.type == 'CURVE')) else 'ID IN ' + "('" + "','".join(sna_getmatidlist_FA08E(bpy.data.materials)) + "')") if zone_de_recherche['sna_debut'] else zone_material['sna_filtermat'])], sna_defaultfilter_1F513()]), [], 'Material', eval('True'), 'Nom', False)[1][0][i_C723E], sna_getdatabase_69E32_9D3D4(os.path.join(os.path.dirname(__file__), 'assets', 'Materials.db'), 'Prix, Nom, Image, Fichier, Lien, ID'.split(','), sna_concatenatelists_30982([["Dispo = 'Oui'", (('Type IN ' + '(' + 'SELECT ' + 'Type ' + 'FROM Material WHERE ' + "ID IN ('" + "','".join(eval("list(set(sna_getmatidlist_FA08E(bpy.context.view_layer.objects.active.data.materials)))")) + "')" + ')' if (sna_isselected_3C840()[0] and (bpy.context.view_layer.objects.active.type == 'MESH' or bpy.context.view_layer.objects.active.type == 'CURVE')) else 'ID IN ' + "('" + "','".join(sna_getmatidlist_FA08E(bpy.data.materials)) + "')") if zone_de_recherche['sna_debut'] else zone_material['sna_filtermat'])], sna_defaultfilter_1F513()]), [], 'Material', eval('True'), 'Nom', False)[1][1][i_C723E], sna_getdatabase_69E32_9D3D4(os.path.join(os.path.dirname(__file__), 'assets', 'Materials.db'), 'Prix, Nom, Image, Fichier, Lien, ID'.split(','), sna_concatenatelists_30982([["Dispo = 'Oui'", (('Type IN ' + '(' + 'SELECT ' + 'Type ' + 'FROM Material WHERE ' + "ID IN ('" + "','".join(eval("list(set(sna_getmatidlist_FA08E(bpy.context.view_layer.objects.active.data.materials)))")) + "')" + ')' if (sna_isselected_3C840()[0] and (bpy.context.view_layer.objects.active.type == 'MESH' or bpy.context.view_layer.objects.active.type == 'CURVE')) else 'ID IN ' + "('" + "','".join(sna_getmatidlist_FA08E(bpy.data.materials)) + "')") if zone_de_recherche['sna_debut'] else zone_material['sna_filtermat'])], sna_defaultfilter_1F513()]), [], 'Material', eval('True'), 'Nom', False)[1][2][i_C723E], sna_getdatabase_69E32_9D3D4(os.path.join(os.path.dirname(__file__), 'assets', 'Materials.db'), 'Prix, Nom, Image, Fichier, Lien, ID'.split(','), sna_concatenatelists_30982([["Dispo = 'Oui'", (('Type IN ' + '(' + 'SELECT ' + 'Type ' + 'FROM Material WHERE ' + "ID IN ('" + "','".join(eval("list(set(sna_getmatidlist_FA08E(bpy.context.view_layer.objects.active.data.materials)))")) + "')" + ')' if (sna_isselected_3C840()[0] and (bpy.context.view_layer.objects.active.type == 'MESH' or bpy.context.view_layer.objects.active.type == 'CURVE')) else 'ID IN ' + "('" + "','".join(sna_getmatidlist_FA08E(bpy.data.materials)) + "')") if zone_de_recherche['sna_debut'] else zone_material['sna_filtermat'])], sna_defaultfilter_1F513()]), [], 'Material', eval('True'), 'Nom', False)[1][3][i_C723E], sna_getdatabase_69E32_9D3D4(os.path.join(os.path.dirname(__file__), 'assets', 'Materials.db'), 'Prix, Nom, Image, Fichier, Lien, ID'.split(','), sna_concatenatelists_30982([["Dispo = 'Oui'", (('Type IN ' + '(' + 'SELECT ' + 'Type ' + 'FROM Material WHERE ' + "ID IN ('" + "','".join(eval("list(set(sna_getmatidlist_FA08E(bpy.context.view_layer.objects.active.data.materials)))")) + "')" + ')' if (sna_isselected_3C840()[0] and (bpy.context.view_layer.objects.active.type == 'MESH' or bpy.context.view_layer.objects.active.type == 'CURVE')) else 'ID IN ' + "('" + "','".join(sna_getmatidlist_FA08E(bpy.data.materials)) + "')") if zone_de_recherche['sna_debut'] else zone_material['sna_filtermat'])], sna_defaultfilter_1F513()]), [], 'Material', eval('True'), 'Nom', False)[1][4][i_C723E], sna_getdatabase_69E32_9D3D4(os.path.join(os.path.dirname(__file__), 'assets', 'Materials.db'), 'Prix, Nom, Image, Fichier, Lien, ID'.split(','), sna_concatenatelists_30982([["Dispo = 'Oui'", (('Type IN ' + '(' + 'SELECT ' + 'Type ' + 'FROM Material WHERE ' + "ID IN ('" + "','".join(eval("list(set(sna_getmatidlist_FA08E(bpy.context.view_layer.objects.active.data.materials)))")) + "')" + ')' if (sna_isselected_3C840()[0] and (bpy.context.view_layer.objects.active.type == 'MESH' or bpy.context.view_layer.objects.active.type == 'CURVE')) else 'ID IN ' + "('" + "','".join(sna_getmatidlist_FA08E(bpy.data.materials)) + "')") if zone_de_recherche['sna_debut'] else zone_material['sna_filtermat'])], sna_defaultfilter_1F513()]), [], 'Material', eval('True'), 'Nom', False)[1][5][i_C723E])


def sna_remplacer_mat_97590(layout_function, filepath, nom, price, hide):
    if hide:
        pass
    else:
        col_71BA9 = layout_function.column(heading='', align=False)
        col_71BA9.alert = False
        col_71BA9.enabled = True
        col_71BA9.active = True
        col_71BA9.use_property_split = False
        col_71BA9.use_property_decorate = False
        col_71BA9.scale_x = 1.0
        col_71BA9.scale_y = 2.0
        col_71BA9.alignment = 'Expand'.upper()
        if not True: col_71BA9.operator_context = "EXEC_DEFAULT"
        op = col_71BA9.operator('sn.dummy_button_operator', text='Remplacer', icon_value=0, emboss=eval('True'), depress=eval('False'))


def sna_peindre_6BA81(layout_function, filepath, nom, price, id):
    col_1F843 = layout_function.column(heading='', align=False)
    col_1F843.alert = False
    col_1F843.enabled = True
    col_1F843.active = True
    col_1F843.use_property_split = False
    col_1F843.use_property_decorate = False
    col_1F843.scale_x = 1.0
    col_1F843.scale_y = 2.0
    col_1F843.alignment = 'Expand'.upper()
    if not True: col_1F843.operator_context = "EXEC_DEFAULT"
    op = col_1F843.operator('sna.paint_prepare_f15ce', text='Placer dans la pièce', icon_value=0, emboss=eval('True'), depress=eval('False'))
    op.sna_id = id
    op.sna_filepath = filepath


def sna_loadmaterial_AF1C1(filepath, matName):
    zone_material['sna_newmaterial'] = None
    if (os.path.exists(filepath) and matName in get_blend_contents(filepath, 'materials')):
        if property_exists("bpy.data.materials[matName]", globals(), locals()):
            zone_material['sna_newmaterial'] = bpy.data.materials[matName]
        else:
            before_data = list(bpy.data.materials)
            bpy.ops.wm.append(directory=filepath + r'\Material', filename=matName, link=True)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.materials)))
            appended_C7AF4 = None if not new_data else new_data[0]
            zone_material['sna_newmaterial'] = appended_C7AF4


def sna_filtrememetypemat_D7A79(Nom, ID):
    return 'Type' + ' = ' + '(SELECT ' + 'Type' + '  FROM ' + 'Material' + ' WHERE ' + ('Nom' if eval("Nom != ''") else 'id') + " = '" + (Nom if eval("Nom != ''") else ID) + "')"


def sna_concatenatelists_30982(list):
    return_B6AB8 = [j for i in list for j in i]
    return return_B6AB8


def sna_material_panel_74DAC(layout_function, price, nom, image_path, filepath, lien, id):
    box_801CF = layout_function.box()
    box_801CF.alert = False
    box_801CF.enabled = True
    box_801CF.active = True
    box_801CF.use_property_split = False
    box_801CF.use_property_decorate = False
    box_801CF.alignment = 'Expand'.upper()
    box_801CF.scale_x = 1.0
    box_801CF.scale_y = 1.0
    if not False: box_801CF.operator_context = "EXEC_DEFAULT"
    col_47C3C = box_801CF.column(heading='', align=False)
    col_47C3C.alert = False
    col_47C3C.enabled = True
    col_47C3C.active = True
    col_47C3C.use_property_split = False
    col_47C3C.use_property_decorate = False
    col_47C3C.scale_x = 1.0
    col_47C3C.scale_y = 1.6299999952316284
    col_47C3C.alignment = 'Left'.upper()
    if not False: col_47C3C.operator_context = "EXEC_DEFAULT"
    col_47C3C.template_icon(icon_value=load_preview_icon(bpy.path.abspath(image_path)), scale=6.0)
    row_37884 = col_47C3C.row(heading='', align=False)
    row_37884.alert = False
    row_37884.enabled = True
    row_37884.active = True
    row_37884.use_property_split = False
    row_37884.use_property_decorate = False
    row_37884.scale_x = 1.0
    row_37884.scale_y = 1.059999942779541
    row_37884.alignment = 'Center'.upper()
    if not False: row_37884.operator_context = "EXEC_DEFAULT"
    row_37884.label(text='', icon_value=0)
    col_4AFCB = row_37884.column(heading='', align=False)
    col_4AFCB.alert = False
    col_4AFCB.enabled = True
    col_4AFCB.active = True
    col_4AFCB.use_property_split = False
    col_4AFCB.use_property_decorate = False
    col_4AFCB.scale_x = 1.0
    col_4AFCB.scale_y = 0.5
    col_4AFCB.alignment = 'Center'.upper()
    if not False: col_4AFCB.operator_context = "EXEC_DEFAULT"
    col_4AFCB.separator(factor=2.0)
    if zone_de_recherche['sna_debut']:
        if sna_isselected_3C840()[0]:
            layout_function = col_4AFCB
            sna_peindre_6BA81(layout_function, bpy.path.abspath(filepath), nom, price, id)
        else:
            layout_function = col_4AFCB
            sna_button_voir_plus_mat_2EFCA(layout_function, nom)
    else:
        layout_function = col_4AFCB
        sna_peindre_6BA81(layout_function, bpy.path.abspath(filepath), nom, price, id)
    col_4AFCB.separator(factor=1.0)
    layout_function = col_4AFCB
    sna_remplacer_mat_97590(layout_function, bpy.path.abspath(filepath), nom, price, eval('True'))
    col_4AFCB.separator(factor=2.0)
    for i_F2EC3 in range(len(sna_word_wrap_34E95_1348A(nom, 32))):
        col_4AFCB.label(text=sna_word_wrap_34E95_1348A(nom, 32)[i_F2EC3], icon_value=0)
    col_4AFCB.separator(factor=1.0)
    row_EBA1B = col_4AFCB.row(heading='', align=False)
    row_EBA1B.alert = False
    row_EBA1B.enabled = True
    row_EBA1B.active = True
    row_EBA1B.use_property_split = False
    row_EBA1B.use_property_decorate = False
    row_EBA1B.scale_x = 1.0
    row_EBA1B.scale_y = 1.0
    row_EBA1B.alignment = 'Expand'.upper()
    if not False: row_EBA1B.operator_context = "EXEC_DEFAULT"
    row_EBA1B.label(text=str(price) + '€', icon_value=0)
    row_EBA1B.separator(factor=0.0)
    op = row_EBA1B.operator('wm.url_open', text='En savoir +', icon_value=0, emboss=True, depress=False)
    op.url = lien
    row_37884.label(text='', icon_value=0)


def sna_getmatidlist_FA08E(Collection):
    zone_material['sna_materiallist'] = []
    for i_3149C in range(len(Collection)):
        if property_exists("Collection[i_3149C].sna_materialpointer", globals(), locals()):
            if (property_exists("Collection[i_3149C].sna_materialpointer.genericproduct", globals(), locals()) and property_exists("Collection[i_3149C].sna_materialpointer.genericproduct.id", globals(), locals()) and eval("Collection[i_3149C].sna_materialpointer.genericproduct.id != ''") and eval("Collection[i_3149C].users > 1")):
                zone_material['sna_materiallist'].append(Collection[i_3149C].sna_materialpointer.genericproduct.id)
    return zone_material['sna_materiallist']


class SNA_OT_Voirplusmat_61040(bpy.types.Operator):
    bl_idname = "sna.voirplusmat_61040"
    bl_label = "VoirPlusMat"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_nom: bpy.props.StringProperty(name='Nom', description='', default='', subtype='NONE', maxlen=0)
    sna_id: bpy.props.StringProperty(name='ID', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        zone_material['sna_filtermat'] = ''
        zone_de_recherche['sna_debut'] = eval('False')
        zone_material['sna_filtermat'] = sna_filtrememetypemat_D7A79(self.sna_nom, self.sna_nom)
        zone_recherche_plus['sna_filter3d'] = 'FALSE'
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Paint_Prepare_F15Ce(bpy.types.Operator):
    bl_idname = "sna.paint_prepare_f15ce"
    bl_label = "Paint_prepare"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_id: bpy.props.StringProperty(name='ID', description='', default='', subtype='NONE', maxlen=0)
    sna_filepath: bpy.props.StringProperty(name='filepath', description='', default='', subtype='FILE_PATH', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.wm.call_panel(name="SNA_PT_aide_57865", keep_open=False)
        area_F9FF4 = find_area_by_type(bpy.context.screen, 'VIEW_3D', 0)
        region_F9FF4 = getattr(find_area_by_type(bpy.context.screen, 'VIEW_3D', 0), 'regions', None)[-1]
        with bpy.context.temp_override(area=area_F9FF4, region=region_F9FF4, ):
            sna_loadmaterial_AF1C1(self.sna_filepath, self.sna_id)
            bpy.ops.sna.paint_e2084('INVOKE_DEFAULT', )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_aide_57865(bpy.types.Panel):
    bl_label = ''
    bl_idname = 'SNA_PT_aide_57865'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='Cliquer sur une surface', icon_value=0)


_E2084_running = False
class SNA_OT_Paint_E2084(bpy.types.Operator):
    bl_idname = "sna.paint_e2084"
    bl_label = "Paint"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    cursor = "EYEDROPPER"
    _handle = None
    _event = {}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        if not False or context.area.spaces[0].bl_rna.identifier == 'SpaceNodeEditor':
            return not False
        return False

    def save_event(self, event):
        event_options = ["type", "value", "alt", "shift", "ctrl", "oskey", "mouse_region_x", "mouse_region_y", "mouse_x", "mouse_y", "pressure", "tilt"]
        if bpy.app.version >= (3, 2, 1):
            event_options += ["type_prev", "value_prev"]
        for option in event_options: self._event[option] = getattr(event, option)

    def draw_callback_px(self, context):
        event = self._event
        if event.keys():
            event = dotdict(event)
            try:
                pass
            except Exception as error:
                print(error)

    def execute(self, context):
        global _E2084_running
        _E2084_running = False
        context.window.cursor_set("DEFAULT")
        if (None != zone_material['sna_object']):
            if 'sna_structure' in zone_material['sna_object']:
                bm_CDBFC = bmesh.new()
                if zone_material['sna_object']:
                    if zone_material['sna_object'].mode == 'EDIT' and False:
                        bm_CDBFC = bmesh.from_edit_mesh(zone_material['sna_object'].data)
                    else:
                        if False:
                            dg = bpy.context.evaluated_depsgraph_get()
                            bm_CDBFC.from_mesh(zone_material['sna_object'].evaluated_get(dg).to_mesh())
                        else:
                            bm_CDBFC.from_mesh(zone_material['sna_object'].data)
                if False:
                    bm_CDBFC.transform(zone_material['sna_object'].matrix_world)
                bm_CDBFC.verts.ensure_lookup_table()
                bm_CDBFC.faces.ensure_lookup_table()
                bm_CDBFC.edges.ensure_lookup_table()
                zone_material['sna_object'].active_material_index = bm_CDBFC.faces[zone_material['sna_faceindex']].material_index
                bpy.context.view_layer.objects.active = zone_material['sna_object']
                bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
                zone_material['sna_object'].select_set(state=eval('True'), view_layer=bpy.context.view_layer, )
                bpy.ops.view3d.materialutilities_assign_material_object('INVOKE_DEFAULT', material_name=eval("zone_material['sna_newmaterial'].name"), override_type='OVERRIDE_CURRENT')
                bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
                sna_main_bottom_D6C7A()
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}

    def modal(self, context, event):
        global _E2084_running
        if not context.area or not _E2084_running:
            self.execute(context)
            return {'CANCELLED'}
        self.save_event(event)
        context.window.cursor_set('EYEDROPPER')
        try:
            context.window.cursor_set('EYEDROPPER')
            if (event.type == 'LEFTMOUSE' and event.value == 'PRESS' and event.alt == False and event.shift == False and event.ctrl == False):
                zone_material['sna_faceindex'] = sna_node_58D55_5B174((event.mouse_region_x, event.mouse_region_y), False)[2]
                zone_material['sna_object'] = bpy.data.objects[eval("sna_node_58D55_5B174((event.mouse_region_x, event.mouse_region_y), False)[0].name")]
                zone_de_recherche['sna_debut'] = True
                if event.type in ['RIGHTMOUSE', 'ESC']:
                    self.execute(context)
                    return {'CANCELLED'}
                self.execute(context)
                return {"FINISHED"}
        except Exception as error:
            print(error)
        if event.type in ['RIGHTMOUSE', 'ESC']:
            self.execute(context)
            return {'CANCELLED'}
        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        global _E2084_running
        if _E2084_running:
            _E2084_running = False
            return {'FINISHED'}
        else:
            self.save_event(event)
            self.start_pos = (event.mouse_x, event.mouse_y)
            zone_material['sna_object'] = None
            zone_material['sna_materials'] = None
            context.window.cursor_set('EYEDROPPER')
            context.window_manager.modal_handler_add(self)
            _E2084_running = True
            return {'RUNNING_MODAL'}


def sna_button_voir_plus_mat_2EFCA(layout_function, nom):
    col_B2553 = layout_function.column(heading='', align=False)
    col_B2553.alert = False
    col_B2553.enabled = True
    col_B2553.active = True
    col_B2553.use_property_split = False
    col_B2553.use_property_decorate = False
    col_B2553.scale_x = 1.0
    col_B2553.scale_y = 2.0
    col_B2553.alignment = 'Expand'.upper()
    if not True: col_B2553.operator_context = "EXEC_DEFAULT"
    op = col_B2553.operator('sna.voirplusmat_61040', text='Voir plus de produits', icon_value=0, emboss=eval('True'), depress=eval('False'))
    op.sna_nom = nom
    op.sna_id = ''


class SNA_OT_Voirplus_Cec25(bpy.types.Operator):
    bl_idname = "sna.voirplus_cec25"
    bl_label = "VoirPlus"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_nom: bpy.props.StringProperty(name='Nom', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        zone_recherche_plus['sna_filter3d'] = ''
        zone_de_recherche['sna_debut'] = eval('False')
        zone_recherche_plus['sna_filter3d'] = sna_filtrememetype3d_1BFCC(self.sna_nom, '')
        zone_material['sna_filtermat'] = 'FALSE'
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_filtrememetype3d_1BFCC(Nom, ID):
    return 'type' + ' = ' + '(SELECT ' + 'type' + '  FROM ' + 'Zago_Officiel ' + ' WHERE ' + ('Nom' if eval("Nom != ''") else 'id') + " = '" + (Nom if eval("Nom != ''") else ID) + "')"


class SNA_OT_Retourner_60C49(bpy.types.Operator):
    bl_idname = "sna.retourner_60c49"
    bl_label = "Retourner"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        zone_de_recherche['sna_debut'] = bool(1)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_main_bottom_D6C7A():
    sna_eevee_render_BE76B()
    sna_loadimages_9657B()
    if (property_exists("find_area_by_type(bpy.context.screen, 'VIEW_3D', 0)", globals(), locals()) and property_exists("find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).regions[-1]", globals(), locals())):
        area_11136 = find_area_by_type(bpy.context.screen, 'VIEW_3D', 0)
        region_11136 = find_area_by_type(bpy.context.screen, 'VIEW_3D', 0).regions[-1]
        with bpy.context.temp_override(area=area_11136, region=region_11136, ):
            bpy.ops.sna.click_check_3a2a1('INVOKE_DEFAULT', )


def sna_add_to_view3d_ht_header_92465(self, context):
    if not (False):
        layout = self.layout
        layout.separator(factor=-0.04999995231628418)
        op = layout.operator('sna.calculer_cea9d', text='Rendu image', icon_value=258, emboss=True, depress=False)
        op.sna_filepath = r''
        op = layout.operator('sna.terminer_7fdfe', text='Terminer mon projet', icon_value=693, emboss=True, depress=False)
        op = layout.operator('sna.reinitialiser_3b8dd', text='Réinitialiser', icon_value=3, emboss=True, depress=False)
        layout.separator(factor=5.0)
        layout_function = layout
        sna_movebuttons_B8309(layout_function, )
        layout.separator(factor=1.0)
        layout_function = layout
        sna_rotatebuttons_E0B3D(layout_function, )
        layout.separator(factor=0.3700000047683716)
        op = layout.operator('sna.effacer_82a47', text='', icon_value=21, emboss=False, depress=False)
        if bpy.context.scene.sna_globalhide:
            layout.separator(factor=5000.0)


class SNA_GROUP_sna_custombuttonsgroup(bpy.types.PropertyGroup):
    width: bpy.props.IntProperty(name='width', description='', options={'HIDDEN'}, default=100, subtype='PIXEL', min=0)
    height: bpy.props.IntProperty(name='height', description='', options={'HIDDEN'}, default=100, subtype='PIXEL', min=0)
    location: bpy.props.FloatVectorProperty(name='location', description='', size=2, default=(0.0, 0.0), subtype='COORDINATES', unit='NONE', step=3, precision=2)
    camera: bpy.props.PointerProperty(name='camera', description='', type=bpy.types.Object)
    image: bpy.props.StringProperty(name='image', description='', options={'HIDDEN'}, default='', subtype='FILE_PATH', maxlen=0)


class SNA_GROUP_sna_product(bpy.types.PropertyGroup):
    nom: bpy.props.StringProperty(name='Nom', description='Nom du meuble', default='', subtype='NONE', maxlen=0)
    object: bpy.props.PointerProperty(name='Object', description='Placed object', type=bpy.types.Object)
    prix: bpy.props.FloatProperty(name='Prix', description='', default=0.0, subtype='NONE', unit='NONE', min=0.0, step=3, precision=2)


def sna_pivot_enum_items(self, context):
    return [("No Items", "No Items", "No generate enum items node found to create items!", "ERROR", 0)]


def sna_platform_enum_items(self, context):
    return [("No Items", "No Items", "No generate enum items node found to create items!", "ERROR", 0)]


def sna_update_sna_globalhide(self, context):
    sna_update_sna_globalhide_8AD9B(self, context)
    sna_update_sna_globalhide_A5A3D(self, context)


def sna_matslots_enum_items(self, context):
    return [("No Items", "No Items", "No generate enum items node found to create items!", "ERROR", 0)]


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_GROUP_sna_custombuttonsgroup)
    bpy.utils.register_class(SNA_GROUP_sna_product)
    bpy.types.Scene.sna_active_workspace = bpy.props.StringProperty(name='Active workspace', description='', default='Double', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_button_emboss = bpy.props.BoolProperty(name='button_emboss', description='', default=True)
    bpy.types.Scene.sna_show_toolbar = bpy.props.BoolProperty(name='show_toolbar', description='', default=True, update=sna_update_sna_show_toolbar_FBEFC)
    bpy.types.Scene.sna_search_term = bpy.props.StringProperty(name='Search_term', description='', default='Que recherchez-vous?', subtype='NONE', maxlen=100, update=sna_update_sna_search_term_9FC8E)
    bpy.types.Scene.sna_trier = bpy.props.EnumProperty(name='Trier', description='', items=sna_trier_enum_items, update=sna_update_sna_trier_61CB3)
    bpy.types.Scene.sna_tailles = bpy.props.EnumProperty(name='Tailles', description='', items=[('Taille 1', 'Taille 1', '', 0, 0), ('Taille 2', 'Taille 2', '', 0, 1)])
    bpy.types.Scene.sna_marques = bpy.props.EnumProperty(name='Marques', description='', items=[('Marque 1', 'Marque 1', '', 0, 0), ('Marque 2', 'Marque 2', '', 0, 1)])
    bpy.types.Scene.sna_couleurs = bpy.props.EnumProperty(name='Couleurs', description='', items=sna_couleurs_enum_items)
    bpy.types.Scene.sna_type = bpy.props.EnumProperty(name='Type', description='', items=[('Type 1', 'Type 1', '', 0, 0), ('Type 2', 'Type 2', '', 0, 1)])
    bpy.types.Scene.sna_prix = bpy.props.EnumProperty(name='Prix', description='', items=sna_prix_enum_items)
    bpy.types.Scene.sna_prixcroissant = bpy.props.BoolProperty(name='prixCroissant', description='Sort ascendently by the price', default=False)
    bpy.types.Scene.sna_vue = bpy.props.EnumProperty(name='Vue', description='', items=[('Biblio', 'Biblio', '', 0, 0), ('3D', '3D', '', 0, 1), ('Double', 'Double', '', 0, 2)])
    bpy.types.Scene.sna_database_parent = bpy.props.StringProperty(name='Database Parent', description='Path of all images, prices, weblink, and blend file', default='//Zago officiel', subtype='DIR_PATH', maxlen=0)
    bpy.types.Scene.sna_filepath = bpy.props.StringProperty(name='filePath', description='', default='L:\\#Prod\\Leon\\3DWarehouse-Lib\\YOKO-SOF3P02.blend', subtype='FILE_PATH', maxlen=0)
    bpy.types.Scene.sna_productperrow = bpy.props.IntProperty(name='ProductPerRow', description='', default=2, subtype='NONE', min=1, max=6)
    bpy.types.Scene.sna_editdisplay = bpy.props.BoolProperty(name='editDisplay', description='Automatique', default=False)
    bpy.types.Object.sna_pivot = bpy.props.EnumProperty(name='Pivot', description='', items=[('None', 'None', '', 0, 0), ('Sol', 'Sol', '', 0, 1), ('Mur', 'Mur', '', 0, 2), ('Plafond', 'Plafond', '', 0, 3)])
    bpy.types.Object.sna_structure = bpy.props.EnumProperty(name='Structure', description='', items=[('None', 'None', '', 0, 0), ('Sol', 'Sol', '', 0, 1), ('Mur', 'Mur', '', 0, 2), ('Plafond', 'Plafond', '', 0, 3)])
    bpy.types.Scene.sna_tmpfolder = bpy.props.StringProperty(name='tmpfolder', description='', default='//.tmp', subtype='DIR_PATH', maxlen=0)
    bpy.types.Object.sna_custombutton = bpy.props.PointerProperty(name='customButton', description='', type=SNA_GROUP_sna_custombuttonsgroup)
    bpy.types.Scene.sna_custombuttons = bpy.props.CollectionProperty(name='customButtons', description='', type=SNA_GROUP_sna_custombuttonsgroup)
    bpy.types.Scene.sna_d_area_width = bpy.props.IntProperty(name='3d Area width', description='', default=0, subtype='PIXEL', min=0)
    bpy.types.Scene.sna_platform = bpy.props.EnumProperty(name='Platform', description='', items=[('PC', 'PC', '', 0, 0), ('Mobile', 'Mobile', '', 0, 1)])
    bpy.types.Scene.sna_globalhide = bpy.props.BoolProperty(name='GlobalHide', description='temporarily Hide the effect of this addon', default=True, update=sna_update_sna_globalhide)
    bpy.types.Scene.sna_freeplace = bpy.props.BoolProperty(name='FreePlace', description='place freely objects', default=True)
    bpy.types.Scene.sna_listemeubles = bpy.props.CollectionProperty(name='ListeMeubles', description='', type=SNA_GROUP_sna_product)
    bpy.types.Scene.sna_listematriaux = bpy.props.CollectionProperty(name='ListeMatériaux', description='', type=bpy.types.PropertyGroup.__subclasses__()[0])
    bpy.types.Scene.sna_thisproduct = bpy.props.PointerProperty(name='ThisProduct', description='', type=SNA_GROUP_sna_product)
    bpy.types.Scene.sna_index = bpy.props.IntProperty(name='Index', description='Index for the ListeMeubles collection', default=0, subtype='NONE')
    bpy.types.Scene.sna_prixpiece = bpy.props.FloatProperty(name='PrixPiece', description='', default=0.0, subtype='NONE', unit='NONE', min=0.0, step=3, precision=2)
    bpy.types.Scene.sna_texte_scene = bpy.props.StringProperty(name='Texte_Scene', description='', default='Sélectionnez le produit pour votre projet', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_matindex = bpy.props.IntProperty(name='matIndex', description='Index of the material to replace in the collection list', default=0, subtype='NONE', min=0)
    bpy.types.Scene.sna_matslots = bpy.props.EnumProperty(name='matSlots', description='', items=sna_matslots_enum_items)
    bpy.types.Scene.sna_renderingcamindex = bpy.props.IntProperty(name='renderingCamIndex', description='', default=0, subtype='NONE')
    bpy.utils.register_class(SNA_OT_Batch_Render_Cb8Fd)
    bpy.utils.register_class(SNA_OT_Click_Check_3A2A1)
    bpy.app.handlers.load_post.append(load_post_handler_FDB46)
    bpy.utils.register_class(SNA_OT_Clean_Top_Bar_8853A)
    bpy.types.TOPBAR_HT_upper_bar.prepend(sna_add_to_topbar_ht_upper_bar_8C538)
    bpy.types.VIEW3D_PT_tools_active.prepend(sna_add_to_view3d_pt_tools_active_6EE17)
    bpy.utils.register_class(SNA_OT_Calculer_Cea9D)
    bpy.types.VIEW3D_HT_tool_header.prepend(sna_add_to_view3d_ht_tool_header_4990D)
    bpy.types.IMAGE_HT_header.prepend(sna_add_to_image_ht_header_1EA36)
    bpy.utils.register_class(SNA_OT_Terminer_7Fdfe)
    bpy.types.VIEW3D_PT_tools_active.prepend(sna_add_to_view3d_pt_tools_active_B1403)
    bpy.utils.register_class(SNA_OT_Effacer_82A47)
    bpy.app.handlers.load_post.append(load_post_handler_B1103)
    bpy.utils.register_class(SNA_OT_Reinitialiser_3B8Dd)
    bpy.utils.register_class(SNA_OT_Move_Ad916)
    bpy.app.handlers.load_pre.append(load_pre_handler_AB2EC)
    bpy.utils.register_class(SNA_OT_Rotate_39Ac0)
    bpy.utils.register_class(SNA_PT_NEW_PANEL_B8E48)
    bpy.utils.register_class(SNA_PT_NEW_PANEL_AC978)
    bpy.utils.register_class(SNA_OT_List_6D562)
    bpy.app.handlers.load_pre.append(load_pre_handler_5A8E2)
    bpy.utils.register_class(SNA_OT_Global_Hide_8A754)
    bpy.utils.register_class(SNA_OT_Choose_Platform_E9D97)
    bpy.utils.register_class(SNA_OT_Toggle_Globalhide_Aeafd)
    bpy.app.handlers.load_post.append(load_post_handler_5BC94)
    bpy.app.handlers.load_post.append(load_post_handler_BB9E5)
    bpy.app.handlers.load_post.append(load_post_handler_B49B0)
    bpy.app.handlers.load_post.append(load_post_handler_34F67)
    bpy.utils.register_class(Batchrender)
    bpy.app.handlers.load_post.append(load_post_handler_471C4)
    bpy.utils.register_class(SNA_OT_Operator_57A70)
    bpy.utils.register_class(SNA_PT_AIDE_38B46)
    bpy.utils.register_class(SNA_PT_wrong_place_469A0)
    bpy.utils.register_class(SNA_PT_REMPLACER_A6840)
    bpy.utils.register_class(SNA_OT_Place_387A2)
    bpy.utils.register_class(SNA_OT_Append_And_Replace_F53E9)
    bpy.utils.register_class(SNA_OT_Append_And_Move_0Eba8)
    bpy.utils.register_class(SNA_AddonPreferences_588F5)
    bpy.types.PROPERTIES_PT_navigation_bar.prepend(sna_add_to_properties_pt_navigation_bar_D8EF4)
    bpy.types.PROPERTIES_HT_header.prepend(sna_add_to_properties_ht_header_26849)
    bpy.types.TOPBAR_HT_upper_bar.append(sna_add_to_topbar_ht_upper_bar_14A26)
    bpy.utils.register_class(SNA_PT_RENDU_FINI_79A39)
    bpy.utils.register_class(SNA_OT_Switch_Workspace_15E45)
    bpy.app.handlers.load_post.append(load_post_handler_85AB2)
    bpy.utils.register_class(SNA_PT_NEW_PANEL_88C1D)
    bpy.utils.register_class(SNA_PT_FILTRES_96594)
    bpy.app.handlers.load_post.append(load_post_handler_900C8)
    bpy.utils.register_class(SNA_PT_NEW_PANEL_9CADE)
    bpy.utils.register_class(SNA_OT_Voirplusmat_61040)
    bpy.utils.register_class(SNA_OT_Paint_Prepare_F15Ce)
    bpy.utils.register_class(SNA_PT_aide_57865)
    bpy.utils.register_class(SNA_OT_Paint_E2084)
    bpy.utils.register_class(SNA_OT_Voirplus_Cec25)
    bpy.utils.register_class(SNA_OT_Retourner_60C49)
    kc = bpy.context.window_manager.keyconfigs.addon
    km = kc.keymaps.new(name='Window', space_type='EMPTY')
    kmi = km.keymap_items.new('sna.toggle_globalhide_aeafd', 'Y', 'PRESS',
        ctrl=True, alt=True, shift=True, repeat=False)
    addon_keymaps['88F80'] = (km, kmi)
    bpy.types.VIEW3D_HT_header.prepend(sna_add_to_view3d_ht_header_92465)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_renderingcamindex
    del bpy.types.Scene.sna_matslots
    del bpy.types.Scene.sna_matindex
    del bpy.types.Scene.sna_texte_scene
    del bpy.types.Scene.sna_prixpiece
    del bpy.types.Scene.sna_index
    del bpy.types.Scene.sna_thisproduct
    del bpy.types.Scene.sna_listematriaux
    del bpy.types.Scene.sna_listemeubles
    del bpy.types.Scene.sna_freeplace
    del bpy.types.Scene.sna_globalhide
    del bpy.types.Scene.sna_platform
    del bpy.types.Scene.sna_d_area_width
    del bpy.types.Scene.sna_custombuttons
    del bpy.types.Object.sna_custombutton
    del bpy.types.Scene.sna_tmpfolder
    del bpy.types.Object.sna_structure
    del bpy.types.Object.sna_pivot
    del bpy.types.Scene.sna_editdisplay
    del bpy.types.Scene.sna_productperrow
    del bpy.types.Scene.sna_filepath
    del bpy.types.Scene.sna_database_parent
    del bpy.types.Scene.sna_vue
    del bpy.types.Scene.sna_prixcroissant
    del bpy.types.Scene.sna_prix
    del bpy.types.Scene.sna_type
    del bpy.types.Scene.sna_couleurs
    del bpy.types.Scene.sna_marques
    del bpy.types.Scene.sna_tailles
    del bpy.types.Scene.sna_trier
    del bpy.types.Scene.sna_search_term
    del bpy.types.Scene.sna_show_toolbar
    del bpy.types.Scene.sna_button_emboss
    del bpy.types.Scene.sna_active_workspace
    bpy.utils.unregister_class(SNA_GROUP_sna_product)
    bpy.utils.unregister_class(SNA_GROUP_sna_custombuttonsgroup)
    bpy.utils.unregister_class(SNA_OT_Batch_Render_Cb8Fd)
    bpy.utils.unregister_class(SNA_OT_Click_Check_3A2A1)
    bpy.app.handlers.load_post.remove(load_post_handler_FDB46)
    bpy.utils.unregister_class(SNA_OT_Clean_Top_Bar_8853A)
    bpy.types.TOPBAR_HT_upper_bar.remove(sna_add_to_topbar_ht_upper_bar_8C538)
    bpy.types.VIEW3D_PT_tools_active.remove(sna_add_to_view3d_pt_tools_active_6EE17)
    bpy.utils.unregister_class(SNA_OT_Calculer_Cea9D)
    bpy.types.VIEW3D_HT_tool_header.remove(sna_add_to_view3d_ht_tool_header_4990D)
    bpy.types.IMAGE_HT_header.remove(sna_add_to_image_ht_header_1EA36)
    bpy.utils.unregister_class(SNA_OT_Terminer_7Fdfe)
    bpy.types.VIEW3D_PT_tools_active.remove(sna_add_to_view3d_pt_tools_active_B1403)
    bpy.utils.unregister_class(SNA_OT_Effacer_82A47)
    bpy.app.handlers.load_post.remove(load_post_handler_B1103)
    bpy.utils.unregister_class(SNA_OT_Reinitialiser_3B8Dd)
    bpy.utils.unregister_class(SNA_OT_Move_Ad916)
    bpy.app.handlers.load_pre.remove(load_pre_handler_AB2EC)
    bpy.utils.unregister_class(SNA_OT_Rotate_39Ac0)
    bpy.utils.unregister_class(SNA_PT_NEW_PANEL_B8E48)
    bpy.utils.unregister_class(SNA_PT_NEW_PANEL_AC978)
    bpy.utils.unregister_class(SNA_OT_List_6D562)
    bpy.app.handlers.load_pre.remove(load_pre_handler_5A8E2)
    bpy.utils.unregister_class(SNA_OT_Global_Hide_8A754)
    bpy.utils.unregister_class(SNA_OT_Choose_Platform_E9D97)
    bpy.utils.unregister_class(SNA_OT_Toggle_Globalhide_Aeafd)
    bpy.app.handlers.load_post.remove(load_post_handler_5BC94)
    bpy.app.handlers.load_post.remove(load_post_handler_BB9E5)
    bpy.app.handlers.load_post.remove(load_post_handler_B49B0)
    bpy.app.handlers.load_post.remove(load_post_handler_34F67)
    bpy.utils.unregister_class(Batchrender)
    bpy.app.handlers.load_post.remove(load_post_handler_471C4)
    bpy.utils.unregister_class(SNA_OT_Operator_57A70)
    bpy.utils.unregister_class(SNA_PT_AIDE_38B46)
    bpy.utils.unregister_class(SNA_PT_wrong_place_469A0)
    bpy.utils.unregister_class(SNA_PT_REMPLACER_A6840)
    bpy.utils.unregister_class(SNA_OT_Place_387A2)
    bpy.utils.unregister_class(SNA_OT_Append_And_Replace_F53E9)
    bpy.utils.unregister_class(SNA_OT_Append_And_Move_0Eba8)
    bpy.utils.unregister_class(SNA_AddonPreferences_588F5)
    bpy.types.PROPERTIES_PT_navigation_bar.remove(sna_add_to_properties_pt_navigation_bar_D8EF4)
    bpy.types.PROPERTIES_HT_header.remove(sna_add_to_properties_ht_header_26849)
    bpy.types.TOPBAR_HT_upper_bar.remove(sna_add_to_topbar_ht_upper_bar_14A26)
    bpy.utils.unregister_class(SNA_PT_RENDU_FINI_79A39)
    bpy.utils.unregister_class(SNA_OT_Switch_Workspace_15E45)
    bpy.app.handlers.load_post.remove(load_post_handler_85AB2)
    bpy.utils.unregister_class(SNA_PT_NEW_PANEL_88C1D)
    bpy.utils.unregister_class(SNA_PT_FILTRES_96594)
    bpy.app.handlers.load_post.remove(load_post_handler_900C8)
    bpy.utils.unregister_class(SNA_PT_NEW_PANEL_9CADE)
    bpy.utils.unregister_class(SNA_OT_Voirplusmat_61040)
    bpy.utils.unregister_class(SNA_OT_Paint_Prepare_F15Ce)
    bpy.utils.unregister_class(SNA_PT_aide_57865)
    bpy.utils.unregister_class(SNA_OT_Paint_E2084)
    bpy.utils.unregister_class(SNA_OT_Voirplus_Cec25)
    bpy.utils.unregister_class(SNA_OT_Retourner_60C49)
    bpy.types.VIEW3D_HT_header.remove(sna_add_to_view3d_ht_header_92465)
