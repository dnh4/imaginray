# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Appart Deco",
    "author" : "Kevinn", 
    "description" : "",
    "blender" : (3, 0, 0),
    "version" : (1, 0, 2),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import os
from bpy.app.handlers import persistent
import mathutils
from bpy.types import Object
import math


addon_keymaps = {}
_icons = None
lights = {'sna_sol': None, 'sna_ouverture': None, 'sna_sun': None, }


def sna_getdatabase_69E32_0A230(Filepath, ColumnNames, ColumnConditions, CheckValues, TableName, isTransposed, orderBy, Ascendent):
    import sqlite3

    def get_database_item(FilePath: str, ColumnNames, ColumnConditions, CheckValues:list, TableName: str, isTransposed:str = True, orderBy:str = None, Ascendent:bool = True ):
        conditions = ColumnConditions
        if not os.path.isfile(FilePath):
            return [None, None, None]
        connection = sqlite3.connect(FilePath)
        cursor = connection.cursor()
        # Set the condition for the columns
        columns = ','.join(ColumnNames) if len(ColumnNames) != 0 else '*'
        # filters
        filters = f'WHERE {" AND ".join(conditions)}' if len(conditions) > 0 else ''
        order = f"ORDER BY {orderBy} {'ASC' if Ascendent else 'DESC'}" if orderBy is not None else ""
        # Generate the SELECT statement using an f-string
        select_stmt = f"SELECT {columns} FROM {TableName} {filters} {order}"
        # select_stmt = f"SELECT {columns} FROM {TableName} WHERE Nom Like ?"
        results = []
        try:
            cursor.execute(select_stmt, CheckValues)
            # Fetch the results
            results = cursor.fetchall()
            nbResults = len(results)
            # trasnpose the list
            if isTransposed:
                results = [list(item) for item in list(zip(*results))]
        except:
            nbResults = 0
        # Commit the changes
        connection.commit()
        # Close the connection
        connection.close()
        return [nbResults, results]
    if __name__ == '__main__':
        path = r"L:\#Prod\Leon\3DWarehouse-Lib\Zago officiel\Zago-Officiel.db"
        # get_database_item()
        db = get_database_item(path, ColumnNames=['Nom', 'Prix'], ColumnConditions=['Prix IS NOT NULL',"Nom LIKE '%lit%' OR Nom LIKE '%rouge%'"], CheckValues=[], TableName= 'Zago_Officiel')
        print(db[-1])
    return_7362F = get_database_item(FilePath=Filepath, ColumnNames=ColumnNames, ColumnConditions=ColumnConditions, CheckValues=CheckValues, TableName=TableName, isTransposed=isTransposed, orderBy=orderBy, Ascendent=Ascendent)
    return [return_7362F[0], return_7362F[1]]


def get_blend_contents(path, data_type):
    if os.path.exists(path):
        with bpy.data.libraries.load(path) as (data_from, data_to):
            return getattr(data_from, data_type)
    return []


def display_collection_id(uid, vars):
    id = f"coll_{uid}"
    for var in vars.keys():
        if var.startswith("i_"):
            id += f"_{var}_{vars[var]}"
    return id


class SNA_UL_display_collection_list_FF513(bpy.types.UIList):

    def draw_item(self, context, layout, data, item_FF513, icon, active_data, active_propname, index_FF513):
        row = layout
        if property_exists("item_FF513.name", globals(), locals()):
            layout.label(text=item_FF513.name, icon_value=287)
        op = layout.operator('sna.delete_f7cfc', text='', icon_value=19, emboss=True, depress=False)
        op.sna_obj_name = item_FF513.name

    def filter_items(self, context, data, propname):
        flt_flags = []
        for item in getattr(data, propname):
            if not self.filter_name or self.filter_name.lower() in item.name.lower():
                if True:
                    flt_flags.append(self.bitflag_filter_item)
                else:
                    flt_flags.append(0)
            else:
                flt_flags.append(0)
        return flt_flags, []


def property_exists(prop_path, glob, loc):
    try:
        eval(prop_path, glob, loc)
        return True
    except:
        return False


def sna_update_sna_index_7D7ED(self, context):
    sna_updated_prop = self.sna_index
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.data.objects[sna_updated_prop].select_set(state=True, )
    bpy.context.view_layer.objects.active = bpy.data.objects[sna_updated_prop]


_item_map = dict()


def make_enum_item(_id, name, descr, preview_id, uid):
    lookup = str(_id)+"\0"+str(name)+"\0"+str(descr)+"\0"+str(preview_id)+"\0"+str(uid)
    if not lookup in _item_map:
        _item_map[lookup] = (_id, name, descr, preview_id, uid)
    return _item_map[lookup]


class SNA_PT_ASSIGN_PROPERTIES_TO_FILES_CDAEE(bpy.types.Panel):
    bl_label = 'Assign properties to files'
    bl_idname = 'SNA_PT_ASSIGN_PROPERTIES_TO_FILES_CDAEE'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'AppartDeco'
    bl_order = 2
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.prop(bpy.context.scene, 'sna_database', text='Database file', icon_value=0, emboss=True)
        layout.prop(bpy.context.scene, 'sna_tablename', text='Table name', icon_value=0, emboss=True)
        op = layout.operator('sn.dummy_button_operator', text='Assign', icon_value=0, emboss=True, depress=False)


class SNA_OT_Assignprops_Ef6F9(bpy.types.Operator):
    bl_idname = "sna.assignprops_ef6f9"
    bl_label = "AssignProps"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_525D5 in range(len(sna_getdatabase_69E32_0A230(bpy.path.abspath(bpy.context.scene.sna_database), 'Fichier, Type'.split(','), [], [], bpy.context.scene.sna_tablename, True, 'Type', False)[1][0])):
            if eval("i_525D5 == 0"):
                print(bpy.path.abspath(sna_getdatabase_69E32_0A230(bpy.path.abspath(bpy.context.scene.sna_database), 'Fichier, Type'.split(','), [], [], bpy.context.scene.sna_tablename, True, 'Type', False)[1][0][i_525D5]), str(eval("i_525D5 == 0")), str(get_blend_contents(bpy.path.abspath(sna_getdatabase_69E32_0A230(bpy.path.abspath(bpy.context.scene.sna_database), 'Fichier, Type'.split(','), [], [], bpy.context.scene.sna_tablename, True, 'Type', False)[1][0][i_525D5]), 'objects')))
                bpy.ops.wm.open_mainfile(filepath=bpy.path.abspath(sna_getdatabase_69E32_0A230(bpy.path.abspath(bpy.context.scene.sna_database), 'Fichier, Type'.split(','), [], [], bpy.context.scene.sna_tablename, True, 'Type', False)[1][0][i_525D5]))
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Openfile_6Affe(bpy.types.Operator):
    bl_idname = "sna.openfile_6affe"
    bl_label = "OpenFile"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_filepath: bpy.props.StringProperty(name='filepath', description='', default='', subtype='FILE_PATH', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.wm.open_mainfile(filepath=self.sna_filepath)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_LISTE_DE_PRODUITS_PLACS_B56D9(bpy.types.Panel):
    bl_label = 'Liste de produits placés'
    bl_idname = 'SNA_PT_LISTE_DE_PRODUITS_PLACS_B56D9'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'AppartDeco'
    bl_order = 1
    bl_options = {'DEFAULT_CLOSED'}
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_2A663 = layout.row(heading='', align=False)
        row_2A663.alert = False
        row_2A663.enabled = True
        row_2A663.active = True
        row_2A663.use_property_split = False
        row_2A663.use_property_decorate = False
        row_2A663.scale_x = 1.0
        row_2A663.scale_y = 1.0
        row_2A663.alignment = 'Expand'.upper()
        if not True: row_2A663.operator_context = "EXEC_DEFAULT"
        coll_id = display_collection_id('FF513', locals())
        row_2A663.template_list('SNA_UL_display_collection_list_FF513', coll_id, bpy.data, 'objects', bpy.context.scene, 'sna_index', rows=0)
        row_2A663.prop(bpy.context.scene, 'sna_filtre_couleur', text='Filtre couleur', icon_value=0, emboss=True)


class SNA_OT_Delete_F7Cfc(bpy.types.Operator):
    bl_idname = "sna.delete_f7cfc"
    bl_label = "Delete"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_obj_name: bpy.props.StringProperty(name='Obj name', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.data.objects.remove(object=bpy.data.objects[self.sna_obj_name], do_unlink=True, do_id_user=True, do_ui_user=True, )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_LUMIRES_4EFEC(bpy.types.Panel):
    bl_label = 'Lumières'
    bl_idname = 'SNA_PT_LUMIRES_4EFEC'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'AppartDeco'
    bl_order = 3
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        box_80AEE = layout.box()
        box_80AEE.alert = False
        box_80AEE.enabled = True
        box_80AEE.active = True
        box_80AEE.use_property_split = False
        box_80AEE.use_property_decorate = False
        box_80AEE.alignment = 'Expand'.upper()
        box_80AEE.scale_x = 1.0
        box_80AEE.scale_y = 1.0
        if not True: box_80AEE.operator_context = "EXEC_DEFAULT"
        col_DB741 = box_80AEE.column(heading='', align=False)
        col_DB741.alert = False
        col_DB741.enabled = True
        col_DB741.active = True
        col_DB741.use_property_split = False
        col_DB741.use_property_decorate = False
        col_DB741.scale_x = 1.0
        col_DB741.scale_y = 1.0
        col_DB741.alignment = 'Expand'.upper()
        if not True: col_DB741.operator_context = "EXEC_DEFAULT"
        row_659B8 = col_DB741.row(heading='', align=False)
        row_659B8.alert = False
        row_659B8.enabled = True
        row_659B8.active = True
        row_659B8.use_property_split = False
        row_659B8.use_property_decorate = False
        row_659B8.scale_x = 1.0
        row_659B8.scale_y = 1.0
        row_659B8.alignment = 'Expand'.upper()
        if not True: row_659B8.operator_context = "EXEC_DEFAULT"
        op = row_659B8.operator('sna.alllights_4e0bb', text='Placer lumières', icon_value=239, emboss=True, depress=False)


def sna_changesky_76488():
    if property_exists("bpy.data.worlds[bpy.context.preferences.addons['appart_deco'].preferences.sna_skyname]", globals(), locals()):
        bpy.data.worlds.remove(world=bpy.data.worlds[bpy.context.preferences.addons['appart_deco'].preferences.sna_skyname], do_unlink=eval('True'), do_id_user=eval('True'), do_ui_user=eval('True'), )
    before_data = list(bpy.data.worlds)
    bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'Lights.blend') + r'\World', filename=bpy.context.preferences.addons['appart_deco'].preferences.sna_skyname, link=False)
    new_data = list(filter(lambda d: not d in before_data, list(bpy.data.worlds)))
    appended_47151 = None if not new_data else new_data[0]
    bpy.context.scene.world = appended_47151


def sna_place_light_plafond_EEEA9(z_offset):
    output_0_cb22d = sna_getstructure_1B718('Plafond')
    if (len(output_0_cb22d) > 0):
        before_data = list(bpy.data.objects)
        bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'Lights.blend') + r'\Object', filename=bpy.context.preferences.addons['appart_deco'].preferences.sna_lightceilingname, link=False)
        new_data = list(filter(lambda d: not d in before_data, list(bpy.data.objects)))
        appended_F4E79 = None if not new_data else new_data[0]
        if property_exists("appended_F4E79", globals(), locals()):
            appended_F4E79.location = (sna_getbottomcenter_8EC07(output_0_cb22d[0])[1][0], sna_getbottomcenter_8EC07(output_0_cb22d[0])[1][1], float(sna_getbottomcenter_8EC07(output_0_cb22d[0])[0] + z_offset))
    else:
        bpy.ops.wm.call_panel(name="SNA_PT_pas_de_plafond_1F3F4", keep_open=False)


class SNA_PT_pas_de_plafond_1F3F4(bpy.types.Panel):
    bl_label = ''
    bl_idname = 'SNA_PT_pas_de_plafond_1F3F4'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='Pas de plafond', icon_value=19)


exec('import numpy as np')


def sna_getbottomcenter_8EC07(MeshObj):
    if MeshObj.type == 'MESH':
        return_0EF48 = [MeshObj.matrix_world @ v.co for v in MeshObj.data.vertices]
        return_BA16C = np.min(return_0EF48, axis=0)[-1]
        return_F3A51 = np.mean(return_0EF48, axis=0)
        return_CE9DD = toVector(return_F3A51)
        return [return_BA16C, return_CE9DD]


def sna_getstructure_1B718(Structure):
    return_38839 = [obj for obj in bpy.data.objects if getattr(obj, 'sna_structure') == Structure]
    return return_38839


def sna_enable_addon_07F92():
    exec('bpy.ops.preferences.addon_enable(module="space_view3d_align_tools")')


@persistent
def load_pre_handler_32C0D(dummy):
    sna_enable_addon_07F92()


from mathutils import Euler, Vector


def mat_rot(euler_rot: Euler):
    return euler_rot.to_matrix()


def toVector(vec):
    return Vector(vec)


def sortByDimension(ObjList: list):
    func = lambda obj: obj.dimensions.x * obj.dimensions.z
    ObjList.sort(key = func, reverse=True)
    return ObjList


def dirToEulerZ(dir):
    y = Vector((0,1,0))
    dir = Vector(dir)
    return y.rotation_difference(dir).to_euler().z


class SNA_OT_Alllights_4E0Bb(bpy.types.Operator):
    bl_idname = "sna.alllights_4e0bb"
    bl_label = "AllLights"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_place_light_plafond_EEEA9(bpy.context.preferences.addons['appart_deco'].preferences.sna_lightceilingoffset)
        sna_changesky_76488()
        sna_place_portal_05F31()
        sna_sun_83880()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_place_portal_05F31():
    output_0_8445c = sna_getstructure_1B718('Ouverture')
    for i_2F228 in range(len(output_0_8445c)):
        if output_0_8445c[i_2F228].type == 'MESH':
            before_data = list(bpy.data.objects)
            bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'Lights.blend') + r'\Object', filename=bpy.context.preferences.addons['appart_deco'].preferences.sna_portalname, link=False)
            new_data = list(filter(lambda d: not d in before_data, list(bpy.data.objects)))
            appended_626B1 = None if not new_data else new_data[0]
            appended_626B1.location = sna_getbottomcenter_8EC07(output_0_8445c[i_2F228])[1]
            appended_626B1.rotation_euler = (math.radians(-90.0), 0.0, 0.0)
            return_52D64 = appended_626B1.rotation_euler.rotate(output_0_8445c[i_2F228].rotation_euler)
            return_26D65 = mat_rot(euler_rot=appended_626B1.rotation_euler)
            return_4E423 = toVector((0.0, 0.0, 0.20000000298023224))
            return_AAA45 = return_26D65 @ return_4E423
            appended_626B1.location = tuple(mathutils.Vector(return_AAA45) + mathutils.Vector(appended_626B1.location))
            sna_setsize_C358C(appended_626B1.data, tuple(mathutils.Vector(output_0_8445c[i_2F228].dimensions) * mathutils.Vector((1.100000023841858, 1.100000023841858, 1.100000023841858)))[0], tuple(mathutils.Vector(output_0_8445c[i_2F228].dimensions) * mathutils.Vector((1.100000023841858, 1.100000023841858, 1.100000023841858)))[2])


def sna_setsize_C358C(light, x, y):
    light.size = x
    light.size_y = y


def sna_sun_83880():
    if property_exists("bpy.data.objects[bpy.context.preferences.addons['appart_deco'].preferences.sna_sunname]", globals(), locals()):
        lights['sna_sun'] = bpy.data.objects[bpy.context.preferences.addons['appart_deco'].preferences.sna_sunname]
    else:
        before_data = list(bpy.data.objects)
        bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'Lights.blend') + r'\Object', filename=bpy.context.preferences.addons['appart_deco'].preferences.sna_sunname, link=False)
        new_data = list(filter(lambda d: not d in before_data, list(bpy.data.objects)))
        appended_C6302 = None if not new_data else new_data[0]
        lights['sna_sun'] = appended_C6302
    direction_0_f0969 = sna_getsundirection_F1B1B()
    return_E6AF1 = dirToEulerZ(direction_0_f0969)
    lights['sna_sun'].rotation_euler = (math.radians(bpy.context.preferences.addons['appart_deco'].preferences.sna_sunheight), 0.0, return_E6AF1)
    lights['sna_sun'].location = lights['sna_ouverture'].location


def sna_getbiggestopening_B7F6F(openings):
    return_9B248 = sortByDimension(openings)
    return return_9B248[0]


def sna_getsundirection_F1B1B():
    output_0_9b4a1 = sna_getstructure_1B718('Sol')
    lights['sna_sol'] = output_0_9b4a1[0]
    output_0_f3516 = sna_getstructure_1B718('Ouverture')
    biggest_0_94cd2 = sna_getbiggestopening_B7F6F(output_0_f3516)
    lights['sna_ouverture'] = biggest_0_94cd2
    return (eval("(sna_getbottomcenter_8EC07(lights['sna_sol'])[1] - sna_getbottomcenter_8EC07(lights['sna_ouverture'])[1]).normalized()")[0], eval("(sna_getbottomcenter_8EC07(lights['sna_sol'])[1] - sna_getbottomcenter_8EC07(lights['sna_ouverture'])[1]).normalized()")[1], 0.0)


class SNA_PT_MATERIAL_3846D(bpy.types.Panel):
    bl_label = 'Material'
    bl_idname = 'SNA_PT_MATERIAL_3846D'
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'AppartDeco'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        if property_exists("bpy.context.view_layer.objects.active.active_material.sna_materialpointer", globals(), locals()):
            grid_A1D0D = layout.grid_flow(columns=2, row_major=True, even_columns=False, even_rows=False, align=False)
            grid_A1D0D.enabled = True
            grid_A1D0D.active = True
            grid_A1D0D.use_property_split = False
            grid_A1D0D.use_property_decorate = False
            grid_A1D0D.alignment = 'Expand'.upper()
            grid_A1D0D.scale_x = 1.0
            grid_A1D0D.scale_y = 1.0
            if not True: grid_A1D0D.operator_context = "EXEC_DEFAULT"
            grid_A1D0D.prop(bpy.context.view_layer.objects.active.active_material.sna_materialpointer.genericproduct, 'id', text='ID', icon_value=0, emboss=True)
            grid_A1D0D.prop(bpy.context.view_layer.objects.active.active_material.sna_materialpointer.genericproduct, 'name', text='Nom', icon_value=0, emboss=True)
            grid_A1D0D.prop(bpy.context.view_layer.objects.active.active_material.sna_materialpointer.genericproduct, 'filepath', text='Filepath', icon_value=0, emboss=True)
            grid_A1D0D.prop(bpy.context.view_layer.objects.active.active_material.sna_materialpointer.genericproduct, 'link', text='Lien', icon_value=0, emboss=True)
            grid_A1D0D.prop(bpy.context.view_layer.objects.active.active_material.sna_materialpointer.genericproduct, 'price', text='Prix EUR', icon_value=0, emboss=True)
            grid_A1D0D.prop(bpy.context.view_layer.objects.active.active_material.sna_materialpointer.genericproduct, 'color', text='Couleur', icon_value=0, emboss=True)


class SNA_OT_Place_Cam_8Cd50(bpy.types.Operator):
    bl_idname = "sna.place_cam_8cd50"
    bl_label = "place_cam"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.object.camera_add('INVOKE_DEFAULT', )
        bpy.context.view_layer.objects.active.rotation_euler = (math.radians(90.0), 0.0, 0.0)
        bpy.context.view_layer.objects.active.data.type = 'PANO'
        bpy.context.view_layer.objects.active.data.cycles.panorama_type = 'EQUIRECTANGULAR'
        bpy.context.view_layer.objects.active.location = (bpy.context.scene.cursor.location[0], bpy.context.scene.cursor.location[1], float(bpy.context.scene.cursor.location[2] + 1.2000000476837158))
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_CAMRAS_521CB(bpy.types.Panel):
    bl_label = 'Caméras'
    bl_idname = 'SNA_PT_CAMRAS_521CB'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'AppartDeco'
    bl_order = 2
    bl_options = {'HEADER_LAYOUT_EXPAND'}
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        box_D91EE = layout.box()
        box_D91EE.alert = False
        box_D91EE.enabled = True
        box_D91EE.active = True
        box_D91EE.use_property_split = False
        box_D91EE.use_property_decorate = False
        box_D91EE.alignment = 'Expand'.upper()
        box_D91EE.scale_x = 1.0
        box_D91EE.scale_y = 1.0
        if not True: box_D91EE.operator_context = "EXEC_DEFAULT"
        col_25359 = box_D91EE.column(heading='', align=False)
        col_25359.alert = False
        col_25359.enabled = True
        col_25359.active = True
        col_25359.use_property_split = False
        col_25359.use_property_decorate = False
        col_25359.scale_x = 1.0
        col_25359.scale_y = 1.0
        col_25359.alignment = 'Expand'.upper()
        if not True: col_25359.operator_context = "EXEC_DEFAULT"
        row_171EB = col_25359.row(heading='', align=False)
        row_171EB.alert = False
        row_171EB.enabled = True
        row_171EB.active = True
        row_171EB.use_property_split = False
        row_171EB.use_property_decorate = False
        row_171EB.scale_x = 1.0
        row_171EB.scale_y = 1.0
        row_171EB.alignment = 'Expand'.upper()
        if not True: row_171EB.operator_context = "EXEC_DEFAULT"
        row_188B8 = row_171EB.row(heading='', align=True)
        row_188B8.alert = False
        row_188B8.enabled = True
        row_188B8.active = True
        row_188B8.use_property_split = False
        row_188B8.use_property_decorate = False
        row_188B8.scale_x = 1.0
        row_188B8.scale_y = 1.0
        row_188B8.alignment = 'Left'.upper()
        if not True: row_188B8.operator_context = "EXEC_DEFAULT"
        row_188B8.label(text='360°', icon_value=0)
        row_94198 = row_171EB.row(heading='', align=True)
        row_94198.alert = False
        row_94198.enabled = True
        row_94198.active = True
        row_94198.use_property_split = False
        row_94198.use_property_decorate = False
        row_94198.scale_x = 1.0
        row_94198.scale_y = 1.0
        row_94198.alignment = 'Expand'.upper()
        if not True: row_94198.operator_context = "EXEC_DEFAULT"
        op = row_94198.operator('sna.place_cam_8cd50', text='Placer sur curseur 3D', icon_value=168, emboss=True, depress=False)


class SNA_AddonPreferences_07739(bpy.types.AddonPreferences):
    bl_idname = 'appart_deco'
    sna_lightceilingoffset: bpy.props.FloatProperty(name='LightCeilingOffset', description='', default=-0.6000000238418579, subtype='NONE', unit='NONE', step=3, precision=6)
    sna_skyname: bpy.props.StringProperty(name='SkyName', description='', default='APP_Sky', subtype='NONE', maxlen=0)
    sna_lightceilingname: bpy.props.StringProperty(name='LightCeilingName', description='', default='APP_Ceiling', subtype='NONE', maxlen=0)
    sna_sunname: bpy.props.StringProperty(name='SunName', description='', default='APP_Sun', subtype='NONE', maxlen=0)
    sna_sunheight: bpy.props.FloatProperty(name='SunHeight', description='Hauteur du soleil en degré', default=60.0, subtype='ANGLE', unit='NONE', step=3, precision=4)
    sna_portalname: bpy.props.StringProperty(name='PortalName', description='', default='APP_Portal', subtype='NONE', maxlen=0)

    def draw(self, context):
        if not (False):
            layout = self.layout 


class SNA_PT_D_19DBC(bpy.types.Panel):
    bl_label = '3D'
    bl_idname = 'SNA_PT_D_19DBC'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'AppartDeco'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ((None == bpy.context.view_layer.objects.active))

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        box_A8E26 = layout.box()
        box_A8E26.alert = False
        box_A8E26.enabled = True
        box_A8E26.active = True
        box_A8E26.use_property_split = False
        box_A8E26.use_property_decorate = False
        box_A8E26.alignment = 'Expand'.upper()
        box_A8E26.scale_x = 1.0
        box_A8E26.scale_y = 1.0
        if not True: box_A8E26.operator_context = "EXEC_DEFAULT"
        box_A8E26.label(text='Immobilier', icon_value=673)
        row_19B1B = box_A8E26.row(heading='', align=False)
        row_19B1B.alert = False
        row_19B1B.enabled = True
        row_19B1B.active = True
        row_19B1B.use_property_split = False
        row_19B1B.use_property_decorate = False
        row_19B1B.scale_x = 1.0
        row_19B1B.scale_y = 1.0
        row_19B1B.alignment = 'Expand'.upper()
        if not True: row_19B1B.operator_context = "EXEC_DEFAULT"
        row_19B1B.label(text='Structure', icon_value=0)
        row_19B1B.prop(bpy.context.view_layer.objects.active, 'sna_structure', text='Structure', icon_value=0, emboss=True, expand=True)
        layout.separator(factor=0.0)
        box_618EB = layout.box()
        box_618EB.alert = False
        box_618EB.enabled = True
        box_618EB.active = True
        box_618EB.use_property_split = False
        box_618EB.use_property_decorate = False
        box_618EB.alignment = 'Expand'.upper()
        box_618EB.scale_x = 1.0
        box_618EB.scale_y = 1.0
        if not True: box_618EB.operator_context = "EXEC_DEFAULT"
        box_618EB.label(text='Produits', icon_value=124)
        if property_exists("bpy.context.view_layer.objects.active.sna_objectpointer", globals(), locals()):
            row_EAB79 = box_618EB.row(heading='', align=False)
            row_EAB79.alert = False
            row_EAB79.enabled = True
            row_EAB79.active = True
            row_EAB79.use_property_split = False
            row_EAB79.use_property_decorate = False
            row_EAB79.scale_x = 1.0
            row_EAB79.scale_y = 1.0
            row_EAB79.alignment = 'Expand'.upper()
            if not True: row_EAB79.operator_context = "EXEC_DEFAULT"
            row_EAB79.label(text='Pivot', icon_value=0)
            row_EAB79.prop(bpy.context.view_layer.objects.active.sna_objectpointer, 'pivot', text='Pivot', icon_value=0, emboss=True, expand=True)
        grid_4EFB7 = box_618EB.grid_flow(columns=2, row_major=True, even_columns=False, even_rows=False, align=False)
        grid_4EFB7.enabled = True
        grid_4EFB7.active = True
        grid_4EFB7.use_property_split = False
        grid_4EFB7.use_property_decorate = False
        grid_4EFB7.alignment = 'Expand'.upper()
        grid_4EFB7.scale_x = 1.0
        grid_4EFB7.scale_y = 1.0
        if not True: grid_4EFB7.operator_context = "EXEC_DEFAULT"
        grid_4EFB7.prop(bpy.context.view_layer.objects.active.sna_objectpointer.genericproduct, 'id', text='ID', icon_value=0, emboss=True)
        grid_4EFB7.prop(bpy.context.view_layer.objects.active.sna_objectpointer.genericproduct, 'name', text='Nom', icon_value=0, emboss=True)
        grid_4EFB7.prop(bpy.context.view_layer.objects.active.sna_objectpointer.genericproduct, 'filepath', text='Filepath', icon_value=0, emboss=True)
        grid_4EFB7.prop(bpy.context.view_layer.objects.active.sna_objectpointer.genericproduct, 'link', text='Lien', icon_value=0, emboss=True)
        grid_4EFB7.prop(bpy.context.view_layer.objects.active.sna_objectpointer.genericproduct, 'price', text='Prix EUR', icon_value=0, emboss=True)
        grid_4EFB7.prop(bpy.context.view_layer.objects.active.sna_objectpointer.genericproduct, 'color', text='Couleur', icon_value=0, emboss=True)
        grid_4EFB7.prop(bpy.context.view_layer.objects.active.sna_objectpointer.genericproduct, 'type', text='Type', icon_value=0, emboss=True)


def sna_dproduct_pivot_enum_items(self, context):
    enum_items = [['None', 'None', '', 0], ['Sol', 'Sol', '', 0], ['Mur', 'Mur', '', 0], ['Plafond', 'Plafond', '', 0]]
    return [make_enum_item(item[0], item[1], item[2], item[3], i) for i, item in enumerate(enum_items)]


def sna_pivot_enum_items(self, context):
    enum_items = [['None', 'None', '', 0], ['Sol', 'Sol', '', 0], ['Mur', 'Mur', '', 0], ['Plafond', 'Plafond', '', 0]]
    return [make_enum_item(item[0], item[1], item[2], item[3], i) for i, item in enumerate(enum_items)]


class SNA_GROUP_sna_genericproduct(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name='Name', description='', default='', subtype='NONE', maxlen=0)
    filepath: bpy.props.StringProperty(name='Filepath', description='Filepath of the product', default='', subtype='FILE_PATH', maxlen=0)
    link: bpy.props.StringProperty(name='Link', description='Webpage link', options={'HIDDEN'}, default='', subtype='BYTE_STRING', maxlen=0)
    price: bpy.props.FloatProperty(name='Price', description='', default=0.0, subtype='NONE', unit='NONE', min=0.0, step=10, precision=2)
    color: bpy.props.StringProperty(name='Color', description='', options={'HIDDEN'}, default='', subtype='NONE', maxlen=0)
    id: bpy.props.StringProperty(name='ID', description='', default='', subtype='NONE', maxlen=0)
    type: bpy.props.StringProperty(name='Type', description='', default='', subtype='NONE', maxlen=0)


class SNA_GROUP_sna_dproduct(bpy.types.PropertyGroup):
    genericproduct: bpy.props.PointerProperty(name='GenericProduct', description='', type=SNA_GROUP_sna_genericproduct)
    pivot: bpy.props.EnumProperty(name='Pivot', description='', items=sna_dproduct_pivot_enum_items)


class SNA_GROUP_sna_materialproduct(bpy.types.PropertyGroup):
    genericproduct: bpy.props.PointerProperty(name='GenericProduct', description='', type=SNA_GROUP_sna_genericproduct)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_GROUP_sna_genericproduct)
    bpy.utils.register_class(SNA_GROUP_sna_dproduct)
    bpy.utils.register_class(SNA_GROUP_sna_materialproduct)
    bpy.types.Object.sna_pivot = bpy.props.EnumProperty(name='Pivot', description='', items=sna_pivot_enum_items)
    bpy.types.Object.sna_structure = bpy.props.EnumProperty(name='Structure', description='', items=[('None', 'None', '', 0, 0), ('Sol', 'Sol', '', 0, 1), ('Plafond', 'Plafond', '', 0, 2), ('Mur', 'Mur', '', 0, 3), ('Ouverture', 'Ouverture', '', 0, 4)])
    bpy.types.Object.sna_objectpointer = bpy.props.PointerProperty(name='ObjectPointer', description='', type=SNA_GROUP_sna_dproduct)
    bpy.types.Scene.sna_index = bpy.props.IntProperty(name='index', description='', default=0, subtype='NONE', update=sna_update_sna_index_7D7ED)
    bpy.types.Scene.sna_filtre_couleur = bpy.props.StringProperty(name='Filtre Couleur', description='', default='', subtype='NONE', maxlen=0)
    bpy.types.Material.sna_materialpointer = bpy.props.PointerProperty(name='MaterialPointer', description='', type=SNA_GROUP_sna_materialproduct)
    bpy.types.Scene.sna_database = bpy.props.StringProperty(name='Database', description='', default='', subtype='FILE_PATH', maxlen=0)
    bpy.types.Scene.sna_tablename = bpy.props.StringProperty(name='TableName', description='Zago_Officiel', default='', subtype='NONE', maxlen=0)
    bpy.types.Scene.sna_skyname = bpy.props.StringProperty(name='skyName', description='', default='APP_Sky', subtype='NONE', maxlen=0)
    bpy.utils.register_class(SNA_PT_ASSIGN_PROPERTIES_TO_FILES_CDAEE)
    bpy.utils.register_class(SNA_OT_Assignprops_Ef6F9)
    bpy.utils.register_class(SNA_OT_Openfile_6Affe)
    bpy.utils.register_class(SNA_PT_LISTE_DE_PRODUITS_PLACS_B56D9)
    bpy.utils.register_class(SNA_UL_display_collection_list_FF513)
    bpy.utils.register_class(SNA_OT_Delete_F7Cfc)
    bpy.utils.register_class(SNA_PT_LUMIRES_4EFEC)
    bpy.utils.register_class(SNA_PT_pas_de_plafond_1F3F4)
    bpy.app.handlers.load_pre.append(load_pre_handler_32C0D)
    bpy.utils.register_class(SNA_OT_Alllights_4E0Bb)
    bpy.utils.register_class(SNA_PT_MATERIAL_3846D)
    bpy.utils.register_class(SNA_OT_Place_Cam_8Cd50)
    bpy.utils.register_class(SNA_PT_CAMRAS_521CB)
    bpy.utils.register_class(SNA_AddonPreferences_07739)
    bpy.utils.register_class(SNA_PT_D_19DBC)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_skyname
    del bpy.types.Scene.sna_tablename
    del bpy.types.Scene.sna_database
    del bpy.types.Material.sna_materialpointer
    del bpy.types.Scene.sna_filtre_couleur
    del bpy.types.Scene.sna_index
    del bpy.types.Object.sna_objectpointer
    del bpy.types.Object.sna_structure
    del bpy.types.Object.sna_pivot
    bpy.utils.unregister_class(SNA_GROUP_sna_materialproduct)
    bpy.utils.unregister_class(SNA_GROUP_sna_dproduct)
    bpy.utils.unregister_class(SNA_GROUP_sna_genericproduct)
    bpy.utils.unregister_class(SNA_PT_ASSIGN_PROPERTIES_TO_FILES_CDAEE)
    bpy.utils.unregister_class(SNA_OT_Assignprops_Ef6F9)
    bpy.utils.unregister_class(SNA_OT_Openfile_6Affe)
    bpy.utils.unregister_class(SNA_PT_LISTE_DE_PRODUITS_PLACS_B56D9)
    bpy.utils.unregister_class(SNA_UL_display_collection_list_FF513)
    bpy.utils.unregister_class(SNA_OT_Delete_F7Cfc)
    bpy.utils.unregister_class(SNA_PT_LUMIRES_4EFEC)
    bpy.utils.unregister_class(SNA_PT_pas_de_plafond_1F3F4)
    bpy.app.handlers.load_pre.remove(load_pre_handler_32C0D)
    bpy.utils.unregister_class(SNA_OT_Alllights_4E0Bb)
    bpy.utils.unregister_class(SNA_PT_MATERIAL_3846D)
    bpy.utils.unregister_class(SNA_OT_Place_Cam_8Cd50)
    bpy.utils.unregister_class(SNA_PT_CAMRAS_521CB)
    bpy.utils.unregister_class(SNA_AddonPreferences_07739)
    bpy.utils.unregister_class(SNA_PT_D_19DBC)
